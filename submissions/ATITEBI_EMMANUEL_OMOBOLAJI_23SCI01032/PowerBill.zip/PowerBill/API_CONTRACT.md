# API Contract

Base prefix: `/api/v1`

Public: `GET /public/tariffs`, `GET /public/stats`.

Authentication: `GET /auth/csrf`, `POST /auth/register`, `POST /auth/login`, `POST /auth/logout`, `GET /auth/me`.

Customer: `GET /me/dashboard`, `GET /me/meters`, `GET /me/bills`, `GET /me/bills/{id}`, `POST /me/bills/{id}/pay`, `GET /me/bills/{id}/receipt`, `POST /me/readings`, `GET|POST /me/complaints`.

Staff: `GET /staff/stats`, `GET|POST /staff/meters`, `GET /staff/customers?q&page` (search active customers by name/email), `POST /staff/readings`, `GET /staff/bills`, `GET /staff/bills/{id}`, `POST /staff/bills/{id}/pay`, `GET /staff/complaints`, `PATCH /staff/complaints/{id}`.

Admin: `GET /admin/users`, `PATCH /admin/users/{id}`, `GET|POST|PATCH /admin/tariffs`, `GET /admin/audit`.

For state-changing requests, obtain a CSRF token from `GET /auth/csrf`, retain the first-party session cookie, send `X-CSRF-Token`, and use an allowed Origin. Ownership and role checks are enforced by the backend.
