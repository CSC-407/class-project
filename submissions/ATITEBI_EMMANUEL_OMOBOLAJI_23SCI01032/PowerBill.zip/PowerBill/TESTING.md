# Testing Guide

Test suites:
- Backend pytest: `powerbill/backend/tests/`.
- Frontend Vitest/React Testing Library: `powerbill/frontend/tests/`.
- Browser tests: `powerbill/frontend/e2e/`.

Backend:
```bash
python -m pip install -r powerbill/backend/requirements.txt
cd powerbill/backend
python -m pytest
```

Frontend:
```bash
cd powerbill/frontend
npm ci
npm run typecheck
npm test
npm run build
```

Browser tests:
```bash
cd powerbill/frontend
npx playwright install chromium
npm run test:e2e
```

The browser tests use isolated test services. Never point tests at production data. Coverage includes authentication, authorization, validation, meter readings, billing logic, payment safeguards, audit events, CSRF/Origin enforcement, security headers, error handling and responsive customer workflows. Record actual command output when a new test run is performed.
