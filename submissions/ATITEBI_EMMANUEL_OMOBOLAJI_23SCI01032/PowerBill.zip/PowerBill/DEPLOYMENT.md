# Deployment Guide

- Frontend: Vercel project `power-bill`, root `powerbill/frontend`, URL https://power-bill-nine.vercel.app.
- API: Vercel project `power-bill-api`, root `powerbill/backend`, URL https://power-bill-api.vercel.app.
- Database: PostgreSQL hosted by Supabase.

Backend protected environment variables:
- `FLASK_ENV=production`
- `DATABASE_URL`: PowerBill PostgreSQL connection string with SSL.
- `SECRET_KEY`: generated random value of at least 32 characters.
- `ALLOWED_ORIGINS`: exact production frontend origin.
- `COOKIE_SECURE=true`

Frontend environment:
- `POWERBILL_API_ORIGIN=https://power-bill-api.vercel.app`

Apply the reviewed `powerbill/backend/schema.sql` to the database. Keep database credentials server-side and store them only in protected deployment settings.

Verification checklist:
- API health and public tariff endpoints respond.
- Registration and login work.
- Session cookies are HttpOnly and Secure in production.
- Customers cannot access staff/admin routes or another customer's records.
- CSRF and Origin checks protect state-changing requests.
- Meter assignment and reading submission work with separate test accounts.

A real third-party payment gateway is not integrated; production customer checkout is disabled. Billing staff can record verified offline payments.
