# PowerBill source

The project overview, setup instructions, local run steps, test commands and known limitations are documented in the [main README](../README.md).

- `backend/`: Flask API, data models, validation, security and backend tests.
- `frontend/`: Next.js application, UI components and frontend tests.
