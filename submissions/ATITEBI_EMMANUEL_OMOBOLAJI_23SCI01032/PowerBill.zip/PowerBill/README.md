# PowerBill — Electricity Bill Management System

**Student:** Atitebi Emmanuel Omobolaji  
**Matric number:** 23/SCI01/032  
**Course:** CSC 407  
**Project title:** Design and Implementation of an Electricity Bill Management System

## Overview

PowerBill is a web-based electricity bill management system. Customers can register, sign in, view their dashboard, submit meter readings, view bills and receipts, keep track of payment records, and raise complaints. Billing staff manage customer meters, readings, bills and complaints. Administrators manage users, tariffs and audit records.

The system includes server-side authentication, role-based authorization, ownership checks, input validation, secure session handling, CSRF protection and audit logging.

## Live application

- **Frontend:** https://power-bill-nine.vercel.app
- **Backend health endpoint:** https://power-bill-api.vercel.app/health

## Technology stack

- **Frontend:** Next.js 16, React 19, TypeScript and Tailwind CSS
- **Backend:** Python, Flask, SQLAlchemy and bcrypt
- **Database:** PostgreSQL/Supabase for the hosted environment; SQLite for the isolated local demonstration
- **Deployment:** Vercel

## Main features

- Customer registration, authentication and dashboard
- Customer meter assignment and meter-reading submission
- Active tariff management and tariff-based bill generation
- Bill history, payment records and printable receipts
- Customer complaints and staff responses
- Administrator and billing-officer roles
- Server-side validation, authorization and audit logging
- Responsive interface for desktop and mobile screens

## Run locally

### Requirements

- Python 3.11 or newer
- Node.js 22 or newer
- npm

The included local launcher uses a separate SQLite database. It does not need production database credentials.

### 1. Set up the backend

Open a terminal in the extracted `PowerBill` folder:

```bash
python -m venv .venv
```

Activate the environment.

**Windows PowerShell:**

```powershell
.\.venv\Scripts\Activate.ps1
```

**macOS / Linux:**

```bash
source .venv/bin/activate
```

Install the backend dependencies and start the local API:

```bash
python -m pip install -r powerbill/backend/requirements.txt
python run_local.py
```

The API runs at `http://127.0.0.1:5000`. The launcher initializes a local SQLite database automatically.

### 2. Set up the frontend

Open a second terminal in the same extracted `PowerBill` folder:

```bash
cd powerbill/frontend
npm ci
npm run dev
```

Open **http://localhost:3000** in your browser. The frontend uses the local API on port 5000. Register a customer account to begin using the local demonstration.

### Optional: create a local administrator

From the extracted `PowerBill` folder, with the Python environment activated, run:

```bash
python run_local.py --create-admin
```

Follow the prompts to create a local administrator account. No default administrator password is provided.

## Run tests

**Backend** (from the extracted `PowerBill` folder):

```bash
cd powerbill/backend
python -m pytest
```

**Frontend:**

```bash
cd powerbill/frontend
npm ci
npm test
npm run build
```

Optional browser end-to-end tests require Playwright Chromium:

```bash
npx playwright install chromium
npm run test:e2e
```

## Known limitations

- A real third-party payment-gateway collection flow is not integrated. Payment records and receipts are supported, but online checkout is not available.
- Prepaid electricity-token vending is not integrated.
- The local demonstration uses its own SQLite database and is separate from the hosted production database.

## Security and configuration

The source includes example environment templates only. Replace placeholder values when configuring a separate deployment. **Do not put real passwords, API keys, database credentials or `.env` files in the submission.**
