# PowerBill — Electricity Bill Management System

**Student:** Atitebi Emmanuel Omobolaji  
**Matric number:** 23/SCI01/032  
**Course:** CSC 407  
**Project title:** Design and Implementation of an Electricity Bill Management System

## Overview
PowerBill is a web-based electricity bill management system for customers, billing officers and administrators. It provides customer accounts, meter assignment, meter-reading submission, tariff-based billing, bill history, payment records, receipts and complaint handling.

Customers can register, view their dashboard, submit meter readings, review bills and receipts, and raise complaints. Billing staff can search for customers, assign meters, manage readings and bills, record verified offline payments and respond to complaints. Administrators manage users, roles, tariffs and audit records.

The application applies server-side authentication and authorization, ownership checks, input validation, secure sessions, CSRF and Origin checks, and audit logging.

## Live application
- Frontend: https://power-bill-nine.vercel.app
- Backend health: https://power-bill-api.vercel.app/health

## Technology stack
- Frontend: Next.js 16, React 19, TypeScript and Tailwind CSS.
- Backend: Python, Flask and SQLAlchemy.
- Database: PostgreSQL (hosted) and SQLite (local demo).
- Security: bcrypt, HttpOnly sessions, CSRF/Origin validation, role-based access control and audit logging.
- Testing: pytest, Vitest, React Testing Library and Playwright.
- Deployment: Vercel and Supabase PostgreSQL.

## Run locally
Requirements: Python 3.11+, Node.js 22+ and npm. The local demo does not require production database credentials.

### 1. Backend
From the extracted `PowerBill` folder:
```bash
python -m venv .venv
```
Activate it with `.venv\\Scripts\\Activate.ps1` (Windows PowerShell) or `source .venv/bin/activate` (macOS/Linux), then run:
```bash
python -m pip install -r powerbill/backend/requirements.txt
python run_local.py
```
The API runs at `http://127.0.0.1:5000` and initializes a separate SQLite database.

### 2. Frontend
Open a second terminal in the extracted `PowerBill` folder:
```bash
cd powerbill/frontend
npm ci
npm run dev
```
Open **http://localhost:3000** and register a customer account.

### Optional local administrator
From the extracted project root, with the Python environment activated:
```bash
python run_local.py --create-admin
```
Follow the prompts. No default administrator credentials are included. Local demo data is separate from production.

## Run tests
Backend:
```bash
cd powerbill/backend
python -m pytest
```
Frontend:
```bash
cd powerbill/frontend
npm ci
npm run typecheck
npm test
npm run build
```
Optional browser tests:
```bash
npx playwright install chromium
npm run test:e2e
```
The Playwright configuration uses isolated test services. Never run tests against production data.

## Known limitations
- A real third-party online payment gateway is not integrated; production customer checkout is disabled.
- Billing staff can record verified offline payments.
- Prepaid token vending and direct smart-meter ingestion are not integrated.
- Receipts are printable HTML rather than generated PDF documents.

## Project structure
- `run_local.py`: local SQLite demo launcher.
- `powerbill/backend/`: Flask API, models, schema, security, services and backend tests.
- `powerbill/frontend/`: Next.js application, UI, API client and frontend tests.
- `DEPLOYMENT.md`, `TESTING.md`, `PROJECT_REVIEW.md`, `API_CONTRACT.md`: project documentation.

The archive excludes production `.env` files, passwords, database credentials, API keys, dependency folders and generated build output.
