# Project Review

## What the application does

A web application with registration, login, user profiles, private notes and an admin panel, built to demonstrate security, testing and deployment practices for web applications.

## Features implemented

- Registration and login with client and server validation
- Dashboard with create / search / delete notes
- Profile with name update and password change
- Admin panel: stats, user search and role filter, role change, user deletion, audit log
- Security page with measures table and live attack checks
- Responsive layout (mobile menu, flexible grids, scrollable tables)

## Security measures

bcrypt hashing, server-side sessions with HttpOnly/SameSite/Secure cookies, role-based access control, rate limiting and account lockout, parameterized SQL, input validation, XSS-safe rendering and CSP, CSRF header check, security headers, generic errors, audit logging. Details: Security page and README.

## Testing results

30 automated tests, 30 passed. 8 server-level checks run against the live app also passed or were observed as expected (see `TEST_PLAN.md`). Browser-based checks (form validation display, responsive layout, usability) are listed in the test plan as still to verify by hand.

## Performance observations

- A login takes about 0.31-0.34 s with bcrypt cost 12 (measured over three requests). This is intentional: the slowness is what makes password guessing expensive.
- SQLite in WAL mode handles this app's expected load easily. Higher traffic would call for PostgreSQL or MySQL.

## Problems encountered

- **Cookies and origins:** a frontend on a separate port would need CORS and weaker cookie settings. Solved by serving the frontend from the same origin as the API, which also keeps the CSRF defence strict.
- **Stateless JWT vs logout:** a plain JWT stays valid until it expires even after logout. Solved by storing a session row per login and checking it on every request, so logout really ends access.
- **Strict Content-Security-Policy:** blocking inline scripts and styles meant all JavaScript lives in separate files and the pages are built without `innerHTML`.
- **Test runner setup:** `node --test tests/` treated the folder as a file, so the test script points at the test file directly.
- **Port conflict on first run:** port 5000 was already in use on the development machine; the port is configurable with `PORT` in `.env`.

## Limitations

- No email verification or password reset flow
- No multi-factor authentication
- Rate limiting is in memory per server instance; a multi-server deployment would need a shared store (e.g. Redis)
- SQLite suits a demo or small site
- Lockout can be used to deliberately lock a known user's account (a known trade-off)
- Registration reveals whether an email is already taken
- Not deployed online; runs locally (deployment steps are in `DEPLOYMENT.md`)

## Possible future improvements

- Email verification and password reset
- Two-factor authentication (TOTP)
- "Active sessions" list with remote sign-out
- Breached-password check at registration
- Migrate to PostgreSQL and add CI that runs `npm test` on every push
- Automated browser tests (Playwright) for the frontend
