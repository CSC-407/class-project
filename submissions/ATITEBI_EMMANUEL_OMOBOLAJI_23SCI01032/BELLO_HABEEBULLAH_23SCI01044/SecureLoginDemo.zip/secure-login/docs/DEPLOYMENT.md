# Deployment Guide

How the app moves from development to a live environment.

## 1. Environments

| | Development | Production |
|---|---|---|
| `NODE_ENV` | `development` | `production` |
| Cookies | `Secure` off (works on http://localhost) | `Secure` on (HTTPS only) |
| HSTS / upgrade-insecure-requests | off | on |
| Database | `./data/app.db` | persistent disk or managed volume |
| Secrets | `.env` (git-ignored) | host's environment-variable settings |

## 2. Configuration (environment variables)

All settings are in `backend/.env.example`. Key ones:

- `JWT_SECRET`: 32+ random characters. The server refuses to start without it. Generate with `npm run setup` or `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`.
- `NODE_ENV=production`
- `TRUST_PROXY=1` when behind Nginx or a hosting platform's proxy (needed for correct client IPs and rate limiting).
- `ADMIN_EMAIL` / `ADMIN_PASSWORD`: use a strong password, then remove these two variables after the first start.
- `DB_PATH`: location of the SQLite file.

Never commit `.env`. It is listed in `.gitignore`.

## 3. Option A: Hosting platform (easiest, e.g. Render, Railway)

1. Push the project to GitHub.
2. Create a new **Web Service**, root directory `backend`.
3. Build command: `npm install`. Start command: `npm start`.
4. Add the environment variables from section 2.
5. Add a **persistent disk** and point `DB_PATH` at it (otherwise the SQLite file is lost on redeploy).
6. The platform provides HTTPS and a domain automatically.

## 4. Option B: Your own server (VPS with Nginx)

```bash
# on the server
git clone <your-repo> && cd secure-login/backend
npm install --omit=dev
cp .env.example .env && nano .env      # set production values
npm install -g pm2
pm2 start server.js --name secure-login
pm2 save && pm2 startup
```

Nginx reverse proxy (`/etc/nginx/sites-available/secure-login`):

```nginx
server {
    server_name yourdomain.com;
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

HTTPS with a free certificate:

```bash
sudo certbot --nginx -d yourdomain.com
```

Set `TRUST_PROXY=1` and `NODE_ENV=production`, then `pm2 restart secure-login`.

## 5. Deployment checklist

- [ ] `NODE_ENV=production`
- [ ] Strong, unique `JWT_SECRET`
- [ ] Default admin password changed (and `ADMIN_*` variables removed after first start)
- [ ] HTTPS working, http redirects to https
- [ ] `.env` and `data/` not in version control
- [ ] `npm test` passes before every deploy
- [ ] Persistent storage for the database
- [ ] Backups scheduled (below)

## 6. Backups

SQLite is a single file, so backups are simple. With the app running (WAL mode), use the safe online backup command:

```bash
sqlite3 data/app.db ".backup 'backup-$(date +%F).db'"
```

Schedule it daily with cron, keep several days, and copy backups off the server. Test a restore occasionally by copying a backup over `data/app.db` while the app is stopped.

## 7. Logging and monitoring

- **Application events:** the `audit_log` table records logins, failures, lockouts, role changes and denied access. Admins can read it on the Admin page.
- **Server errors:** unexpected errors are written to the console (`pm2 logs secure-login`); clients only ever see a generic message.
- **Health check:** `GET /` returns 200 when the app is up. Point an uptime monitor (UptimeRobot, etc.) at it.
- Watch for spikes in `login_failed` / `account_locked` events: they indicate brute-force attempts.

## 8. Update process

1. Develop and test locally (`npm test`).
2. Commit and push.
3. On the host: pull, `npm install --omit=dev`, `pm2 restart secure-login` (platforms do this automatically on push).
4. Check the home page and log in once to confirm.
