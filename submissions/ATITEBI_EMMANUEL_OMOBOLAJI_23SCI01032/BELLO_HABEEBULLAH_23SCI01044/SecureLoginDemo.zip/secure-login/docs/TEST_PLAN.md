# Test Plan and Results

## 1. Automated tests (backend)

Run with `cd backend && npm test`. Last run: **30 passed, 0 failed**.

| ID | Test | Expected result | Status |
|---|---|---|---|
| REG-01 | Valid registration | 201, user returned without password hash | Pass |
| REG-02 | Empty fields | 400 with field errors | Pass |
| REG-03 | Invalid email | 400 with email error | Pass |
| REG-04 | Weak passwords (4 variants) | 400 with password error | Pass |
| REG-05 | Duplicate email (different case) | 409 | Pass |
| REG-06 | `role: "admin"` in registration body | Ignored, role is `user` | Pass |
| LOG-01 | Valid login | 200, HttpOnly + SameSite=Strict cookie | Pass |
| LOG-02 | Wrong password vs unknown email | Identical generic 401 error | Pass |
| LOG-03 | Missing credentials | 400 | Pass |
| LOG-04 | 5 wrong passwords | Account locked (423), even with right password | Pass |
| LOG-05 | Logout, then replay old cookie | 401 (session destroyed server-side) | Pass |
| LOG-06 | Tampered token | 401 | Pass |
| ACC-01 | Protected routes without login | 401 | Pass |
| ACC-02 | Normal user calls admin routes | 403 | Pass |
| ACC-03 | Admin lists, searches, filters users, reads audit | 200 | Pass |
| ACC-04 | Admin demotes / deletes self | 400 | Pass |
| ACC-05 | User reads / deletes another user's note | Empty list / 404 | Pass |
| SEC-01 | SQL injection payloads on login | 400/401, database intact | Pass |
| SEC-02 | SQL injection in search | Treated as text, no results | Pass |
| SEC-03 | `<script>` in a note | Stored as inert text, JSON + nosniff | Pass |
| SEC-04 | HTML in the name field | 400 | Pass |
| SEC-05 | Security headers | CSP, frame-ancestors, no X-Powered-By | Pass |
| SEC-06 | POST without CSRF header | 403 | Pass |
| PRO-01 | Update name (valid / invalid) | 200 / 400 | Pass |
| PRO-02 | Change password | Needs current password; other sessions signed out | Pass |
| ERR-01 | Malformed JSON | 400 clean message | Pass |
| ERR-02 | Unknown API route | 404 JSON | Pass |
| ERR-03 | Oversized body | 413 | Pass |
| DB-01 | Password storage | bcrypt hash, not plain text | Pass |
| DB-02 | Delete user | Notes and sessions removed (cascade) | Pass |

## 2. Manual checks against the running server

Run against a freshly installed copy of the project (`npm start`) using HTTP requests (curl).

| Area | Test | Expected result | Actual | Status |
|---|---|---|---|---|
| Functional | Register a normal user, then log in | 201, then 200 | 201, then 200 | Pass |
| Security | Normal user requests `/api/admin/users` | 403 | 403 | Pass |
| Security | Request `/api/admin/users` with no login | 401 | 401 | Pass |
| Security | Session cookie flags | HttpOnly, SameSite=Strict | Both present | Pass |
| Security | Log out, then reuse the old cookie | 401 | Logout 200, reuse 401 | Pass |
| Functional | Open all 7 pages and static files | 200 | 200 for all | Pass |
| Error handling | Server stopped, send a request | Connection refused (frontend shows "Cannot reach the server") | Connection refused | Pass |
| Performance | Login time with bcrypt cost 12 | Roughly a few hundred ms | 0.31-0.34 s (3 runs) | Observed |

## 3. Browser checks

These need a person at a browser. They are not yet recorded as passed; tick or edit after trying them.

| Area | Test | Expected result | Status |
|---|---|---|---|
| Form validation | Submit the register form empty | Field errors shown, no request sent | To verify |
| Form validation | Password mismatch; strength meter | Error shown; bar grows with each rule | To verify |
| Security | Type `<b>hi</b>` in a note | Shown as text, not bold | To verify |
| Security | Admin page as a normal user | "Access denied (403)" message | To verify |
| Usability | Someone unfamiliar completes register + login | Done without help | To verify |
| Responsive | Browser DevTools at 375px width | Menu collapses, no horizontal scroll | To verify |
