# Secure Login Demonstration System

A small web application that demonstrates how a login system is **secured, tested, deployed and reviewed**.
Semi-project topic: *Building Web Applications: Web Application Security, Testing, Deployment and Review*.

## Run it (3 commands)

Requires Node.js 18 or newer.

```bash
cd backend
npm install
npm run setup     # creates .env with a random JWT secret
npm start
```

Open **http://localhost:5000**

The backend also serves the `frontend/` folder, so there is nothing else to start.

**Demo admin account:** `admin@example.com` / `Admin@12345` (created on first start; change it in `.env`).
Register a normal account from the Register page to see the User role.

## Run the tests

```bash
cd backend
npm test
```

30 automated tests cover registration, login, sessions, access control, SQL injection, XSS, CSRF, error handling and the database. See `docs/TEST_PLAN.md`.

## Project structure

```
secure-login/
├── backend/
│   ├── server.js              Express app, security headers, mounts routes
│   ├── config/                db.js (SQLite), seed.js (demo admin)
│   ├── models/                user, session, note, audit tables + queries
│   ├── controllers/           auth, user, note, admin logic
│   ├── routes/                endpoint names, mounted in server.js
│   ├── middleware/            authenticate, requireRole, CSRF, rate limit, errors
│   ├── utils/validators.js    server-side input validation
│   ├── scripts/setup.js       generates .env
│   └── tests/api.test.js      automated tests
├── frontend/
│   ├── index, login, register, dashboard, profile, admin, security (.html)
│   ├── css/style.css
│   └── js/                    common.js (API + safe DOM helpers) + one file per page
└── docs/                      TEST_PLAN.md, DEPLOYMENT.md, REVIEW.md
```

## Pages

| Page | Purpose |
|---|---|
| Home | Overview of the project |
| Register / Log in | Forms with client and server validation, password strength meter |
| Dashboard | Create, search and delete your private notes |
| Profile | Update name, change password |
| Admin (admin only) | Stats, user search/filter, role change, delete, security audit log |
| Security | Table of every protection and where it is in the code, plus live attack tests |

## API

| Method | Endpoint | Access |
|---|---|---|
| POST | `/api/auth/register` | public |
| POST | `/api/auth/login` | public (rate limited) |
| POST | `/api/auth/logout` | logged in |
| GET | `/api/auth/me` | logged in |
| GET / PUT | `/api/user/profile` | logged in |
| PUT | `/api/user/password` | logged in |
| GET / POST | `/api/user/notes` | logged in (own notes only) |
| DELETE | `/api/user/notes/:id` | logged in (own notes only) |
| GET | `/api/admin/users?search=&role=` | admin |
| PUT | `/api/admin/users/:id/role` | admin |
| DELETE | `/api/admin/users/:id` | admin |
| GET | `/api/admin/audit`, `/api/admin/stats` | admin |

## Security summary

bcrypt password hashing, server-side sessions in HttpOnly + SameSite=Strict cookies, role-based access control, rate limiting and account lockout, parameterized SQL, input validation, XSS-safe rendering plus Content-Security-Policy, CSRF header check, Helmet headers, generic error messages, audit log. Full table on the app's Security page.
