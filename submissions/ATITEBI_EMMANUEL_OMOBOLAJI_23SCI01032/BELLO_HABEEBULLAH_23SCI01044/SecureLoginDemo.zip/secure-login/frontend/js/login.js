import { api, $, initPage, setFieldErrors, showMessage } from './common.js';

const user = await initPage();
if (user) window.location.replace('dashboard.html');

const form = $('#login-form');
const message = $('#message');
const submit = $('#submit');

const params = new URLSearchParams(window.location.search);
if (params.get('msg') === 'registered') showMessage(message, 'Account created. You can log in now.', 'success');
if (params.get('msg') === 'loggedout') showMessage(message, 'You have been logged out.', 'success');

// Only allow redirects to pages on this site (prevents open-redirect abuse).
function safeNext() {
  const next = params.get('next') || '';
  return /^\/[A-Za-z0-9_\-./]*\.html$/.test(next) && !next.startsWith('//') ? next : 'dashboard.html';
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  showMessage(message, '');

  const { email, password } = Object.fromEntries(new FormData(form));
  const errors = {
    email: email.trim() ? '' : 'Email is required',
    password: password ? '' : 'Password is required',
  };
  setFieldErrors(form, errors);
  if (Object.values(errors).some(Boolean)) return;

  submit.disabled = true;
  try {
    await api('/auth/login', { method: 'POST', body: { email, password } });
    window.location.href = safeNext();
  } catch (err) {
    showMessage(message, err.message);
    form.password.value = '';
  } finally {
    submit.disabled = false;
  }
});
