import { initPage, $ } from './common.js';

const user = await initPage();

if (user) {
  $('#cta').replaceChildren();
  const a = document.createElement('a');
  a.className = 'btn';
  a.href = 'dashboard.html';
  a.textContent = 'Go to your dashboard';
  $('#cta').append(a);
}
