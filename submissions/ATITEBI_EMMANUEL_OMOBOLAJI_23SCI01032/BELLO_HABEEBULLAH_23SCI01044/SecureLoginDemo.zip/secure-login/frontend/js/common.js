// Shared helpers used by every page.

// ---- API helper -------------------------------------------------------------
export async function api(path, { method = 'GET', body } = {}) {
  const options = {
    method,
    credentials: 'same-origin',
    // Custom header required by the server's CSRF protection.
    headers: { 'X-Requested-With': 'XMLHttpRequest' },
  };
  if (body !== undefined) {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify(body);
  }

  let res;
  try {
    res = await fetch('/api' + path, options);
  } catch {
    const err = new Error('Cannot reach the server. Is it running?');
    err.status = 0;
    throw err;
  }

  let data = null;
  try {
    data = await res.json();
  } catch {
    /* response had no JSON body */
  }

  if (!res.ok) {
    const err = new Error((data && data.error) || 'Request failed');
    err.status = res.status;
    err.details = data && data.details;
    throw err;
  }
  return data;
}

// ---- Safe DOM building (XSS defence) ---------------------------------------
// Everything goes through textContent / createTextNode, never innerHTML,
// so user-supplied text can never be interpreted as HTML or script.
export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? '' : value);
  }
  for (const child of children.flat()) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child.nodeType ? child : document.createTextNode(String(child)));
  }
  return node;
}

export const $ = (selector, root = document) => root.querySelector(selector);

export function formatDate(sqliteDate) {
  // SQLite stores UTC as "YYYY-MM-DD HH:MM:SS".
  const d = new Date(sqliteDate.replace(' ', 'T') + 'Z');
  return isNaN(d) ? sqliteDate : d.toLocaleString();
}

// ---- Messages and field errors ---------------------------------------------
export function showMessage(container, text, type = 'error') {
  container.replaceChildren();
  if (!text) {
    container.classList.add('hidden');
    return;
  }
  container.className = `alert alert-${type}`;
  container.setAttribute('role', type === 'error' ? 'alert' : 'status');
  container.textContent = text;
}

export function setFieldErrors(form, errors = {}) {
  for (const field of form.querySelectorAll('.field')) {
    const input = field.querySelector('input, textarea, select');
    const msg = field.querySelector('.field-error');
    const text = input && errors[input.name];
    field.classList.toggle('invalid', Boolean(text));
    if (input) input.setAttribute('aria-invalid', text ? 'true' : 'false');
    if (msg) msg.textContent = text || '';
  }
}

// ---- Client-side validation (UX only; the server re-checks everything) -----
export const rules = {
  name: (v) => (/^[\p{L}\p{M}][\p{L}\p{M}' .-]{1,59}$/u.test(v.trim()) ? '' : 'Name must be 2-60 characters: letters, spaces, apostrophes, dots or hyphens'),
  email: (v) => (/^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[A-Za-z]{2,}$/.test(v.trim()) ? '' : 'Enter a valid email address'),
  password: (v) => {
    if (v.length < 8 || v.length > 72) return 'Password must be 8-72 characters';
    if (!/[a-z]/.test(v)) return 'Add a lowercase letter';
    if (!/[A-Z]/.test(v)) return 'Add an uppercase letter';
    if (!/[0-9]/.test(v)) return 'Add a number';
    if (!/[^A-Za-z0-9]/.test(v)) return 'Add a special character';
    return '';
  },
};

export function passwordStrength(v) {
  let score = 0;
  if (v.length >= 8) score++;
  if (/[a-z]/.test(v) && /[A-Z]/.test(v)) score++;
  if (/[0-9]/.test(v)) score++;
  if (/[^A-Za-z0-9]/.test(v)) score++;
  if (v.length >= 12) score++;
  return score;
}

// ---- Session + navigation ---------------------------------------------------
export async function getCurrentUser() {
  try {
    return (await api('/auth/me')).user;
  } catch (err) {
    if (err.status === 401) return null;
    throw err;
  }
}

export async function requireLogin() {
  const user = await getCurrentUser();
  if (!user) {
    window.location.replace('/login.html?next=' + encodeURIComponent(window.location.pathname));
    return null;
  }
  return user;
}

export function renderNav(user) {
  const header = $('#site-header');
  if (!header) return;
  const here = window.location.pathname.split('/').pop() || 'index.html';

  const link = (href, label) =>
    el('a', { href, text: label, 'aria-current': here === href ? 'page' : null });

  const links = el('div', { class: 'nav-links', id: 'nav-links' }, link('index.html', 'Home'));
  if (user) {
    links.append(link('dashboard.html', 'Dashboard'), link('profile.html', 'Profile'));
    if (user.role === 'admin') links.append(link('admin.html', 'Admin'));
  }
  links.append(link('security.html', 'Security'));

  if (user) {
    links.append(
      el('button', {
        type: 'button',
        text: 'Log out',
        onclick: async () => {
          try {
            await api('/auth/logout', { method: 'POST' });
          } finally {
            window.location.href = 'login.html?msg=loggedout';
          }
        },
      })
    );
  } else {
    links.append(link('login.html', 'Log in'), link('register.html', 'Register'));
  }

  const toggle = el('button', {
    type: 'button',
    class: 'nav-toggle',
    text: 'Menu',
    'aria-expanded': 'false',
    'aria-controls': 'nav-links',
    onclick: () => {
      const open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    },
  });

  header.replaceChildren(
    el('div', { class: 'container' }, el('a', { class: 'brand', href: 'index.html', text: 'Secure Login Demo' }), toggle, links)
  );
}

// Standard page boot: find the user (if any) and draw the navigation.
export async function initPage({ requireAuth = false } = {}) {
  let user = null;
  try {
    user = requireAuth ? await requireLogin() : await getCurrentUser();
  } catch {
    /* server unreachable: still render the page */
  }
  renderNav(user);
  return user;
}
