import { api, el, $, initPage, formatDate, rules, setFieldErrors, showMessage } from './common.js';

let user = await initPage({ requireAuth: true });
if (!user) throw new Error('redirecting to login');

const details = $('#details');
const profileForm = $('#profile-form');
const passwordForm = $('#password-form');

function drawDetails(current, noteCount) {
  details.replaceChildren(
    el('p', {}, el('strong', { text: 'Email: ' }), current.email),
    el('p', {}, el('strong', { text: 'Role: ' }), el('span', { class: current.role === 'admin' ? 'badge badge-admin' : 'badge', text: current.role })),
    el('p', {}, el('strong', { text: 'Member since: ' }), formatDate(current.created_at)),
    noteCount !== undefined ? el('p', {}, el('strong', { text: 'Notes saved: ' }), String(noteCount)) : null
  );
  profileForm.name.value = current.name;
}

const profile = await api('/user/profile');
drawDetails(profile.user, profile.noteCount);

profileForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const box = $('#profile-message');
  showMessage(box, '');
  const name = profileForm.name.value;
  const errors = { name: rules.name(name) };
  setFieldErrors(profileForm, errors);
  if (errors.name) return;

  try {
    const res = await api('/user/profile', { method: 'PUT', body: { name } });
    drawDetails(res.user, profile.noteCount);
    showMessage(box, res.message, 'success');
  } catch (err) {
    if (err.details) setFieldErrors(profileForm, err.details);
    showMessage(box, err.message);
  }
});

passwordForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const box = $('#password-message');
  showMessage(box, '');
  const { currentPassword, newPassword } = Object.fromEntries(new FormData(passwordForm));
  const errors = {
    currentPassword: currentPassword ? '' : 'Current password is required',
    newPassword: rules.password(newPassword),
  };
  setFieldErrors(passwordForm, errors);
  if (Object.values(errors).some(Boolean)) return;

  try {
    const res = await api('/user/password', { method: 'PUT', body: { currentPassword, newPassword } });
    passwordForm.reset();
    showMessage(box, res.message, 'success');
  } catch (err) {
    if (err.details) setFieldErrors(passwordForm, err.details);
    showMessage(box, err.message);
  }
});
