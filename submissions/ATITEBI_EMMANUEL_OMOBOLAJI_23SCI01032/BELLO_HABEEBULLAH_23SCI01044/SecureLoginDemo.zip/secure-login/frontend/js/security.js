import { api, initPage, $ } from './common.js';

await initPage();

function show(id, text) {
  const box = $(id);
  box.textContent = text; // textContent: output can never execute as HTML
  box.classList.remove('hidden');
}

$('#demo-sqli').addEventListener('click', async () => {
  const payload = { email: "' OR '1'='1' --", password: "' OR '1'='1" };
  try {
    await api('/auth/login', { method: 'POST', body: payload });
    show('#out-sqli', 'UNEXPECTED: login succeeded');
  } catch (err) {
    show('#out-sqli', `Sent:     ${JSON.stringify(payload)}\nResponse: HTTP ${err.status} - ${err.message}\nResult:   Attack blocked. The input was treated as plain text.`);
  }
});

$('#demo-auth').addEventListener('click', async () => {
  try {
    await api('/admin/users');
    show('#out-auth', 'You are logged in as an admin, so this request is allowed.\nLog out (or use a normal user) to see it blocked.');
  } catch (err) {
    show('#out-auth', `GET /api/admin/users\nResponse: HTTP ${err.status} - ${err.message}\nResult:   ${err.status === 401 ? 'Blocked: authentication required.' : 'Blocked: admin role required.'}`);
  }
});

$('#demo-xss').addEventListener('click', () => {
  const payload = '<img src=x onerror="alert(document.cookie)">';
  show('#out-xss', `Malicious input:\n${payload}\n\nRendered via textContent as plain text above. It is not parsed as HTML, so no script runs.\nEven if it were injected, the Content-Security-Policy would block inline scripts, and the session cookie is HttpOnly so scripts cannot read it.`);
});
