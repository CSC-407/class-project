import { api, $, initPage, rules, passwordStrength, setFieldErrors, showMessage } from './common.js';

const user = await initPage();
if (user) window.location.replace('dashboard.html');

const form = $('#register-form');
const message = $('#message');
const submit = $('#submit');
const strength = $('#strength');

form.password.addEventListener('input', () => {
  const level = passwordStrength(form.password.value);
  strength.dataset.level = String(level);
  strength.firstElementChild.style.width = `${level * 20}%`;
});

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  showMessage(message, '');

  const values = Object.fromEntries(new FormData(form));
  const errors = {
    name: rules.name(values.name),
    email: rules.email(values.email),
    password: rules.password(values.password),
    confirm: values.password === values.confirm ? '' : 'Passwords do not match',
  };
  setFieldErrors(form, errors);
  if (Object.values(errors).some(Boolean)) return;

  submit.disabled = true;
  try {
    await api('/auth/register', {
      method: 'POST',
      body: { name: values.name, email: values.email, password: values.password },
    });
    window.location.href = 'login.html?msg=registered';
  } catch (err) {
    if (err.details) setFieldErrors(form, err.details);
    showMessage(message, err.message);
  } finally {
    submit.disabled = false;
  }
});
