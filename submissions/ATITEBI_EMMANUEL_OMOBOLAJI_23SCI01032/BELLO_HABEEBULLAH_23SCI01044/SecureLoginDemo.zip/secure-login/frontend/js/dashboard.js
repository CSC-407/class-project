import { api, el, $, initPage, formatDate, setFieldErrors, showMessage } from './common.js';

const user = await initPage({ requireAuth: true });
if (!user) throw new Error('redirecting to login');

$('#welcome').textContent = `Welcome, ${user.name}`;
$('#role-line').replaceChildren(
  'Signed in as ',
  el('strong', { text: user.email }),
  ' · role: ',
  el('span', { class: user.role === 'admin' ? 'badge badge-admin' : 'badge', text: user.role })
);

const notesBox = $('#notes');
const form = $('#note-form');
const message = $('#note-message');
const search = $('#search');

async function loadNotes() {
  try {
    const { notes } = await api('/user/notes?search=' + encodeURIComponent(search.value.trim()));
    if (!notes.length) {
      notesBox.replaceChildren(el('p', { class: 'muted', text: search.value ? 'No notes match your search.' : 'No notes yet. Add your first one above.' }));
      return;
    }
    notesBox.replaceChildren(
      ...notes.map((n) =>
        el(
          'div',
          { class: 'note' },
          el('div', {}, el('h3', { text: n.title }), n.body ? el('p', { text: n.body }) : null, el('small', { text: formatDate(n.created_at) })),
          el('button', {
            class: 'btn btn-danger btn-small',
            type: 'button',
            text: 'Delete',
            'aria-label': `Delete note ${n.title}`,
            onclick: async () => {
              try {
                await api(`/user/notes/${n.id}`, { method: 'DELETE' });
                await loadNotes();
              } catch (err) {
                showMessage(message, err.message);
              }
            },
          })
        )
      )
    );
  } catch (err) {
    if (err.status === 401) window.location.replace('login.html');
    notesBox.replaceChildren(el('div', { class: 'alert alert-error', text: err.message }));
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  showMessage(message, '');
  const { title, body } = Object.fromEntries(new FormData(form));
  const errors = { title: title.trim() ? '' : 'Title is required' };
  setFieldErrors(form, errors);
  if (errors.title) return;

  try {
    await api('/user/notes', { method: 'POST', body: { title, body } });
    form.reset();
    showMessage(message, 'Note saved.', 'success');
    await loadNotes();
  } catch (err) {
    if (err.details) setFieldErrors(form, err.details);
    showMessage(message, err.message);
  }
});

let timer;
search.addEventListener('input', () => {
  clearTimeout(timer);
  timer = setTimeout(loadNotes, 250);
});

await loadNotes();
