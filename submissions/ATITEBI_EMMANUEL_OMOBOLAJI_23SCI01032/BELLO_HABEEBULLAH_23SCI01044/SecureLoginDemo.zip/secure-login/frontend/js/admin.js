import { api, el, $, initPage, formatDate, showMessage } from './common.js';

const me = await initPage({ requireAuth: true });
if (!me) throw new Error('redirecting to login');

const message = $('#admin-message');
const content = $('#admin-content');
const usersBody = $('#users');
const search = $('#search');
const roleFilter = $('#role-filter');

// The server is the real gatekeeper (403 for non-admins). This check only improves the UX.
if (me.role !== 'admin') {
  content.classList.add('hidden');
  try {
    await api('/admin/users'); // demonstrates the server-side access-control check
  } catch (err) {
    showMessage(message, `Access denied (${err.status}): ${err.message}`);
  }
  throw new Error('not an admin');
}

async function loadStats() {
  const s = await api('/admin/stats');
  const stat = (num, label) => el('div', { class: 'stat' }, el('div', { class: 'num', text: String(num) }), el('div', { class: 'label', text: label }));
  $('#stats').replaceChildren(
    stat(s.users, 'Total users'),
    stat(s.admins, 'Admins'),
    stat(s.successfulLogins, 'Successful logins'),
    stat(s.failedLogins, 'Failed logins'),
    stat(s.accessDenied, 'Access denied')
  );
}

async function loadUsers() {
  const query = new URLSearchParams({ search: search.value.trim(), role: roleFilter.value });
  const { users } = await api('/admin/users?' + query);

  if (!users.length) {
    usersBody.replaceChildren(el('tr', {}, el('td', { colspan: '5', class: 'muted', text: 'No users match.' })));
    return;
  }

  usersBody.replaceChildren(
    ...users.map((u) => {
      const isSelf = u.id === me.id;
      const select = el(
        'select',
        {
          'aria-label': `Role for ${u.name}`,
          disabled: isSelf,
          onchange: async (e) => {
            try {
              await api(`/admin/users/${u.id}/role`, { method: 'PUT', body: { role: e.target.value } });
              showMessage(message, `Role updated for ${u.name}.`, 'success');
              await refresh();
            } catch (err) {
              showMessage(message, err.message);
              await refresh();
            }
          },
        },
        el('option', { value: 'user', text: 'user', selected: u.role === 'user' }),
        el('option', { value: 'admin', text: 'admin', selected: u.role === 'admin' })
      );

      return el(
        'tr',
        {},
        el('td', { text: u.name }),
        el('td', { text: u.email }),
        el('td', {}, select),
        el('td', { text: formatDate(u.created_at) }),
        el('td', {}, isSelf
          ? el('span', { class: 'muted', text: 'You' })
          : el('button', {
              class: 'btn btn-danger btn-small',
              type: 'button',
              text: 'Delete',
              'aria-label': `Delete ${u.name}`,
              onclick: async () => {
                if (!window.confirm(`Delete ${u.name} and all their data?`)) return;
                try {
                  await api(`/admin/users/${u.id}`, { method: 'DELETE' });
                  showMessage(message, `${u.name} was deleted.`, 'success');
                  await refresh();
                } catch (err) {
                  showMessage(message, err.message);
                }
              },
            }))
      );
    })
  );
}

async function loadAudit() {
  const { events } = await api('/admin/audit');
  $('#audit').replaceChildren(
    ...events.map((e) =>
      el('tr', {}, el('td', { text: formatDate(e.created_at) }), el('td', {}, el('code', { text: e.event })), el('td', { text: e.user_email || '-' }), el('td', { text: e.ip || '-' }), el('td', { text: e.detail || '' }))
    )
  );
}

async function refresh() {
  try {
    await Promise.all([loadStats(), loadUsers(), loadAudit()]);
  } catch (err) {
    showMessage(message, err.message);
  }
}

let timer;
const debounced = () => {
  clearTimeout(timer);
  timer = setTimeout(loadUsers, 250);
};
search.addEventListener('input', debounced);
roleFilter.addEventListener('change', loadUsers);

await refresh();
