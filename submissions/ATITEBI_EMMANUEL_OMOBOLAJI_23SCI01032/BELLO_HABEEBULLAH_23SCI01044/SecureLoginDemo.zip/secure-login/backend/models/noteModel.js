import db from '../config/db.js';

db.exec(`
  CREATE TABLE IF NOT EXISTS notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title      TEXT    NOT NULL,
    body       TEXT    NOT NULL DEFAULT '',
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  )
`);

const likeEscape = (s) => s.replace(/[\\%_]/g, (c) => '\\' + c);

// Every query is scoped by user_id, so one user can never read or delete
// another user's notes even if they guess an ID (access control at data level).
export const NoteModel = {
  create({ userId, title, body }) {
    const info = db
      .prepare('INSERT INTO notes (user_id, title, body) VALUES (?, ?, ?)')
      .run(userId, title, body);
    return db.prepare('SELECT * FROM notes WHERE id = ?').get(info.lastInsertRowid);
  },

  listForUser(userId, search = '') {
    const like = `%${likeEscape(search)}%`;
    return db
      .prepare(
        `SELECT id, title, body, created_at FROM notes
         WHERE user_id = ? AND (title LIKE ? ESCAPE '\\' OR body LIKE ? ESCAPE '\\')
         ORDER BY created_at DESC, id DESC`
      )
      .all(userId, like, like);
  },

  countForUser(userId) {
    return db.prepare('SELECT COUNT(*) AS n FROM notes WHERE user_id = ?').get(userId).n;
  },

  removeForUser(id, userId) {
    return db.prepare('DELETE FROM notes WHERE id = ? AND user_id = ?').run(id, userId).changes > 0;
  },
};
