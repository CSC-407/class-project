import db from '../config/db.js';

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT    NOT NULL,
    email           TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    password_hash   TEXT    NOT NULL,
    role            TEXT    NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until    INTEGER,
    created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
  )
`);

// Never return password_hash or lockout internals to clients.
const PUBLIC_COLUMNS = 'id, name, email, role, created_at';

// Escape LIKE wildcards so a search for "%" is treated literally.
const likeEscape = (s) => s.replace(/[\\%_]/g, (c) => '\\' + c);

// All queries use parameter placeholders (?), never string concatenation.
// This is the core defence against SQL injection.
export const UserModel = {
  create({ name, email, passwordHash, role = 'user' }) {
    const info = db
      .prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)')
      .run(name, email, passwordHash, role);
    return this.findById(info.lastInsertRowid);
  },

  findById(id) {
    return db.prepare(`SELECT ${PUBLIC_COLUMNS} FROM users WHERE id = ?`).get(id);
  },

  // Includes the hash and lockout fields: only used by the login/password flow.
  findAuthByEmail(email) {
    return db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  },

  findAuthById(id) {
    return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  },

  list({ search = '', role = '' } = {}) {
    const like = `%${likeEscape(search)}%`;
    return db
      .prepare(
        `SELECT ${PUBLIC_COLUMNS} FROM users
         WHERE (name LIKE ? ESCAPE '\\' OR email LIKE ? ESCAPE '\\')
           AND (? = '' OR role = ?)
         ORDER BY created_at DESC, id DESC`
      )
      .all(like, like, role, role);
  },

  count() {
    return db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  },

  updateName(id, name) {
    db.prepare('UPDATE users SET name = ? WHERE id = ?').run(name, id);
    return this.findById(id);
  },

  updatePassword(id, passwordHash) {
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(passwordHash, id);
  },

  updateRole(id, role) {
    db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);
    return this.findById(id);
  },

  remove(id) {
    return db.prepare('DELETE FROM users WHERE id = ?').run(id).changes > 0;
  },

  recordFailedLogin(id, maxAttempts, lockMs) {
    const user = this.findAuthById(id);
    const attempts = user.failed_attempts + 1;
    const lockedUntil = attempts >= maxAttempts ? Date.now() + lockMs : null;
    db.prepare('UPDATE users SET failed_attempts = ?, locked_until = ? WHERE id = ?').run(
      lockedUntil ? 0 : attempts,
      lockedUntil,
      id
    );
    return { locked: Boolean(lockedUntil) };
  },

  resetFailedLogins(id) {
    db.prepare('UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = ?').run(id);
  },
};
