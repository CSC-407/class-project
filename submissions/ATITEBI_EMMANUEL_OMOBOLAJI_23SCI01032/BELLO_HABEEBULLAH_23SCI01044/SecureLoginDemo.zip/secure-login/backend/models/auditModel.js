import db from '../config/db.js';

// Security audit trail: who did what, from where, and when.
db.exec(`
  CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER,
    event      TEXT    NOT NULL,
    ip         TEXT,
    detail     TEXT,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  )
`);

export const AuditModel = {
  add({ userId = null, event, ip = null, detail = null }) {
    db.prepare('INSERT INTO audit_log (user_id, event, ip, detail) VALUES (?, ?, ?, ?)').run(
      userId,
      event,
      ip,
      detail ? String(detail).slice(0, 255) : null
    );
  },

  recent(limit = 50) {
    return db
      .prepare(
        `SELECT a.id, a.event, a.ip, a.detail, a.created_at, u.email AS user_email
         FROM audit_log a LEFT JOIN users u ON u.id = a.user_id
         ORDER BY a.id DESC LIMIT ?`
      )
      .all(limit);
  },

  countByEvent(event) {
    return db.prepare('SELECT COUNT(*) AS n FROM audit_log WHERE event = ?').get(event).n;
  },
};
