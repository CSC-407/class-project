import db from '../config/db.js';

// Server-side sessions: each login creates a row. Logging out deletes it,
// so a stolen token stops working immediately (unlike a plain stateless JWT).
db.exec(`
  CREATE TABLE IF NOT EXISTS sessions (
    id         TEXT    PRIMARY KEY,
    user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL,
    user_agent TEXT,
    created_at TEXT    NOT NULL DEFAULT (datetime('now'))
  )
`);

export const SessionModel = {
  create({ id, userId, expiresAt, userAgent }) {
    db.prepare('INSERT INTO sessions (id, user_id, expires_at, user_agent) VALUES (?, ?, ?, ?)').run(
      id,
      userId,
      expiresAt,
      (userAgent || '').slice(0, 255)
    );
  },

  find(id) {
    return db.prepare('SELECT * FROM sessions WHERE id = ?').get(id);
  },

  remove(id) {
    db.prepare('DELETE FROM sessions WHERE id = ?').run(id);
  },

  removeAllForUser(userId, exceptId = null) {
    db.prepare('DELETE FROM sessions WHERE user_id = ? AND id IS NOT ?').run(userId, exceptId);
  },

  purgeExpired() {
    return db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now()).changes;
  },
};
