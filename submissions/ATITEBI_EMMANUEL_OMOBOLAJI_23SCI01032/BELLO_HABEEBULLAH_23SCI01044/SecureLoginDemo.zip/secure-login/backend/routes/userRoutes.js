import { Router } from 'express';
import { getProfile, updateProfile, changePassword } from '../controllers/userController.js';
import { createNote, listNotes, deleteNote } from '../controllers/noteController.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

// Every route below requires a logged-in user.
router.use(authenticate);

router.get('/profile', getProfile);
router.put('/profile', updateProfile);
router.put('/password', changePassword);

router.get('/notes', listNotes);
router.post('/notes', createNote);
router.delete('/notes/:id', deleteNote);

export default router;
