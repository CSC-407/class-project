import { Router } from 'express';
import {
  listUsers,
  updateRole,
  deleteUser,
  getAuditLog,
  getStats,
} from '../controllers/adminController.js';
import { authenticate, requireRole } from '../middleware/auth.js';

const router = Router();

// Logged in AND admin role, checked on every request.
router.use(authenticate, requireRole('admin'));

router.get('/users', listUsers);
router.put('/users/:id/role', updateRole);
router.delete('/users/:id', deleteUser);
router.get('/audit', getAuditLog);
router.get('/stats', getStats);

export default router;
