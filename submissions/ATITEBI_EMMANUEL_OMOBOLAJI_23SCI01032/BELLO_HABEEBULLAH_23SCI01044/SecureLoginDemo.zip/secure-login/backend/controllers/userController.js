import bcrypt from 'bcryptjs';
import { UserModel } from '../models/userModel.js';
import { SessionModel } from '../models/sessionModel.js';
import { AuditModel } from '../models/auditModel.js';
import { NoteModel } from '../models/noteModel.js';
import { cleanString, validateName, validatePassword, collectErrors } from '../utils/validators.js';

const rounds = () => Number(process.env.BCRYPT_ROUNDS) || 12;

export function getProfile(req, res) {
  res.json({ user: req.user, noteCount: NoteModel.countForUser(req.user.id) });
}

export function updateProfile(req, res) {
  const name = cleanString(req.body?.name);
  const error = validateName(name);
  if (error) {
    return res.status(400).json({ error: 'Please fix the highlighted fields', details: { name: error } });
  }
  const user = UserModel.updateName(req.user.id, name);
  res.json({ message: 'Profile updated', user });
}

export async function changePassword(req, res, next) {
  try {
    const { currentPassword, newPassword } = req.body || {};
    const errors = collectErrors({
      newPassword: validatePassword(newPassword),
      currentPassword: typeof currentPassword === 'string' && currentPassword ? null : 'Current password is required',
    });
    if (Object.keys(errors).length) {
      return res.status(400).json({ error: 'Please fix the highlighted fields', details: errors });
    }

    const user = UserModel.findAuthById(req.user.id);
    if (!(await bcrypt.compare(currentPassword, user.password_hash))) {
      return res.status(400).json({
        error: 'Please fix the highlighted fields',
        details: { currentPassword: 'Current password is incorrect' },
      });
    }

    UserModel.updatePassword(user.id, await bcrypt.hash(newPassword, rounds()));
    // Sign out every other device after a password change.
    SessionModel.removeAllForUser(user.id, req.sessionId);
    AuditModel.add({ userId: user.id, event: 'password_changed', ip: req.ip });

    res.json({ message: 'Password changed. Other devices have been signed out.' });
  } catch (err) {
    next(err);
  }
}
