import { NoteModel } from '../models/noteModel.js';
import { cleanString, validateNote } from '../utils/validators.js';

export function createNote(req, res) {
  // Notes may contain any text (including "<script>"). We store it as-is and the
  // frontend renders it with textContent, so it is displayed as text, never executed.
  const title = cleanString(req.body?.title);
  const body = typeof req.body?.body === 'string' ? req.body.body.trim() : '';

  const errors = validateNote({ title, body });
  if (Object.keys(errors).length) {
    return res.status(400).json({ error: 'Please fix the highlighted fields', details: errors });
  }

  const note = NoteModel.create({ userId: req.user.id, title, body });
  res.status(201).json({ note });
}

export function listNotes(req, res) {
  const search = cleanString(req.query.search).slice(0, 100);
  res.json({ notes: NoteModel.listForUser(req.user.id, search) });
}

export function deleteNote(req, res) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) {
    return res.status(400).json({ error: 'Invalid note id' });
  }
  // Returns false if the note does not exist OR belongs to someone else.
  if (!NoteModel.removeForUser(id, req.user.id)) {
    return res.status(404).json({ error: 'Note not found' });
  }
  res.json({ message: 'Note deleted' });
}
