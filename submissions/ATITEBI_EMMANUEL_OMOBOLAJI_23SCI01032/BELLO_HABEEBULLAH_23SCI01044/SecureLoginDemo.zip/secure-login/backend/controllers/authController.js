import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { UserModel } from '../models/userModel.js';
import { SessionModel } from '../models/sessionModel.js';
import { AuditModel } from '../models/auditModel.js';
import { COOKIE_NAME } from '../middleware/auth.js';
import {
  cleanString,
  normalizeEmail,
  validateName,
  validateEmail,
  validatePassword,
  collectErrors,
} from '../utils/validators.js';

const MAX_FAILED_ATTEMPTS = 5;
const LOCK_MS = 15 * 60 * 1000;

const rounds = () => Number(process.env.BCRYPT_ROUNDS) || 12;
const sessionMs = () => (Number(process.env.SESSION_HOURS) || 1) * 60 * 60 * 1000;

// Used to make "unknown email" take as long as "wrong password" (timing-attack defence).
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing', 4);

function cookieOptions() {
  return {
    httpOnly: true, // JavaScript cannot read it, so XSS cannot steal it
    sameSite: 'strict', // not sent on cross-site requests (CSRF defence)
    secure: process.env.NODE_ENV === 'production', // HTTPS only in production
    maxAge: sessionMs(),
    path: '/',
  };
}

export async function register(req, res, next) {
  try {
    // Only pick the fields we expect. A "role" field in the body is ignored,
    // so nobody can register themselves as an admin (mass-assignment defence).
    const name = cleanString(req.body?.name);
    const email = normalizeEmail(req.body?.email);
    const password = req.body?.password;

    const errors = collectErrors({
      name: validateName(name),
      email: validateEmail(email),
      password: validatePassword(password),
    });
    if (Object.keys(errors).length) {
      return res.status(400).json({ error: 'Please fix the highlighted fields', details: errors });
    }

    if (UserModel.findAuthByEmail(email)) {
      return res.status(409).json({
        error: 'Please fix the highlighted fields',
        details: { email: 'An account with this email already exists' },
      });
    }

    const passwordHash = await bcrypt.hash(password, rounds());
    const user = UserModel.create({ name, email, passwordHash });

    AuditModel.add({ userId: user.id, event: 'register', ip: req.ip });
    res.status(201).json({ message: 'Account created', user });
  } catch (err) {
    next(err);
  }
}

export async function login(req, res, next) {
  try {
    const email = normalizeEmail(req.body?.email);
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = UserModel.findAuthByEmail(email);

    if (!user) {
      await bcrypt.compare(password, DUMMY_HASH);
      AuditModel.add({ event: 'login_failed', ip: req.ip, detail: 'unknown email' });
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    if (user.locked_until && user.locked_until > Date.now()) {
      AuditModel.add({ userId: user.id, event: 'login_blocked', ip: req.ip, detail: 'account locked' });
      return res
        .status(423)
        .json({ error: 'Too many failed attempts. Account locked for 15 minutes.' });
    }

    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      const { locked } = UserModel.recordFailedLogin(user.id, MAX_FAILED_ATTEMPTS, LOCK_MS);
      AuditModel.add({
        userId: user.id,
        event: locked ? 'account_locked' : 'login_failed',
        ip: req.ip,
        detail: 'wrong password',
      });
      // Same message as unknown email: do not reveal which part was wrong.
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    UserModel.resetFailedLogins(user.id);
    SessionModel.purgeExpired();

    const jti = crypto.randomUUID();
    SessionModel.create({
      id: jti,
      userId: user.id,
      expiresAt: Date.now() + sessionMs(),
      userAgent: req.get('user-agent'),
    });

    const token = jwt.sign({ sub: user.id, jti }, process.env.JWT_SECRET, {
      algorithm: 'HS256',
      expiresIn: Math.floor(sessionMs() / 1000),
    });

    res.cookie(COOKIE_NAME, token, cookieOptions());
    AuditModel.add({ userId: user.id, event: 'login_success', ip: req.ip });

    res.json({
      message: 'Logged in',
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    });
  } catch (err) {
    next(err);
  }
}

export function logout(req, res) {
  SessionModel.remove(req.sessionId);
  AuditModel.add({ userId: req.user.id, event: 'logout', ip: req.ip });
  const { maxAge, ...clearOptions } = cookieOptions();
  res.clearCookie(COOKIE_NAME, clearOptions);
  res.json({ message: 'Logged out' });
}

export function me(req, res) {
  res.json({ user: req.user });
}
