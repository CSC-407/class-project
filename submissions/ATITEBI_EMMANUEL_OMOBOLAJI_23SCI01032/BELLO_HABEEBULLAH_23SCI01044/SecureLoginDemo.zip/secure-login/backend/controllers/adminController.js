import { UserModel } from '../models/userModel.js';
import { SessionModel } from '../models/sessionModel.js';
import { AuditModel } from '../models/auditModel.js';
import { cleanString } from '../utils/validators.js';

export function listUsers(req, res) {
  const search = cleanString(req.query.search).slice(0, 100);
  const role = ['user', 'admin'].includes(req.query.role) ? req.query.role : '';
  res.json({ users: UserModel.list({ search, role }) });
}

export function updateRole(req, res) {
  const id = Number(req.params.id);
  const role = req.body?.role;

  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid user id' });
  if (!['user', 'admin'].includes(role)) return res.status(400).json({ error: 'Role must be "user" or "admin"' });
  if (id === req.user.id) return res.status(400).json({ error: 'You cannot change your own role' });
  if (!UserModel.findById(id)) return res.status(404).json({ error: 'User not found' });

  const user = UserModel.updateRole(id, role);
  AuditModel.add({ userId: req.user.id, event: 'role_changed', ip: req.ip, detail: `user ${id} -> ${role}` });
  res.json({ message: 'Role updated', user });
}

export function deleteUser(req, res) {
  const id = Number(req.params.id);

  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid user id' });
  if (id === req.user.id) return res.status(400).json({ error: 'You cannot delete your own account' });

  SessionModel.removeAllForUser(id);
  if (!UserModel.remove(id)) return res.status(404).json({ error: 'User not found' });

  AuditModel.add({ userId: req.user.id, event: 'user_deleted', ip: req.ip, detail: `user ${id}` });
  res.json({ message: 'User deleted' });
}

export function getAuditLog(req, res) {
  res.json({ events: AuditModel.recent(50) });
}

export function getStats(req, res) {
  res.json({
    users: UserModel.count(),
    admins: UserModel.list({ role: 'admin' }).length,
    successfulLogins: AuditModel.countByEvent('login_success'),
    failedLogins: AuditModel.countByEvent('login_failed') + AuditModel.countByEvent('account_locked'),
    accessDenied: AuditModel.countByEvent('access_denied'),
  });
}
