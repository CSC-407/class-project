import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

// Test configuration must be set BEFORE the app is imported.
process.env.NODE_ENV = 'test';
process.env.DB_PATH = ':memory:';
process.env.JWT_SECRET = 'test-secret-test-secret-test-secret-123456';
process.env.BCRYPT_ROUNDS = '4';
process.env.LOGIN_RATE_MAX = '1000';
process.env.API_RATE_MAX = '100000';
process.env.ADMIN_EMAIL = 'admin@test.local';
process.env.ADMIN_PASSWORD = 'Admin@12345';

const { default: app } = await import('../server.js');
const { seedAdmin } = await import('../config/seed.js');

let server;
let base;

before(async () => {
  await seedAdmin();
  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => server.close());

// Minimal HTTP client that keeps cookies, like a browser would.
class Client {
  cookie = '';

  async request(method, path, body, { csrf = true } = {}) {
    const headers = {};
    if (csrf) headers['X-Requested-With'] = 'XMLHttpRequest';
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (this.cookie) headers.Cookie = this.cookie;

    const res = await fetch(base + path, {
      method,
      headers,
      body: typeof body === 'string' ? body : body !== undefined ? JSON.stringify(body) : undefined,
    });

    const setCookie = res.headers.get('set-cookie');
    if (setCookie) this.cookie = setCookie.split(';')[0].endsWith('=') ? '' : setCookie.split(';')[0];

    let data = null;
    try {
      data = await res.json();
    } catch {
      /* not JSON */
    }
    return { status: res.status, data, headers: res.headers, setCookie };
  }
  get = (p, o) => this.request('GET', p, undefined, o);
  post = (p, b, o) => this.request('POST', p, b, o);
  put = (p, b, o) => this.request('PUT', p, b, o);
  del = (p, o) => this.request('DELETE', p, undefined, o);
}

const strong = 'Str0ng!Pass';
let counter = 0;
const newUser = (overrides = {}) => ({
  name: 'Test User',
  email: `user${++counter}@test.local`,
  password: strong,
  ...overrides,
});

async function registerAndLogin(overrides) {
  const user = newUser(overrides);
  const c = new Client();
  await c.post('/api/auth/register', user);
  const res = await c.post('/api/auth/login', { email: user.email, password: user.password });
  return { c, user, res };
}

// ---------- Registration ----------

test('REG-01 valid registration succeeds and never returns the password hash', async () => {
  const res = await new Client().post('/api/auth/register', newUser());
  assert.equal(res.status, 201);
  assert.equal(res.data.user.role, 'user');
  assert.equal(res.data.user.password_hash, undefined);
});

test('REG-02 empty fields are rejected with field errors', async () => {
  const res = await new Client().post('/api/auth/register', { name: '', email: '', password: '' });
  assert.equal(res.status, 400);
  assert.ok(res.data.details.name && res.data.details.email && res.data.details.password);
});

test('REG-03 invalid email format is rejected', async () => {
  const res = await new Client().post('/api/auth/register', newUser({ email: 'not-an-email' }));
  assert.equal(res.status, 400);
  assert.ok(res.data.details.email);
});

test('REG-04 weak password is rejected', async () => {
  for (const password of ['short1!', 'alllowercase1!', 'NoDigits!!', 'NoSpecial123']) {
    const res = await new Client().post('/api/auth/register', newUser({ password }));
    assert.equal(res.status, 400, `should reject ${password}`);
    assert.ok(res.data.details.password);
  }
});

test('REG-05 duplicate email is rejected (case-insensitive)', async () => {
  const user = newUser({ email: 'dupe@test.local' });
  await new Client().post('/api/auth/register', user);
  const res = await new Client().post('/api/auth/register', { ...user, email: 'DUPE@test.local' });
  assert.equal(res.status, 409);
});

test('REG-06 cannot register as admin by sending a role field', async () => {
  const res = await new Client().post('/api/auth/register', { ...newUser(), role: 'admin' });
  assert.equal(res.status, 201);
  assert.equal(res.data.user.role, 'user');
});

// ---------- Login / sessions ----------

test('LOG-01 valid login sets an httpOnly, SameSite=Strict cookie', async () => {
  const { res } = await registerAndLogin();
  assert.equal(res.status, 200);
  assert.match(res.setCookie, /HttpOnly/i);
  assert.match(res.setCookie, /SameSite=Strict/i);
});

test('LOG-02 wrong password and unknown email give the same generic error', async () => {
  const user = newUser();
  const c = new Client();
  await c.post('/api/auth/register', user);
  const wrongPass = await c.post('/api/auth/login', { email: user.email, password: 'Wrong!Pass1' });
  const unknown = await c.post('/api/auth/login', { email: 'nobody@test.local', password: 'Wrong!Pass1' });
  assert.equal(wrongPass.status, 401);
  assert.equal(unknown.status, 401);
  assert.equal(wrongPass.data.error, unknown.data.error);
});

test('LOG-03 missing credentials return 400', async () => {
  const res = await new Client().post('/api/auth/login', { email: '', password: '' });
  assert.equal(res.status, 400);
});

test('LOG-04 account locks after 5 failed attempts, even with the right password', async () => {
  const user = newUser();
  const c = new Client();
  await c.post('/api/auth/register', user);
  for (let i = 0; i < 5; i++) {
    await c.post('/api/auth/login', { email: user.email, password: 'Wrong!Pass1' });
  }
  const res = await c.post('/api/auth/login', { email: user.email, password: user.password });
  assert.equal(res.status, 423);
});

test('LOG-05 logout invalidates the session server-side', async () => {
  const { c } = await registerAndLogin();
  const stolenCookie = c.cookie;
  assert.equal((await c.get('/api/auth/me')).status, 200);

  assert.equal((await c.post('/api/auth/logout')).status, 200);

  const attacker = new Client();
  attacker.cookie = stolenCookie; // replay the old token
  assert.equal((await attacker.get('/api/auth/me')).status, 401);
});

test('LOG-06 a forged / tampered token is rejected', async () => {
  const { c } = await registerAndLogin();
  const tampered = new Client();
  tampered.cookie = c.cookie.slice(0, -3) + 'abc';
  assert.equal((await tampered.get('/api/auth/me')).status, 401);
});

// ---------- Access control ----------

test('ACC-01 protected routes return 401 without a session', async () => {
  const c = new Client();
  for (const path of ['/api/auth/me', '/api/user/profile', '/api/user/notes', '/api/admin/users']) {
    assert.equal((await c.get(path)).status, 401, path);
  }
});

test('ACC-02 normal user is denied admin routes (403)', async () => {
  const { c } = await registerAndLogin();
  assert.equal((await c.get('/api/admin/users')).status, 403);
  assert.equal((await c.get('/api/admin/audit')).status, 403);
  assert.equal((await c.put('/api/admin/users/1/role', { role: 'admin' })).status, 403);
});

test('ACC-03 admin can list users, search, filter and view the audit log', async () => {
  const admin = new Client();
  const login = await admin.post('/api/auth/login', { email: 'admin@test.local', password: 'Admin@12345' });
  assert.equal(login.status, 200);
  assert.equal(login.data.user.role, 'admin');

  const all = await admin.get('/api/admin/users');
  assert.equal(all.status, 200);
  assert.ok(all.data.users.length >= 1);
  assert.equal(all.data.users[0].password_hash, undefined);

  const admins = await admin.get('/api/admin/users?role=admin');
  assert.ok(admins.data.users.every((u) => u.role === 'admin'));

  const search = await admin.get('/api/admin/users?search=admin%40test');
  assert.equal(search.data.users.length, 1);

  assert.equal((await admin.get('/api/admin/audit')).status, 200);
  assert.equal((await admin.get('/api/admin/stats')).status, 200);
});

test('ACC-04 admin cannot demote or delete themselves', async () => {
  const admin = new Client();
  await admin.post('/api/auth/login', { email: 'admin@test.local', password: 'Admin@12345' });
  const me = (await admin.get('/api/auth/me')).data.user;
  assert.equal((await admin.put(`/api/admin/users/${me.id}/role`, { role: 'user' })).status, 400);
  assert.equal((await admin.del(`/api/admin/users/${me.id}`)).status, 400);
});

test('ACC-05 users cannot see or delete each other\'s notes', async () => {
  const a = (await registerAndLogin()).c;
  const b = (await registerAndLogin()).c;

  const created = await a.post('/api/user/notes', { title: 'Private', body: 'secret' });
  const noteId = created.data.note.id;

  assert.equal((await b.get('/api/user/notes')).data.notes.length, 0);
  assert.equal((await b.del(`/api/user/notes/${noteId}`)).status, 404);
  assert.equal((await a.get('/api/user/notes')).data.notes.length, 1);
});

// ---------- Injection / XSS / CSRF ----------

test('SEC-01 SQL injection in the login form does not bypass authentication', async () => {
  const c = new Client();
  const payloads = ["' OR '1'='1' --", "admin@test.local' --", "' OR 1=1; DROP TABLE users; --"];
  for (const email of payloads) {
    const res = await c.post('/api/auth/login', { email, password: "' OR '1'='1" });
    assert.ok([400, 401].includes(res.status), `payload ${email} gave ${res.status}`);
  }
  // Table still exists and admin can still log in.
  const ok = await new Client().post('/api/auth/login', { email: 'admin@test.local', password: 'Admin@12345' });
  assert.equal(ok.status, 200);
});

test('SEC-02 SQL injection in search parameters is treated as plain text', async () => {
  const { c } = await registerAndLogin();
  await c.post('/api/user/notes', { title: 'hello', body: 'world' });
  const res = await c.get("/api/user/notes?search=' OR '1'='1");
  assert.equal(res.status, 200);
  assert.equal(res.data.notes.length, 0);
});

test('SEC-03 XSS payload is stored as inert text and JSON is served with nosniff', async () => {
  const { c } = await registerAndLogin();
  const payload = '<script>alert(1)</script>';
  const created = await c.post('/api/user/notes', { title: 'xss', body: payload });
  assert.equal(created.status, 201);
  const list = await c.get('/api/user/notes');
  assert.equal(list.data.notes[0].body, payload); // raw text; the frontend renders it with textContent
  assert.match(list.headers.get('content-type'), /application\/json/);
  assert.equal(list.headers.get('x-content-type-options'), 'nosniff');
});

test('SEC-04 XSS payload in the name field is rejected by validation', async () => {
  const res = await new Client().post('/api/auth/register', newUser({ name: '<img src=x onerror=alert(1)>' }));
  assert.equal(res.status, 400);
  assert.ok(res.data.details.name);
});

test('SEC-05 security headers are present (CSP, frame blocking)', async () => {
  const res = await new Client().get('/api/auth/me');
  const csp = res.headers.get('content-security-policy');
  assert.match(csp, /script-src 'self'/);
  assert.match(csp, /frame-ancestors 'none'/);
  assert.equal(res.headers.get('x-powered-by'), null);
});

test('SEC-06 state-changing requests without the CSRF header are blocked', async () => {
  const res = await new Client().post('/api/auth/login', { email: 'a@b.co', password: 'x' }, { csrf: false });
  assert.equal(res.status, 403);
});

// ---------- Profile / password ----------

test('PRO-01 user can update their name; invalid names are rejected', async () => {
  const { c } = await registerAndLogin();
  const ok = await c.put('/api/user/profile', { name: 'New Name' });
  assert.equal(ok.status, 200);
  assert.equal(ok.data.user.name, 'New Name');
  assert.equal((await c.put('/api/user/profile', { name: '<b>' })).status, 400);
});

test('PRO-02 password change requires the current password and signs out other sessions', async () => {
  const { c, user } = await registerAndLogin();
  const other = new Client();
  await other.post('/api/auth/login', { email: user.email, password: user.password });
  assert.equal((await other.get('/api/auth/me')).status, 200);

  const bad = await c.put('/api/user/password', { currentPassword: 'Nope!Nope1', newPassword: 'N3w!Password' });
  assert.equal(bad.status, 400);

  const good = await c.put('/api/user/password', { currentPassword: user.password, newPassword: 'N3w!Password' });
  assert.equal(good.status, 200);

  assert.equal((await other.get('/api/auth/me')).status, 401); // other device signed out
  assert.equal((await c.get('/api/auth/me')).status, 200); // current device stays signed in

  const relogin = await new Client().post('/api/auth/login', { email: user.email, password: 'N3w!Password' });
  assert.equal(relogin.status, 200);
});

// ---------- Error handling ----------

test('ERR-01 malformed JSON returns a clean 400', async () => {
  const res = await new Client().post('/api/auth/login', '{bad json');
  assert.equal(res.status, 400);
  assert.equal(res.data.error, 'Malformed JSON in request body');
});

test('ERR-02 unknown API route returns JSON 404', async () => {
  const res = await new Client().get('/api/does-not-exist');
  assert.equal(res.status, 404);
});

test('ERR-03 oversized body is rejected', async () => {
  const res = await new Client().post('/api/auth/login', { email: 'a@b.co', password: 'x'.repeat(20000) });
  assert.equal(res.status, 413);
});

// ---------- Database ----------

test('DB-01 passwords are stored as bcrypt hashes, not plain text', async () => {
  const { default: db } = await import('../config/db.js');
  const row = db.prepare('SELECT password_hash FROM users WHERE email = ?').get('admin@test.local');
  assert.match(row.password_hash, /^\$2[aby]\$\d{2}\$/);
  assert.notEqual(row.password_hash, 'Admin@12345');
});

test('DB-02 deleting a user removes their notes and sessions (cascade)', async () => {
  const { c, user } = await registerAndLogin();
  await c.post('/api/user/notes', { title: 'bye', body: '' });
  const admin = new Client();
  await admin.post('/api/auth/login', { email: 'admin@test.local', password: 'Admin@12345' });
  const target = (await admin.get(`/api/admin/users?search=${encodeURIComponent(user.email)}`)).data.users[0];
  assert.equal((await admin.del(`/api/admin/users/${target.id}`)).status, 200);

  const { default: db } = await import('../config/db.js');
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM notes WHERE user_id = ?').get(target.id).n, 0);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM sessions WHERE user_id = ?').get(target.id).n, 0);
});
