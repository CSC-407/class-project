import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import './models/userModel.js';
import './models/sessionModel.js';
import './models/noteModel.js';
import './models/auditModel.js';

import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import { requireCsrfHeader } from './middleware/auth.js';
import { apiLimiter } from './middleware/rateLimit.js';
import { notFound, errorHandler } from './middleware/errorHandler.js';
import { seedAdmin } from './config/seed.js';

const isProd = process.env.NODE_ENV === 'production';
const isTest = process.env.NODE_ENV === 'test';

// Refuse to start with a missing or weak signing secret.
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
  console.error('JWT_SECRET is missing or too short (need 32+ characters). Check your .env file.');
  process.exit(1);
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const frontendDir = path.resolve(__dirname, process.env.FRONTEND_DIR || '../frontend');

const app = express();

if (process.env.TRUST_PROXY === '1') app.set('trust proxy', 1);

// Security headers: CSP (blocks injected scripts), HSTS, no-sniff, frame blocking, etc.
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        imgSrc: ["'self'", 'data:'],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        formAction: ["'self'"],
        baseUri: ["'self'"],
        upgradeInsecureRequests: isProd ? [] : null,
      },
    },
    strictTransportSecurity: isProd,
  })
);

app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());

// Mount the API.
app.use('/api', apiLimiter, requireCsrfHeader);
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', notFound);

// Serve the frontend from the same origin (keeps cookies simple and CSP strict).
app.use(express.static(frontendDir, { index: 'index.html' }));

app.use(errorHandler);

export default app;

if (!isTest) {
  const port = Number(process.env.PORT) || 5000;
  await seedAdmin();
  app.listen(port, () => {
    console.log(`Secure Login Demo running at http://localhost:${port}`);
  });
}
