import bcrypt from 'bcryptjs';
import { UserModel } from '../models/userModel.js';

// Creates the demo admin on first start so you can log in and show the admin features.
export async function seedAdmin() {
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';
  if (!email || !password) return;
  if (UserModel.findAuthByEmail(email)) return;

  const passwordHash = await bcrypt.hash(password, Number(process.env.BCRYPT_ROUNDS) || 12);
  UserModel.create({
    name: process.env.ADMIN_NAME || 'System Admin',
    email,
    passwordHash,
    role: 'admin',
  });
  console.log(`Seeded admin account: ${email}`);
}
