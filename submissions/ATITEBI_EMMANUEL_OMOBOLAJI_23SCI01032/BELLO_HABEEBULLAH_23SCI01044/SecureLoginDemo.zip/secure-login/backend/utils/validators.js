// Server-side input validation. Never trust the browser: client checks are only for UX.

const EMAIL_RE = /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[A-Za-z]{2,}$/;
const NAME_RE = /^[\p{L}\p{M}][\p{L}\p{M}' .-]{1,59}$/u;

export function cleanString(value) {
  // Trim and strip control characters (including null bytes).
  return typeof value === 'string' ? value.replace(/[\u0000-\u001F\u007F]/g, '').trim() : '';
}

export function normalizeEmail(value) {
  return cleanString(value).toLowerCase();
}

export function validateName(name) {
  if (!NAME_RE.test(name)) {
    return 'Name must be 2-60 characters: letters, spaces, apostrophes, dots or hyphens only';
  }
  return null;
}

export function validateEmail(email) {
  if (email.length > 254 || !EMAIL_RE.test(email)) return 'Enter a valid email address';
  return null;
}

export function validatePassword(password) {
  if (typeof password !== 'string') return 'Password is required';
  // bcrypt only uses the first 72 bytes, so cap the length.
  if (password.length < 8 || Buffer.byteLength(password) > 72) {
    return 'Password must be 8-72 characters';
  }
  if (!/[a-z]/.test(password)) return 'Password needs a lowercase letter';
  if (!/[A-Z]/.test(password)) return 'Password needs an uppercase letter';
  if (!/[0-9]/.test(password)) return 'Password needs a number';
  if (!/[^A-Za-z0-9]/.test(password)) return 'Password needs a special character';
  return null;
}

export function validateNote({ title, body }) {
  const errors = {};
  if (title.length < 1 || title.length > 100) errors.title = 'Title must be 1-100 characters';
  if (body.length > 1000) errors.body = 'Note must be 1000 characters or fewer';
  return errors;
}

// Collapse { field: message | null } into only the real errors.
export function collectErrors(map) {
  return Object.fromEntries(Object.entries(map).filter(([, msg]) => msg));
}
