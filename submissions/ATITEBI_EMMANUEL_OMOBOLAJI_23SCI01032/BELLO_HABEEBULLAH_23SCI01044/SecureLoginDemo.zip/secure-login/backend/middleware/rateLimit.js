import rateLimit from 'express-rate-limit';

const windowMs = 15 * 60 * 1000;

// Brute-force protection: limits login attempts per IP.
export const loginLimiter = rateLimit({
  windowMs,
  limit: () => Number(process.env.LOGIN_RATE_MAX) || 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts from this address. Try again in 15 minutes.' },
});

// General protection for the whole API.
export const apiLimiter = rateLimit({
  windowMs,
  limit: () => Number(process.env.API_RATE_MAX) || 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please slow down.' },
});
