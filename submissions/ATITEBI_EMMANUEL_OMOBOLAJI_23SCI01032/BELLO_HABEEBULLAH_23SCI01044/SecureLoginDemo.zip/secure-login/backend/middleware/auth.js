import jwt from 'jsonwebtoken';
import { SessionModel } from '../models/sessionModel.js';
import { UserModel } from '../models/userModel.js';
import { AuditModel } from '../models/auditModel.js';

export const COOKIE_NAME = 'token';

// 1. Authentication: valid signed JWT + a live server-side session + user still exists.
export function authenticate(req, res, next) {
  const token = req.cookies?.[COOKIE_NAME];
  if (!token) return res.status(401).json({ error: 'Authentication required' });

  let payload;
  try {
    // Pin the algorithm so an attacker cannot switch it (e.g. to "none").
    payload = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
  } catch {
    return res.status(401).json({ error: 'Session invalid or expired' });
  }

  const session = SessionModel.find(payload.jti);
  if (!session || session.expires_at < Date.now()) {
    return res.status(401).json({ error: 'Session invalid or expired' });
  }

  // Always load the role from the database, never trust the role inside the token.
  const user = UserModel.findById(payload.sub);
  if (!user) return res.status(401).json({ error: 'Session invalid or expired' });

  req.user = user;
  req.sessionId = payload.jti;
  next();
}

// 2. Authorization: role-based access control.
export const requireRole =
  (...roles) =>
  (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      AuditModel.add({
        userId: req.user.id,
        event: 'access_denied',
        ip: req.ip,
        detail: `${req.method} ${req.originalUrl}`,
      });
      return res.status(403).json({ error: 'You do not have permission to access this resource' });
    }
    next();
  };

// 3. CSRF defence (on top of SameSite=Strict cookies): state-changing requests must
// carry a custom header. Cross-site forms cannot set it, and cross-site fetch()
// would need a CORS preflight that this server never approves.
export function requireCsrfHeader(req, res, next) {
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    if (req.get('X-Requested-With') !== 'XMLHttpRequest') {
      return res.status(403).json({ error: 'Missing required request header' });
    }
  }
  next();
}
