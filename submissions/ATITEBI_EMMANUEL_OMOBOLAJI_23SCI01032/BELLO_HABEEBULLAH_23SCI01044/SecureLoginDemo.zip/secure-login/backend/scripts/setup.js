// Creates backend/.env from .env.example with a freshly generated random JWT secret.
// Run once with:  npm run setup
import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const target = path.join(root, '.env');

if (fs.existsSync(target)) {
  console.log('.env already exists, leaving it untouched.');
  process.exit(0);
}

const secret = crypto.randomBytes(48).toString('hex');
const content = fs
  .readFileSync(path.join(root, '.env.example'), 'utf8')
  .replace(/^JWT_SECRET=.*$/m, `JWT_SECRET=${secret}`);

fs.writeFileSync(target, content, { mode: 0o600 });
console.log('Created .env with a new random JWT_SECRET.');
console.log('Demo admin login: admin@example.com / Admin@12345 (change it in .env before deploying).');
