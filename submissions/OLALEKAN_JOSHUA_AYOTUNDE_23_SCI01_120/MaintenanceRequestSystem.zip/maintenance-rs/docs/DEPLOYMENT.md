# Deployment

This explains how the app moves from **development** (your laptop) to a **live environment** on the internet. The chosen host is **Render** (render.com), because it gives a free PostgreSQL database, free HTTPS, and deploys automatically from GitHub.

## 1. The three environments

| | Development | Test | Production (live) |
|---|---|---|---|
| Where | Your computer | Your computer / CI | Render |
| `NODE_ENV` | `development` | `test` | `production` |
| Database | `mrs` (local) | `mrs_test` (local, wiped by tests) | Render PostgreSQL |
| HTTPS | No (localhost) | No | Yes, forced |
| Cookies `Secure` | No | No | Yes |
| Error details | In the terminal | Hidden | In Render's log only |
| Demo data | Yes | Created by each test | No |

The **same code** runs everywhere. Only the environment variables change.

## 2. Environment variables

Settings and secrets are read from environment variables (`src/config.js`). Locally they come from a `.env` file; on Render they are set in the dashboard. The real `.env` is never put on GitHub (`.gitignore`).

| Variable | Example | Purpose |
|---|---|---|
| `NODE_ENV` | `production` | Turns on HTTPS redirect, secure cookies, HSTS |
| `PORT` | set by Render | Port the server listens on |
| `DATABASE_URL` | `postgres://user:pass@host:5432/mrs` | Database connection |
| `DATABASE_SSL` | `false` / `true` | `true` if the host needs SSL to the database |
| `SESSION_SECRET` | 64+ random characters | Signs session cookies; app will not start in production if under 32 |
| `SESSION_MAX_AGE_MINUTES` | `30` | Idle logout time |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME` | | First Admin account (`npm run seed`) |
| `SEED_DEMO` | `false` in production | Adds the demo user and sample requests |
| `SUPPORT_PHONE` | `+234 903 093 0463` | Shown in the header |

Make a strong secret with:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

## 3. Database configuration

- Tables are defined in `db/schema.sql`. Running `npm run migrate` creates them. It is safe to run again (`IF NOT EXISTS`). The server also runs it on start.
- The app connects with **one pool** of up to 10 connections (`src/db.js`).
- Use a database user that owns only this app's database, not the PostgreSQL superuser.
- On Render the app uses the **internal** database URL, so database traffic never leaves Render's private network.

## 4. Server configuration

- `npm start` runs `src/server.js`, which creates tables, then listens on `PORT`.
- `app.set('trust proxy', 1)`: Render's load balancer handles HTTPS and forwards to the app. This setting lets the app see that the visitor used HTTPS and their real IP address (needed for the rate limiter and the activity log).
- **Graceful shutdown:** on `SIGTERM` (sent by Render during a new deploy), the server stops taking new visitors, finishes current ones, and closes the database pool.
- **Health check:** `GET /health` returns `{"status":"ok"}`. Render calls it; if it fails, Render does not switch to the new version.
- Static files (CSS, JS, fonts) are cached by browsers for 7 days in production.

## 5. Deployment process (step by step)

### First time

1. **Put the code on GitHub**
   ```bash
   git init
   git add .
   git commit -m "Maintenance Request System"
   git branch -M main
   git remote add origin https://github.com/<you>/maintenance-rs.git
   git push -u origin main
   ```
2. **Create a Render account** at render.com and connect GitHub.
3. **New → Blueprint**, choose the repository. Render reads `render.yaml` and plans:
   - a PostgreSQL database `mrs-db`
   - a web service `maintenance-rs`
4. Render asks for the values marked `sync: false`: type your **ADMIN_EMAIL** and a strong **ADMIN_PASSWORD**. `SESSION_SECRET` is generated for you.
5. Click **Apply**. Render will:
   1. run `npm ci --omit=dev` (install exact package versions, no test tools)
   2. run `npm run migrate && npm run seed && npm start`
   3. check `/health`, then put the app live at `https://maintenance-rs.onrender.com` (the name may differ)
6. Open the link, log in as Admin, and check the padlock in the browser address bar.

### Every update after that

```
edit code → npm test → git commit → git push → Render builds and deploys automatically
```

If the tests fail, do not push. If a deploy fails its health check, Render keeps the old version running. You can also roll back to any earlier deploy from the Render dashboard.

## 6. Domain and hosting

- Render gives a free address: `https://<service-name>.onrender.com`.
- **Own domain** (e.g. `maintenance.yourestate.ng`): in Render → Settings → Custom Domains, add the domain, then at your domain seller add the `CNAME` record Render shows you. Render then issues the certificate automatically.
- **Free plan notes:** the web service sleeps after 15 minutes without visitors (the first visit after that takes about a minute), and the free database expires after 30 days. For real use, choose a paid plan for both.

## 7. HTTPS / SSL

- Render provides a free **Let's Encrypt** SSL certificate and renews it automatically.
- The app adds three more protections in production:
  1. **Redirect**: any `http://` request gets a 301 to `https://`.
  2. **HSTS**: browsers remember to use HTTPS for one year.
  3. **Secure cookies**: the session cookie is never sent over plain HTTP.

Checked by running the app with `NODE_ENV=production`:

```
http request  -> 301 https://mrs.example.com/login
https request -> Strict-Transport-Security: max-age=31536000; includeSubDomains
              -> Set-Cookie: mrs.sid=...; HttpOnly; Secure; SameSite=Lax
```

You can test the live site's HTTPS grade for free at **ssllabs.com/ssltest** and its headers at **securityheaders.com**. Add both results to the report.

## 8. Backup considerations

| What | How | How often |
|---|---|---|
| Automatic | Render paid databases take daily backups you can restore from the dashboard | Daily |
| Manual | `npm run backup` runs `pg_dump` and saves `backups/mrs-<date>.sql` (keeps the last 7) | Before every big change |
| Code | GitHub keeps every version of the code | Every push |

- Restore a manual backup: `psql "$DATABASE_URL" < backups/mrs-2026-10-18-1530.sql`
- Backups contain personal data and password hashes: the files are created readable by the owner only, `backups/` is in `.gitignore`, and copies should be kept somewhere private and encrypted (not on GitHub).
- **Test the restore** at least once, into a spare database, so you know the backups actually work.

## 9. Error and log monitoring

| What is recorded | Where to see it |
|---|---|
| Every visit (method, page, status, time) via `morgan` | Render → Logs |
| Server errors with full details (`[error]`) | Render → Logs (never shown to users) |
| Warnings like 403 and expired forms (`[warn]`) | Render → Logs |
| Crashes and unhandled errors (`[fatal]`) | Render → Logs; Render restarts the app |
| Security events (logins, failed logins, locks, role changes) | In the app: Admin → Activity log |
| Uptime | Render health check on `/health`; you can also add a free monitor such as UptimeRobot on the same URL to get an email when the site is down |

Passwords and form contents are never written to the logs.

## 10. Final checklist before going live

- [ ] `npm test` passes
- [ ] `NODE_ENV=production`
- [ ] Strong `SESSION_SECRET` and `ADMIN_PASSWORD` set in Render (not in Git)
- [ ] `SEED_DEMO=false`
- [ ] Site opens on `https://` and `http://` redirects to it
- [ ] Logged in as Admin and changed the admin password from the Account page
- [ ] A test resident account can send a request and the Admin can schedule it
- [ ] First backup taken and restore tested
