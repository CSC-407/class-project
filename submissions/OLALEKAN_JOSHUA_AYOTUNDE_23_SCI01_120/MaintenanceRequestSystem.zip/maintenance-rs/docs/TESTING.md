# Testing

The app was tested in two ways:

1. **Automated tests** (100 tests) that run with one command: `npm test`. They use **Jest** (test runner) and **Supertest** (acts like a browser sending requests to the app). They run against a separate test database, which is emptied before each test file.
2. **Manual tests** for things a computer cannot judge well: how easy the app is to use, and how it looks on different screens.

The full list of automated tests and their results is in [test-results.txt](test-results.txt).

## 1. Automated test summary

| Test type | File | Tests | Result |
|---|---|---|---|
| Functional testing (main user journey) | `functional.test.js` | 4 | All passed |
| Search and filter | `functional.test.js` | 8 | All passed |
| Form validation testing | `functional.test.js` | 11 | All passed |
| Registration testing | `auth.test.js` | 9 | All passed |
| Login testing | `auth.test.js` | 7 | All passed |
| Logout and session testing | `auth.test.js` | 3 | All passed |
| Access control: visitors | `access-control.test.js` | 13 | All passed |
| Access control: users | `access-control.test.js` | 9 | All passed |
| Access control: admins | `access-control.test.js` | 5 | All passed |
| Security: SQL injection | `security.test.js` | 5 | All passed |
| Security: XSS | `security.test.js` | 4 | All passed |
| Security: CSRF | `security.test.js` | 3 | All passed |
| Security: headers and cookies | `security.test.js` | 5 | All passed |
| Database testing | `database-and-errors.test.js` | 10 | All passed |
| Error handling | `database-and-errors.test.js` | 4 | All passed |
| **Total** | | **100** | **100 passed** |

### Do the tests really catch problems?

To prove the security tests are not "always green", two protections were switched off on purpose and the tests were run again:

| Change made on purpose | Result |
|---|---|
| CSRF check turned off in `csrf.js` | 3 CSRF tests failed |
| Owner check changed from `AND user_id` to `OR user_id` in `user.js` | The "cannot see another user's request" test failed |

After undoing the changes, all 100 tests passed again.

## 2. Example test cases (for the report)

### Login and registration

| ID | Test | Input | Expected result | Actual |
|---|---|---|---|---|
| L1 | Register with valid details | Name, email, strong password | Account created, user logged in, sent to dashboard | Pass |
| L2 | Register with an email already used | Existing email | "An account with this email already exists" | Pass |
| L3 | Weak password | `short` | "Password must be at least 8 characters..." | Pass |
| L4 | Passwords do not match | Two different passwords | "The two passwords do not match" | Pass |
| L5 | Try to register as Admin | Extra field `role=admin` | Account is still a normal User | Pass |
| L6 | Login with correct details | Valid email and password | Logged in | Pass |
| L7 | Login with wrong password | Wrong password | "Email or password is incorrect." | Pass |
| L8 | Login with unknown email | Unknown email | Same message as L7 | Pass |
| L9 | 5 wrong passwords in a row | 5 bad attempts, then the right one | Account locked for 15 minutes | Pass |
| L10 | Logout | Click "Log out" | Session ended; My requests sends you to login | Pass |

### Form validation

| ID | Field | Input | Expected result | Actual |
|---|---|---|---|---|
| V1 | Description | empty | Error, nothing saved | Pass |
| V2 | Description | 1001 characters | Error, nothing saved | Pass |
| V3 | Housing | `Block Z` (not in list) | "Choose a housing block from the list" | Pass |
| V4 | Flat number | `12; DROP` | "Flat number can only have letters, numbers and -" | Pass |
| V5 | Urgency | `extreme` | "Choose how urgent this is" | Pass |
| V6 | Visit date | Status Scheduled, no date | "Pick a visit date..." | Pass |
| V7 | Email | `not-an-email` | "Enter a valid email address." | Pass |

### Security

| ID | Attack | How it was tried | Expected result | Actual |
|---|---|---|---|---|
| S1 | SQL injection on login | Email `admin@example.com' OR '1'='1' --` | Login refused | Pass |
| S2 | SQL injection in search | `'; DROP TABLE users; --` | Normal empty search, table still exists | Pass |
| S3 | Stored XSS | Description `<script>alert("hacked")</script>` | Shown as text (`&lt;script&gt;`), never runs | Pass |
| S4 | CSRF | Form sent without token | 403, nothing saved | Pass |
| S5 | IDOR | User opens another user's request ID | 404 "Page not found" | Pass |
| S6 | Privilege escalation | User sends the admin status form | 403, status unchanged | Pass |
| S7 | Session fixation | Compare cookie before and after login | Session ID changes | Pass |
| S8 | Huge request body | 30,000-character password | 413 "too large" | Pass |

## 3. Usability testing (manual)

Ask 3 to 5 people (e.g. classmates or neighbours) to do these tasks on their own phone **without help**. Write down the time, mistakes, and comments. Fill in the "Result" columns yourself.

| Task | What the person must do | Success? | Time | Comments |
|---|---|---|---|---|
| U1 | Create an account | | | |
| U2 | Report a leaking kitchen sink in Block A, flat 12 | | | |
| U3 | Find out if your plumbing request has a visit date | | | |
| U4 | Find an old request using the search box | | | |
| U5 | Change your phone number | | | |
| U6 | Log out | | | |

After the tasks, ask: "What was confusing?" and "Rate how easy it was from 1 (hard) to 5 (easy)." The design already includes these usability features:

- The 4 service buttons from the sketch are the first thing on the dashboard.
- Big touch targets (at least 46px tall) for buttons and fields.
- Clear error messages next to each field, and typed values are kept after an error.
- Progress bar (Open → Scheduled → Solved) so users do not have to read status words.
- Show/hide password button, character counter, and a skip-to-content link for keyboard users.
- The app still works if JavaScript is turned off.

## 4. Responsive / mobile testing

Screenshots were taken automatically at a **phone size (390 × 844, like an iPhone 14)** and a **desktop size (1280 × 860)**. They are in [screenshots/](screenshots/).

| Page | Phone (390px) | Desktop (1280px) | What changes on phone |
|---|---|---|---|
| Dashboard | Pass | Pass | Service tiles go from 4 across to 2 × 2 |
| Login / Register | Pass | Pass | Form fills the width |
| My requests (profile) | Pass | Pass | Ongoing cards and filters stack in one column |
| Request form | Pass | Pass | "Need help with something else?" moves under the form |
| Request details | Pass | Pass | Details box moves under the progress section |
| Admin dashboard | Pass | Pass | Table turns into one card per request |
| Admin users | Pass | Pass | Table turns into cards |
| Security page | Pass | Pass | Two columns become one |

Checks on every page: no sideways scrolling, text readable without zooming, menu reachable from the round account button on phones.

**Extra check to do yourself:** open the app on a real Android phone and in Chrome DevTools device mode (Galaxy S8, iPad), and add those screenshots to your report.

## 5. Error handling

| ID | Situation | Expected result | Actual |
|---|---|---|---|
| E1 | Page that does not exist | Friendly 404 page with a link home | Pass |
| E2 | Request ID that is not a number (`/requests/abc`) | 404, no crash | Pass |
| E3 | Database error while loading a page | Friendly 500 page; no SQL or stack trace shown; error written to the server log | Pass |
| E4 | Form expired (old CSRF token) | 403 with "refresh the page and try again" | Pass |
| E5 | Normal user opens an Admin page | 403 "You do not have permission" | Pass |
| E6 | Too many login attempts from one network | 429 "Please wait 15 minutes" | Built in, see `authLimiter` |

## 6. Database testing

| ID | Rule | Expected result | Actual |
|---|---|---|---|
| D1 | All tables are created by `npm run migrate` | users, requests, audit_logs, session exist | Pass |
| D2 | Same email twice | Database refuses (unique) | Pass |
| D3 | Role other than user/admin | Database refuses (check) | Pass |
| D4 | Status other than open/scheduled/solved | Database refuses (check) | Pass |
| D5 | Category not in the 4 services | Database refuses (check) | Pass |
| D6 | Request for a user that does not exist | Database refuses (foreign key) | Pass |
| D7 | Delete a user | Their requests are deleted too (cascade) | Pass |
| D8 | New request | Starts as "open" with a creation date | Pass |
| D9 | Login | Saved in audit log | Pass |
| D10 | Login | Session saved in the database | Pass |

The rules are enforced **twice**: once by the app's validation and once by the database itself, so bad data cannot get in even if the app has a bug.

## How to run the tests

```bash
# Needs TEST_DATABASE_URL in .env (a separate, empty database)
npm test
```
