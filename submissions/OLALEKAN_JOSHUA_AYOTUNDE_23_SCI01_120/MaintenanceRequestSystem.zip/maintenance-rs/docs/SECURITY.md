# Web Application Security

This section explains each security measure, the attack it stops, how it was built, and how it was tested. Users can read a short version on the **Security** page inside the app (`/security`).

## 1. User authentication (login and logout)

- **What it stops:** strangers using the system or seeing other people's data.
- **How:** users log in with email and password (`src/routes/auth.js`). On success, the server stores the user's ID in a session. Every protected page checks for that session (`requireAuth` in `src/middleware/auth.js`).
- **Logout** is a `POST` form with a CSRF token, not a link, so another website cannot log a user out. Logout destroys the session on the server and clears the cookie.
- **Safe error messages:** a wrong email and a wrong password show the same message, "Email or password is incorrect." The server also runs the password check for unknown emails, so the response time does not reveal which emails exist.
- **Tested in:** `tests/auth.test.js`

## 2. Password hashing

- **What it stops:** if the database is ever stolen, the attacker still cannot read passwords.
- **How:** `bcrypt` with a cost of 12 rounds (`src/security/passwords.js`). bcrypt adds a random salt, so the same password gives a different hash for each user. The real password is never stored or logged.
- **Password rule:** at least 8 characters with a letter and a number (checked on the server).
- **Tested in:** `tests/auth.test.js`, which checks the stored value is a bcrypt hash (`$2b$...`) and that two equal passwords have different hashes.

## 3. Role-based access (Admin and User)

| Action | User | Admin |
|---|---|---|
| Send a request | ✔ | |
| See own requests | ✔ | ✔ (all requests) |
| Change status / set visit date | | ✔ |
| Manage roles, unlock accounts | | ✔ |
| View activity log | | ✔ |

- **How:** one line, `router.use(requireRole('admin'))`, protects every `/admin` route. New accounts are always created as `user`. The register route only reads the fields it expects, so adding `role=admin` to the form does nothing.
- An admin cannot change their own role, so the last admin cannot lock themselves out. When a role changes, that user's sessions are ended so the new role applies at once.
- **Tested in:** `tests/access-control.test.js`

## 4. Access-control checks (stopping IDOR)

- **What it stops:** a user changing `/requests/5` to `/requests/6` to see someone else's request.
- **How:** the database query includes the owner: `WHERE id = $1 AND user_id = $2`. If the request is not theirs, the user gets "Page not found", so it does not even reveal that the request exists. New requests take the `user_id` from the session, never from the form.
- **Tested in:** `tests/access-control.test.js`

## 5. Input validation

- **What it stops:** bad, harmful or oversized data.
- **How:** `express-validator` rules for every form (`src/validators.js`): length limits, allowed characters (names, flat numbers, phones), allowed choices (housing block, urgency, status, role), valid emails and dates. Spaces are trimmed. HTML attributes like `maxlength` help users, but the server always checks again.
- Request bodies are limited to 20 KB, and unknown filter values are ignored.
- **Tested in:** `tests/functional.test.js` (Form validation section)

## 6. SQL injection protection

- **What it stops:** typed text like `' OR 1=1 --` changing a database command.
- **How:** every query uses placeholders (`$1`, `$2`) through the `pg` library, which sends the data separately from the SQL. No user input is joined into SQL text. In searches, `%` and `_` are escaped so they cannot act as wildcards (`src/search.js`). Page numbers are converted to whole numbers first.
- **Tested in:** `tests/security.test.js`, which tries a login bypass, `DROP TABLE` in the search box, and SQL in a description.

## 7. Cross-Site Scripting (XSS) protection

- **What it stops:** a user saving `<script>` in a description that then runs in the Admin's browser.
- **How (two layers):**
  1. **Output escaping:** every value is printed with `<%= %>`, which turns `<` into `&lt;`. `<%- %>` (no escaping) is only used for our own fixed icons and page includes, never for user data.
  2. **Content Security Policy** (Helmet, `src/app.js`): `script-src 'self'` with no `unsafe-inline`, so even injected script would not run. All JavaScript is in `public/js/app.js`.
- **Tested in:** `tests/security.test.js`, which stores a script payload and confirms it appears escaped on both the user and admin pages.

## 8. CSRF protection

- **What it stops:** a bad website secretly sending a form to our site using the user's logged-in cookie.
- **How:** each session gets a random 32-byte token (`src/security/csrf.js`). Every form includes it as a hidden field. All `POST` requests must send a matching token, compared with `crypto.timingSafeEqual`. The cookie is also `SameSite=Lax`.
- **Tested in:** `tests/security.test.js` (missing token, wrong token, another user's token).

## 9. Session management

| Setting | Value | Why |
|---|---|---|
| Storage | PostgreSQL `session` table | Survives restarts and can be ended per user |
| Cookie name | `mrs.sid` | Hides the default name |
| `HttpOnly` | on | JavaScript cannot read the cookie |
| `Secure` | on in production | Cookie only travels over HTTPS |
| `SameSite` | `Lax` | Extra CSRF protection |
| Idle timeout | 30 minutes, rolling | Logs out unattended computers |
| New session ID at login | `req.session.regenerate()` | Stops session fixation |
| Password change | ends all other sessions | Kicks out anyone using the old password |

- **Tested in:** `tests/auth.test.js` (new ID on login, logout, other devices logged out) and `tests/security.test.js` (cookie flags).

## 10. Brute-force protection

- **Rate limit:** 20 login/register attempts per 15 minutes per IP (`express-rate-limit`).
- **Account lock:** after 5 wrong passwords the account is locked for 15 minutes. Admins can unlock it on the Users page.
- **Tested in:** `tests/auth.test.js` (lock after 5 failures).

## 11. Secure handling of sensitive information

- Secrets (database URL, session secret, admin password) are **environment variables**, never in the code. `.env` is in `.gitignore`; `.env.example` shows the names only.
- The app refuses to start in production if `SESSION_SECRET` is shorter than 32 characters.
- Password hashes are never selected for pages (`loadUser` picks safe columns only).
- Pages with personal data send `Cache-Control: no-store`.
- Error pages show a friendly message only. Stack traces and SQL errors go to the server log.
- Request logs never include form bodies, so passwords are never logged.
- Backups are written with owner-only file permissions.

## 12. HTTPS and security configuration

- In production, any `http://` visit is redirected to `https://` (301).
- **HSTS** (`Strict-Transport-Security: max-age=31536000; includeSubDomains`) tells browsers to always use HTTPS.
- `trust proxy` is enabled so Express knows the visitor used HTTPS through the host's load balancer.
- Other headers from Helmet: `X-Content-Type-Options: nosniff`, `X-Frame-Options` + `frame-ancestors 'none'` (stops clickjacking), `Referrer-Policy: same-origin`. `X-Powered-By` is removed.
- Fonts are stored in the app, so no outside sites are contacted.

## 13. Activity (audit) log

Saved in the `audit_logs` table with time and IP address: `LOGIN`, `LOGIN_FAILED`, `LOGIN_BLOCKED`, `ACCOUNT_LOCKED`, `ACCOUNT_UNLOCKED`, `LOGOUT`, `REGISTER`, `PASSWORD_CHANGED`, `ROLE_CHANGED`, `REQUEST_UPDATED`. Admins view and filter it at **Admin → Activity log**.

## Known limits (honest notes for the report)

- "Forgot password" by email is not built; users call support. A real system would send a one-time reset link.
- Registration tells users when an email is already used. This is friendlier, but it lets someone check whether an email has an account. The rate limit reduces this risk.
- There is no two-factor login (2FA). It would be a good next step for Admin accounts.
