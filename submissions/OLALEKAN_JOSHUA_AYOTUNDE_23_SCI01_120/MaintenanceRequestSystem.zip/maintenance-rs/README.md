# Maintenance Request System

**By Joshua Olalekan** · +234 903 093 0463

A responsive web app where residents report repair problems (Electrical, Plumbing, Carpentry, IT) and follow them from **Open → Scheduled → Solved**. Admins see every request, set visit dates, manage users and review a security activity log.

Built with **Node.js + Express**, **PostgreSQL**, and plain **HTML (EJS templates) + CSS**.

![Dashboard on desktop](docs/screenshots/desktop-dashboard.png)

## What is inside

| Requirement | Where it is |
|---|---|
| Home / Dashboard | `views/home.ejs` (residents), `views/admin/dashboard.ejs` (admins) |
| Registration and Login | `views/auth/register.ejs`, `views/auth/login.ejs` |
| User profile | `views/profile.ejs` (ongoing + all requests), `views/account.ejs` (details + password) |
| Navigation menu | `views/partials/head.ejs` (top bar + account menu) |
| Forms for entering data | `views/request-form.ejs`, account forms, admin update form |
| Search / filter | My requests page and Admin dashboard (text, status, category, pages) |
| Responsive design | `public/css/style.css` (phone first, tested at 390px and 1280px) |
| Security | `src/security/`, `src/middleware/`, `src/validators.js` + the in-app **Security** page |
| Testing | `tests/` (100 automated tests) + [docs/TESTING.md](docs/TESTING.md) |
| Deployment | `render.yaml`, `.env.example`, `scripts/` + [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) |

## Run it on your computer

This is a server app, so opening `index.html` or using "Go Live" will not work. You only need **Node.js 20+** (from nodejs.org). The database is set up for you.

```bash
npm install        # once, needs internet
npm run local      # every time you want to use the site
```

Then open **http://localhost:3000**. Press `Ctrl + C` in the terminal to stop.

| Role | Email | Password |
|---|---|---|
| Admin | admin@example.com | AdminPass2026 |
| Resident | ada@example.com | DemoUser#2026 |

`npm run local` creates a private database in the `.local-db` folder and a `.env` settings file the first time. To start fresh, stop the app and delete both.

Run all automated tests the easy way with `npm run local:test`.

### Using your own PostgreSQL instead

If you already have PostgreSQL installed:

```bash
cp .env.example .env     # then edit DATABASE_URL and the other values
npm run migrate          # create the tables
npm run seed             # create the Admin account and demo data
npm run dev              # start; restarts when you save a file
```

## Commands

| Command | What it does |
|---|---|
| `npm run local` | Easiest start: private database + website |
| `npm run local:test` | Run all tests with the private database |
| `npm run dev` | Start in development mode with auto-restart (own PostgreSQL) |
| `npm start` | Start normally (used on the live server) |
| `npm run migrate` | Create or update the database tables |
| `npm run seed` | Create the Admin account (and demo data if `SEED_DEMO=true`) |
| `npm test` | Run all automated tests (uses the separate test database) |
| `npm run backup` | Save a database backup to `backups/` |

## Editing the look

- **Pages** are in `views/`. They are normal HTML. `<%= value %>` prints a value safely; `<% if (...) { %>` adds logic.
- **All styling** is in `public/css/style.css`. Change the colours and sizes at the top (`:root`) to restyle everything.
- Keep JavaScript in `public/js/app.js` and styles in the CSS file. The security policy blocks inline `<script>` and `style="..."` on purpose.

## Folder map

```
src/
  app.js            Express setup: headers, sessions, CSRF, routes
  server.js         Starts the app
  config.js         Reads settings from environment variables
  db.js             PostgreSQL connection
  validators.js     Input rules for every form
  search.js         Safe search and filter queries
  security/         passwords.js, csrf.js, audit.js
  middleware/       auth.js (login + role checks), errors.js
  routes/           auth.js, user.js, admin.js, pages.js
views/              HTML pages (EJS)
public/             CSS, JS, fonts, favicon
db/schema.sql       Database tables
scripts/            migrate, seed, backup
tests/              Automated tests
docs/               Security, Testing, Deployment write-ups + screenshots
```

## Author

**Joshua Olalekan**  
Phone: +234 903 093 0463
