// Admin area. EVERY route here checks the user is an Admin.
const express = require('express');
const db = require('../db');
const audit = require('../security/audit');
const { requireRole } = require('../middleware/auth');
const { rules, getErrors } = require('../validators');
const { buildRequestFilters, likeValue } = require('../search');
const { ref, pageNumber } = require('../helpers');

const router = express.Router();
const PAGE_SIZE = 10;

// Role-based access: this one line protects the whole /admin section
router.use(requireRole('admin'));

function cleanFilters(req) {
  const bad = getErrors(req) || {};
  return {
    q: bad.q ? '' : (req.query.q || '').trim(),
    status: bad.status ? '' : req.query.status || '',
    category: bad.category ? '' : req.query.category || '',
  };
}

// ---------- Admin dashboard: all requests with search & filter ----------
router.get('/', rules.filters, async (req, res, next) => {
  try {
    const filters = cleanFilters(req);
    const page = pageNumber(req.query.page);

    const stats = await db.query(
      `SELECT
         COUNT(*)::int AS total,
         COUNT(*) FILTER (WHERE status = 'open')::int AS open,
         COUNT(*) FILTER (WHERE status = 'scheduled')::int AS scheduled,
         COUNT(*) FILTER (WHERE status = 'solved')::int AS solved,
         COUNT(*) FILTER (WHERE urgency = 'high' AND status <> 'solved')::int AS urgent
       FROM requests`
    );

    const { whereSql, params } = buildRequestFilters(filters, [
      'r.description', 'r.address', 'r.flat_number', 'u.full_name', 'u.email',
    ]);
    const total = await db.query(
      `SELECT COUNT(*)::int AS n FROM requests r JOIN users u ON u.id = r.user_id ${whereSql}`,
      params
    );
    const list = await db.query(
      `SELECT r.*, u.full_name, u.email
       FROM requests r JOIN users u ON u.id = r.user_id
       ${whereSql}
       ORDER BY (r.status = 'solved'), (r.urgency = 'high') DESC, r.created_at DESC
       LIMIT ${PAGE_SIZE} OFFSET ${(page - 1) * PAGE_SIZE}`,
      params
    );

    res.render('admin/dashboard', {
      title: 'Admin dashboard',
      stats: stats.rows[0],
      requests: list.rows,
      filters,
      page,
      pages: Math.max(1, Math.ceil(total.rows[0].n / PAGE_SIZE)),
      total: total.rows[0].n,
    });
  } catch (err) {
    next(err);
  }
});

// ---------- Manage one request ----------
async function loadRequest(id) {
  const { rows } = await db.query(
    `SELECT r.*, u.full_name, u.email, u.phone
     FROM requests r JOIN users u ON u.id = r.user_id WHERE r.id = $1`,
    [id]
  );
  return rows[0];
}

router.get('/requests/:id', rules.idParam, async (req, res, next) => {
  try {
    if (getErrors(req)) return next();
    const request = await loadRequest(req.params.id);
    if (!request) return next();
    res.render('admin/request', { title: `Manage ${ref(request.id)}`, request, values: request, errors: {} });
  } catch (err) {
    next(err);
  }
});

router.post('/requests/:id', rules.updateRequest, async (req, res, next) => {
  try {
    const request = await loadRequest(req.params.id);
    if (!request) return next();

    const values = {
      status: req.body.status,
      scheduled_for: req.body.scheduled_for || null,
      admin_note: req.body.admin_note || null,
    };
    const errors = getErrors(req) || {};
    if (values.status === 'scheduled' && !values.scheduled_for) {
      errors.scheduled_for = 'Pick a visit date when the status is "Scheduled".';
    }
    if (Object.keys(errors).length) {
      return res.status(422).render('admin/request', {
        title: `Manage ${ref(request.id)}`, request, values: { ...request, ...values }, errors,
      });
    }

    await db.query(
      `UPDATE requests SET status = $1, scheduled_for = $2, admin_note = $3, updated_at = NOW() WHERE id = $4`,
      [values.status, values.scheduled_for, values.admin_note, request.id]
    );
    await audit(req, 'REQUEST_UPDATED', `${ref(request.id)}: ${request.status} -> ${values.status}`);
    req.session.flash = { type: 'success', message: `${ref(request.id)} has been updated.` };
    res.redirect(`/admin/requests/${request.id}`);
  } catch (err) {
    next(err);
  }
});

// ---------- Users and roles ----------
router.get('/users', rules.filters, async (req, res, next) => {
  try {
    const q = (getErrors(req) || {}).q ? '' : (req.query.q || '').trim();
    const params = [];
    let where = '';
    if (q) {
      params.push(likeValue(q));
      where = 'WHERE u.full_name ILIKE $1 OR u.email ILIKE $1';
    }
    const { rows } = await db.query(
      `SELECT u.id, u.full_name, u.email, u.phone, u.role, u.created_at, u.locked_until,
              COUNT(r.id)::int AS request_count
       FROM users u LEFT JOIN requests r ON r.user_id = u.id
       ${where}
       GROUP BY u.id ORDER BY u.created_at DESC LIMIT 100`,
      params
    );
    res.render('admin/users', { title: 'Users', users: rows, q });
  } catch (err) {
    next(err);
  }
});

router.post('/users/:id/role', rules.changeRole, async (req, res, next) => {
  try {
    if (getErrors(req)) {
      req.session.flash = { type: 'error', message: 'That role change was not valid.' };
      return res.redirect('/admin/users');
    }
    if (Number(req.params.id) === Number(req.user.id)) {
      // Stops an admin from removing their own admin rights by mistake
      req.session.flash = { type: 'error', message: 'You cannot change your own role.' };
      return res.redirect('/admin/users');
    }
    const { rows } = await db.query(
      'UPDATE users SET role = $1 WHERE id = $2 RETURNING email',
      [req.body.role, req.params.id]
    );
    if (!rows[0]) return next();

    // End that user's sessions so the new role applies immediately
    await db.query(`DELETE FROM "session" WHERE (sess->>'userId')::int = $1`, [req.params.id]);
    await audit(req, 'ROLE_CHANGED', `${rows[0].email} is now ${req.body.role}`);
    req.session.flash = { type: 'success', message: `${rows[0].email} is now ${req.body.role === 'admin' ? 'an Admin' : 'a User'}.` };
    res.redirect('/admin/users');
  } catch (err) {
    next(err);
  }
});

router.post('/users/:id/unlock', rules.idParam, async (req, res, next) => {
  try {
    if (getErrors(req)) return next();
    const { rows } = await db.query(
      'UPDATE users SET locked_until = NULL, failed_logins = 0 WHERE id = $1 RETURNING email',
      [req.params.id]
    );
    if (!rows[0]) return next();
    await audit(req, 'ACCOUNT_UNLOCKED', rows[0].email);
    req.session.flash = { type: 'success', message: `${rows[0].email} has been unlocked.` };
    res.redirect('/admin/users');
  } catch (err) {
    next(err);
  }
});

// ---------- Activity (security) log ----------
const LOG_ACTIONS = [
  'LOGIN', 'LOGIN_FAILED', 'LOGIN_BLOCKED', 'ACCOUNT_LOCKED', 'ACCOUNT_UNLOCKED', 'LOGOUT',
  'REGISTER', 'PASSWORD_CHANGED', 'ROLE_CHANGED', 'REQUEST_UPDATED',
];

router.get('/logs', async (req, res, next) => {
  try {
    const action = LOG_ACTIONS.includes(req.query.action) ? req.query.action : '';
    const params = action ? [action] : [];
    const { rows } = await db.query(
      `SELECT l.*, u.email FROM audit_logs l LEFT JOIN users u ON u.id = l.user_id
       ${action ? 'WHERE l.action = $1' : ''}
       ORDER BY l.created_at DESC LIMIT 150`,
      params
    );
    res.render('admin/logs', { title: 'Activity log', logs: rows, action, actions: LOG_ACTIONS });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
