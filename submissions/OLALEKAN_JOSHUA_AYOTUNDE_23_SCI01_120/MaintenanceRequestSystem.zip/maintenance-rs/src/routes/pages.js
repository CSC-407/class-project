// Public information pages
const express = require('express');
const router = express.Router();

router.get('/security', (req, res) => {
  res.render('security', { title: 'Security' });
});

router.get('/support', (req, res) => {
  res.render('support', { title: 'Support' });
});

module.exports = router;
