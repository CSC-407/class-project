// Pages for normal users: dashboard, new request, my requests (profile), account
const express = require('express');
const db = require('../db');
const audit = require('../security/audit');
const { hashPassword, verifyPassword } = require('../security/passwords');
const { requireAuth, requireRole } = require('../middleware/auth');
const { rules, getErrors, CATEGORIES, BLOCKS } = require('../validators');
const { buildRequestFilters } = require('../search');
const { CATEGORY_INFO, pageNumber } = require('../helpers');

const router = express.Router();
const PAGE_SIZE = 8;

// ---------- Home / Dashboard ----------
router.get('/', async (req, res, next) => {
  try {
    if (!req.user) return res.render('home', { title: 'Welcome', counts: null });
    if (req.user.role === 'admin') return res.redirect('/admin');

    const { rows } = await db.query(
      `SELECT status, COUNT(*)::int AS n FROM requests WHERE user_id = $1 GROUP BY status`,
      [req.user.id]
    );
    const counts = { open: 0, scheduled: 0, solved: 0 };
    rows.forEach((r) => { counts[r.status] = r.n; });
    res.render('home', { title: 'Dashboard', counts });
  } catch (err) {
    next(err);
  }
});

// ---------- New request form (one per category) ----------
const userOnly = [requireAuth, requireRole('user')];

router.get('/request/:category', userOnly, (req, res, next) => {
  const { category } = req.params;
  if (!CATEGORIES.includes(category)) return next(); // goes on to the 404 page
  res.render('request-form', {
    title: `Request help: ${CATEGORY_INFO[category].label}`,
    category,
    blocks: BLOCKS,
    values: { housing_block: BLOCKS[0], urgency: 'normal' },
    errors: {},
  });
});

router.post('/request/:category', userOnly, rules.newRequest, async (req, res, next) => {
  const { category } = req.params;
  if (!CATEGORIES.includes(category)) return next();

  const values = {
    housing_block: req.body.housing_block,
    flat_number: req.body.flat_number,
    address: req.body.address,
    description: req.body.description,
    urgency: req.body.urgency,
  };
  try {
    const errors = getErrors(req);
    if (errors) {
      return res.status(422).render('request-form', {
        title: `Request help: ${CATEGORY_INFO[category].label}`,
        category, blocks: BLOCKS, values, errors,
      });
    }
    // user_id comes from the SESSION, not from the form, so nobody can
    // create a request in someone else's name.
    const { rows } = await db.query(
      `INSERT INTO requests (user_id, category, housing_block, flat_number, address, description, urgency)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
      [req.user.id, category, values.housing_block, values.flat_number, values.address, values.description, values.urgency]
    );
    req.session.flash = { type: 'success', message: 'Your request has been sent. We will update you here.' };
    res.redirect(`/requests/${rows[0].id}`);
  } catch (err) {
    next(err);
  }
});

// ---------- One request (owner only) ----------
router.get('/requests/:id', userOnly, rules.idParam, async (req, res, next) => {
  try {
    if (getErrors(req)) return next();
    // Access-control check: the request must belong to the logged-in user.
    // If it does not, we answer "not found" so we do not even reveal it exists.
    const { rows } = await db.query(
      'SELECT * FROM requests WHERE id = $1 AND user_id = $2',
      [req.params.id, req.user.id]
    );
    if (!rows[0]) return next();
    res.render('request-detail', { title: 'Request details', request: rows[0] });
  } catch (err) {
    next(err);
  }
});

// ---------- Profile: ongoing tracker + my requests (search & filter) ----------
router.get('/profile', userOnly, rules.filters, async (req, res, next) => {
  try {
    const bad = getErrors(req);
    const filters = {
      q: bad && bad.q ? '' : (req.query.q || '').trim(),
      status: bad && bad.status ? '' : req.query.status || '',
      category: bad && bad.category ? '' : req.query.category || '',
    };
    const page = pageNumber(req.query.page);

    const ongoing = await db.query(
      `SELECT * FROM requests WHERE user_id = $1 AND status <> 'solved'
       ORDER BY updated_at DESC LIMIT 3`,
      [req.user.id]
    );

    const { whereSql, params } = buildRequestFilters(
      { ...filters, userId: req.user.id },
      ['r.description', 'r.address', 'r.flat_number']
    );
    const total = await db.query(`SELECT COUNT(*)::int AS n FROM requests r ${whereSql}`, params);
    const list = await db.query(
      `SELECT r.* FROM requests r ${whereSql}
       ORDER BY r.created_at DESC
       LIMIT ${PAGE_SIZE} OFFSET ${(page - 1) * PAGE_SIZE}`,
      params
    );

    res.render('profile', {
      title: 'My requests',
      ongoing: ongoing.rows,
      requests: list.rows,
      filters,
      page,
      pages: Math.max(1, Math.ceil(total.rows[0].n / PAGE_SIZE)),
      total: total.rows[0].n,
    });
  } catch (err) {
    next(err);
  }
});

// ---------- Account settings ----------
router.get('/account', requireAuth, (req, res) => {
  res.render('account', {
    title: 'Account settings',
    values: { full_name: req.user.full_name, phone: req.user.phone },
    errors: {},
    pwErrors: {},
  });
});

router.post('/account', requireAuth, rules.profile, async (req, res, next) => {
  const values = { full_name: req.body.full_name, phone: req.body.phone || null };
  try {
    const errors = getErrors(req);
    if (errors) {
      return res.status(422).render('account', { title: 'Account settings', values, errors, pwErrors: {} });
    }
    await db.query('UPDATE users SET full_name = $1, phone = $2 WHERE id = $3', [values.full_name, values.phone, req.user.id]);
    req.session.flash = { type: 'success', message: 'Your details have been saved.' };
    res.redirect('/account');
  } catch (err) {
    next(err);
  }
});

router.post('/account/password', requireAuth, rules.changePassword, async (req, res, next) => {
  const values = { full_name: req.user.full_name, phone: req.user.phone };
  const render = (pwErrors) =>
    res.status(422).render('account', { title: 'Account settings', values, errors: {}, pwErrors });
  try {
    const errors = getErrors(req);
    if (errors) return render(errors);

    const { rows } = await db.query('SELECT password_hash FROM users WHERE id = $1', [req.user.id]);
    const ok = await verifyPassword(req.body.current_password, rows[0].password_hash);
    if (!ok) return render({ current_password: 'Your current password is not correct.' });

    const hash = await hashPassword(req.body.new_password);
    await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [hash, req.user.id]);

    // Log out every OTHER device that was logged in with the old password
    await db.query(
      `DELETE FROM "session" WHERE sid <> $1 AND (sess->>'userId')::int = $2`,
      [req.sessionID, req.user.id]
    );
    await audit(req, 'PASSWORD_CHANGED', 'Password changed; other sessions ended');

    req.session.flash = { type: 'success', message: 'Password changed. Other devices have been logged out.' };
    res.redirect('/account');
  } catch (err) {
    next(err);
  }
});

module.exports = router;
