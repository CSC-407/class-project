// Registration, login and logout
const express = require('express');
const rateLimit = require('express-rate-limit');
const db = require('../db');
const config = require('../config');
const audit = require('../security/audit');
const { hashPassword, verifyPassword } = require('../security/passwords');
const { guestOnly } = require('../middleware/auth');
const { rules, getErrors } = require('../validators');

const router = express.Router();

const MAX_FAILED_LOGINS = 5;
const LOCK_MINUTES = 15;

// Rate limit: one IP address can only try 20 logins/registrations per 15 minutes.
// This slows down password-guessing robots.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  skip: () => config.isTest && !process.env.TEST_RATE_LIMIT,
  handler: (req, res) => {
    res.status(429).render('error', {
      title: 'Too many attempts',
      status: 429,
      message: 'Too many attempts from your network. Please wait 15 minutes and try again.',
    });
  },
});

// ---------- Register ----------
router.get('/register', guestOnly, (req, res) => {
  res.render('auth/register', { title: 'Create account', values: {}, errors: {} });
});

router.post('/register', guestOnly, authLimiter, rules.register, async (req, res, next) => {
  // Only pick the fields we expect. Anything else (like "role=admin") is ignored.
  const values = {
    full_name: req.body.full_name,
    email: req.body.email,
    phone: req.body.phone || null,
  };
  try {
    const errors = getErrors(req) || {};
    if (!errors.email) {
      const exists = await db.query('SELECT 1 FROM users WHERE email = $1', [values.email]);
      if (exists.rowCount) errors.email = 'An account with this email already exists. Try logging in.';
    }
    if (Object.keys(errors).length) {
      return res.status(422).render('auth/register', { title: 'Create account', values, errors });
    }

    const hash = await hashPassword(req.body.password);
    const { rows } = await db.query(
      `INSERT INTO users (full_name, email, phone, password_hash, role)
       VALUES ($1, $2, $3, $4, 'user') RETURNING id, role`,
      [values.full_name, values.email, values.phone, hash]
    );

    await audit(req, 'REGISTER', `New account: ${values.email}`, rows[0].id);
    // Log the new user in straight away
    return startSession(req, res, next, rows[0], 'Your account has been created. Welcome!');
  } catch (err) {
    next(err);
  }
});

// ---------- Login ----------
router.get('/login', guestOnly, (req, res) => {
  const notice = req.query.loggedout === '1' ? 'You have logged out.' : null;
  res.render('auth/login', { title: 'Log in', values: {}, errors: {}, formError: null, notice });
});

router.post('/login', guestOnly, authLimiter, rules.login, async (req, res, next) => {
  const values = { email: req.body.email };
  const fail = (message, status = 401) =>
    res.status(status).render('auth/login', { title: 'Log in', values, errors: {}, formError: message });

  try {
    const errors = getErrors(req);
    if (errors) {
      return res.status(422).render('auth/login', { title: 'Log in', values, errors, formError: null });
    }

    const { rows } = await db.query(
      'SELECT id, role, password_hash, failed_logins, locked_until FROM users WHERE email = $1',
      [values.email]
    );
    const user = rows[0];

    // Account lock after too many wrong passwords
    if (user && user.locked_until && new Date(user.locked_until) > new Date()) {
      await audit(req, 'LOGIN_BLOCKED', `Locked account: ${values.email}`, user.id);
      return fail(`Too many wrong attempts. This account is locked for ${LOCK_MINUTES} minutes.`, 423);
    }

    // Always run the password check (even for unknown emails) so timing is the same
    const ok = await verifyPassword(req.body.password, user && user.password_hash);

    if (!user || !ok) {
      if (user) {
        const attempts = user.failed_logins + 1;
        if (attempts >= MAX_FAILED_LOGINS) {
          await db.query(
            `UPDATE users SET failed_logins = 0, locked_until = NOW() + ($2 || ' minutes')::interval WHERE id = $1`,
            [user.id, String(LOCK_MINUTES)]
          );
          await audit(req, 'ACCOUNT_LOCKED', `After ${attempts} failed attempts: ${values.email}`, user.id);
        } else {
          await db.query('UPDATE users SET failed_logins = $2 WHERE id = $1', [user.id, attempts]);
        }
      }
      await audit(req, 'LOGIN_FAILED', `Email tried: ${values.email}`, user ? user.id : null);
      // Same message for "wrong email" and "wrong password" - do not reveal which one
      return fail('Email or password is incorrect.');
    }

    await db.query('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = $1', [user.id]);
    await audit(req, 'LOGIN', 'Logged in', user.id);
    return startSession(req, res, next, user, null);
  } catch (err) {
    next(err);
  }
});

// Creates a brand new session ID after login.
// This stops "session fixation" (an attacker planting a known session ID before login).
function startSession(req, res, next, user, flashMessage) {
  const returnTo = req.session.returnTo;
  req.session.regenerate((err) => {
    if (err) return next(err);
    req.session.userId = user.id;
    req.session.role = user.role;
    if (flashMessage) req.session.flash = { type: 'success', message: flashMessage };
    const fallback = user.role === 'admin' ? '/admin' : '/';
    // Only allow redirects inside our own site (stops "open redirect" tricks)
    const target = returnTo && /^\/(?!\/)/.test(returnTo) ? returnTo : fallback;
    req.session.save((err2) => (err2 ? next(err2) : res.redirect(target)));
  });
}

// ---------- Logout ----------
// Uses POST (with CSRF token) so another website cannot log you out with a link
router.post('/logout', async (req, res, next) => {
  if (req.session.userId) await audit(req, 'LOGOUT', 'Logged out');
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('mrs.sid');
    res.redirect('/login?loggedout=1');
  });
});

module.exports = router;
