// Starts the web server.
const config = require('./config');
const app = require('./app');
const migrate = require('../scripts/migrate');
const { pool } = require('./db');

async function start() {
  // Make sure the tables exist before accepting visitors
  await migrate();

  const server = app.listen(config.port, () => {
    console.log(`Maintenance Request System running on http://localhost:${config.port} (${config.env})`);
  });

  // Close cleanly when the host stops the app (e.g. during a new deploy)
  const shutdown = (signal) => {
    console.log(`${signal} received, shutting down...`);
    server.close(() => pool.end().then(() => process.exit(0)));
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

// Log crashes so they show in the host's log viewer
process.on('unhandledRejection', (err) => console.error('[fatal] unhandled promise rejection:', err));

start().catch((err) => {
  console.error('[fatal] could not start:', err.message);
  process.exit(1);
});
