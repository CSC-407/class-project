// CSRF protection (Cross-Site Request Forgery).
// Every form gets a secret random token that is also saved in the user's session.
// When a form is sent (POST), the two must match. A fake form on another
// website cannot know this token, so its request is rejected.
const crypto = require('crypto');

function getToken(req) {
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  }
  return req.session.csrfToken;
}

// Makes the token available in every page as <%= csrfToken %>
function provideToken(req, res, next) {
  res.locals.csrfToken = getToken(req);
  next();
}

// Checks the token on every request that changes data
function verifyToken(req, res, next) {
  const safeMethods = ['GET', 'HEAD', 'OPTIONS'];
  if (safeMethods.includes(req.method)) return next();

  const sent = String((req.body && req.body._csrf) || req.get('x-csrf-token') || '');
  const expected = req.session.csrfToken || '';

  const ok =
    sent.length === expected.length &&
    expected.length > 0 &&
    crypto.timingSafeEqual(Buffer.from(sent), Buffer.from(expected));

  if (!ok) {
    const err = new Error('Your form has expired or is not valid. Please go back, refresh the page and try again.');
    err.status = 403;
    err.code = 'CSRF';
    return next(err);
  }
  next();
}

module.exports = { provideToken, verifyToken };
