// Password hashing with bcrypt.
// - We never save the real password. We save a one-way "hash".
// - bcrypt adds a random "salt" to every hash, so two users with the same
//   password still get different hashes.
// - The cost factor (rounds) makes each guess slow for an attacker.
const bcrypt = require('bcryptjs');

const BCRYPT_ROUNDS = process.env.NODE_ENV === 'test' ? 4 : 12;

// A fixed fake hash. When an email does not exist we still run bcrypt.compare
// against this, so the response time does not reveal which emails are registered.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', BCRYPT_ROUNDS);

function hashPassword(plain) {
  return bcrypt.hash(plain, BCRYPT_ROUNDS);
}

function verifyPassword(plain, hash) {
  return bcrypt.compare(plain, hash || DUMMY_HASH);
}

// Password rule shown to the user and checked on the server:
// at least 8 characters, with a letter and a number.
const PASSWORD_RULE = /^(?=.*[A-Za-z])(?=.*\d).{8,72}$/;

module.exports = { BCRYPT_ROUNDS, hashPassword, verifyPassword, PASSWORD_RULE };
