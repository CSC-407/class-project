// Saves important security events (logins, failed logins, role changes...)
// so an Admin can review them on the "Activity log" page.
const db = require('../db');

async function audit(req, action, details, userId) {
  try {
    const uid = userId !== undefined ? userId : (req.session && req.session.userId) || null;
    await db.query(
      'INSERT INTO audit_logs (user_id, action, details, ip_address) VALUES ($1, $2, $3, $4)',
      [uid, action, details ? String(details).slice(0, 300) : null, req.ip]
    );
  } catch (err) {
    // Logging must never crash the app
    console.error('[audit] could not save event:', err.message);
  }
}

module.exports = audit;
