// Input validation rules (checked on the SERVER).
// The browser also checks some fields, but browser checks can be skipped,
// so the server always checks again before saving anything.
const { body, query, param, validationResult } = require('express-validator');
const { PASSWORD_RULE } = require('./security/passwords');

const CATEGORIES = ['electrical', 'plumbing', 'carpentry', 'it'];
const STATUSES = ['open', 'scheduled', 'solved'];
const URGENCIES = ['low', 'normal', 'high'];
const BLOCKS = ['Block A', 'Block B', 'Block C', 'Block D'];

const name = body('full_name')
  .trim()
  .isLength({ min: 2, max: 80 }).withMessage('Name must be between 2 and 80 characters.')
  .matches(/^[A-Za-zÀ-ÿ' .-]+$/).withMessage('Name can only contain letters, spaces, apostrophes and hyphens.');

const email = body('email')
  .trim()
  .isEmail().withMessage('Enter a valid email address.')
  .isLength({ max: 120 })
  .normalizeEmail({ gmail_remove_dots: false });

const phone = body('phone')
  .optional({ values: 'falsy' })
  .trim()
  .matches(/^\+?[0-9 ()-]{7,20}$/).withMessage('Enter a valid phone number.');

const newPassword = (field) =>
  body(field)
    .matches(PASSWORD_RULE)
    .withMessage('Password must be at least 8 characters and include a letter and a number.');

const rules = {
  register: [
    name,
    email,
    phone,
    newPassword('password'),
    body('confirm_password')
      .custom((value, { req }) => value === req.body.password)
      .withMessage('The two passwords do not match.'),
  ],

  login: [
    body('email').trim().isEmail().withMessage('Enter a valid email address.').normalizeEmail({ gmail_remove_dots: false }),
    body('password').isLength({ min: 1, max: 72 }).withMessage('Enter your password.'),
  ],

  profile: [name, phone],

  changePassword: [
    body('current_password').isLength({ min: 1, max: 72 }).withMessage('Enter your current password.'),
    newPassword('new_password'),
    body('confirm_password')
      .custom((value, { req }) => value === req.body.new_password)
      .withMessage('The two new passwords do not match.'),
  ],

  newRequest: [
    param('category').isIn(CATEGORIES).withMessage('Unknown service category.'),
    body('housing_block').isIn(BLOCKS).withMessage('Choose a housing block from the list.'),
    body('flat_number')
      .trim()
      .matches(/^[A-Za-z0-9-]{1,10}$/).withMessage('Flat number can only have letters, numbers and "-" (max 10).'),
    body('address')
      .trim()
      .isLength({ min: 5, max: 200 }).withMessage('Address must be between 5 and 200 characters.'),
    body('description')
      .trim()
      .isLength({ min: 10, max: 1000 }).withMessage('Description must be between 10 and 1000 characters.'),
    body('urgency').isIn(URGENCIES).withMessage('Choose how urgent this is.'),
  ],

  updateRequest: [
    param('id').isInt({ min: 1 }).toInt(),
    body('status').isIn(STATUSES).withMessage('Choose a valid status.'),
    body('scheduled_for')
      .optional({ values: 'falsy' })
      .isISO8601().withMessage('Enter a valid date.'),
    body('admin_note')
      .optional({ values: 'falsy' })
      .trim()
      .isLength({ max: 500 }).withMessage('Note can be at most 500 characters.'),
  ],

  changeRole: [
    param('id').isInt({ min: 1 }).toInt(),
    body('role').isIn(['user', 'admin']).withMessage('Choose a valid role.'),
  ],

  // Search & filter options. Anything not in the allowed list is ignored.
  filters: [
    query('q').optional().trim().isLength({ max: 60 }),
    query('status').optional().isIn(['', ...STATUSES]),
    query('category').optional().isIn(['', ...CATEGORIES]),
    query('page').optional().isInt({ min: 1, max: 1000 }).toInt(),
  ],

  idParam: [param('id').isInt({ min: 1 }).toInt()],
};

// Turns validation errors into a simple { field: message } object
function getErrors(req) {
  const result = validationResult(req);
  if (result.isEmpty()) return null;
  const errors = {};
  for (const e of result.array()) {
    if (!errors[e.path]) errors[e.path] = e.msg;
  }
  return errors;
}

module.exports = { rules, getErrors, CATEGORIES, STATUSES, URGENCIES, BLOCKS };
