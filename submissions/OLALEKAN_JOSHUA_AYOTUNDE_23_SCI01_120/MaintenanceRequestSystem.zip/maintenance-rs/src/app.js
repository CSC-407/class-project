// Builds the Express application. server.js starts it.
// Kept separate so the tests can load the app without starting a server.
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);

const config = require('./config');
const { pool } = require('./db');
const { loadUser } = require('./middleware/auth');
const { provideToken, verifyToken } = require('./security/csrf');
const { notFound, errorHandler } = require('./middleware/errors');
const helpers = require('./helpers');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));
app.disable('x-powered-by'); // do not tell attackers we use Express

// Behind a host like Render, the real HTTPS connection ends at their proxy.
// This lets Express see the original protocol and visitor IP.
if (config.isProd) app.set('trust proxy', 1);

// ---- HTTPS: send any plain HTTP visit to HTTPS (production only) ----
if (config.isProd) {
  app.use((req, res, next) => {
    if (req.secure || req.path === '/health') return next();
    res.redirect(301, `https://${req.headers.host}${req.originalUrl}`);
  });
}

// ---- Security headers (Helmet) ----
// Content-Security-Policy: the browser only runs scripts and styles from OUR site.
// Even if an attacker managed to put a <script> into a page, it would be blocked.
app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'"],
        'style-src': ["'self'"],
        'img-src': ["'self'", 'data:'],
        'font-src': ["'self'"],
        'form-action': ["'self'"],
        'frame-ancestors': ["'none'"],
        'upgrade-insecure-requests': config.isProd ? [] : null,
      },
    },
    // HSTS: tells browsers to ALWAYS use HTTPS for this site (production only)
    strictTransportSecurity: config.isProd ? { maxAge: 31536000, includeSubDomains: true } : false,
    referrerPolicy: { policy: 'same-origin' },
  })
);

// ---- Request logging (error / log monitoring) ----
if (!config.isTest) {
  // Never log request bodies, because they can contain passwords
  app.use(morgan(config.isProd ? 'combined' : 'dev'));
}

// ---- Static files (CSS, JS, images) ----
app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: config.isProd ? '7d' : 0 }));

// ---- Form parsing with a size limit (stops very large bodies) ----
app.use(express.urlencoded({ extended: false, limit: '20kb' }));

// ---- Session management ----
app.use(
  session({
    store: new PgSession({ pool, tableName: 'session', pruneSessionInterval: config.isTest ? false : 60 * 15 }),
    name: 'mrs.sid',              // custom name, not the default "connect.sid"
    secret: config.sessionSecret, // signs the cookie so it cannot be changed
    resave: false,
    saveUninitialized: false,
    rolling: true,                // timer restarts on every visit (idle timeout)
    cookie: {
      httpOnly: true,             // JavaScript in the page cannot read the cookie
      sameSite: 'lax',            // cookie is not sent with most cross-site requests
      secure: config.isProd,      // cookie only travels over HTTPS in production
      maxAge: config.sessionMaxAgeMinutes * 60 * 1000,
    },
  })
);

// ---- CSRF tokens, current user, and shared page values ----
app.use(provideToken);
app.use(verifyToken);
app.use(loadUser);
app.use((req, res, next) => {
  res.locals.flash = req.session.flash || null;
  delete req.session.flash;
  res.locals.path = req.path;
  res.locals.supportPhone = config.supportPhone;
  res.locals.h = helpers;
  next();
});

// Pages that show personal data must not be stored in the browser cache
app.use((req, res, next) => {
  if (req.user) res.set('Cache-Control', 'no-store');
  next();
});

// ---- Routes ----
app.get('/health', (req, res) => res.json({ status: 'ok' })); // used by the host to check the app is alive
app.use('/', require('./routes/auth'));
app.use('/', require('./routes/pages'));
app.use('/', require('./routes/user'));
app.use('/admin', require('./routes/admin'));

// ---- Errors ----
app.use(notFound);
app.use(errorHandler);

module.exports = app;
