// One shared connection pool to PostgreSQL.
// IMPORTANT (SQL injection protection): every query in this app uses
// placeholders like $1, $2. User input is sent separately from the SQL text,
// so it can never change the meaning of the query.
const { Pool } = require('pg');
const config = require('./config');

const pool = new Pool({
  connectionString: config.databaseUrl,
  ssl: config.databaseSsl ? { rejectUnauthorized: false } : false,
  max: 10,
});

pool.on('error', (err) => {
  console.error('[db] unexpected error on idle client:', err.message);
});

module.exports = {
  pool,
  query: (text, params) => pool.query(text, params),
};
