// Builds the WHERE part of a search query safely.
// User input goes into the "params" list (as $1, $2 ...), never into the SQL text.

// In a LIKE search, % and _ are special characters. We escape them so a user
// typing "%" searches for a real "%" instead of matching everything.
function likeValue(text) {
  return '%' + String(text).replace(/[\\%_]/g, (c) => '\\' + c) + '%';
}

function buildRequestFilters({ q, status, category, userId }, searchColumns) {
  const where = [];
  const params = [];

  if (userId) {
    params.push(userId);
    where.push(`r.user_id = $${params.length}`);
  }
  if (status) {
    params.push(status);
    where.push(`r.status = $${params.length}`);
  }
  if (category) {
    params.push(category);
    where.push(`r.category = $${params.length}`);
  }
  if (q) {
    const refMatch = /^mr-?0*(\d+)$/i.exec(q.trim());
    if (refMatch) {
      params.push(Number(refMatch[1]));
      where.push(`r.id = $${params.length}`);
    } else {
      params.push(likeValue(q));
      const n = params.length;
      where.push('(' + searchColumns.map((c) => `${c} ILIKE $${n}`).join(' OR ') + ')');
    }
  }

  return { whereSql: where.length ? 'WHERE ' + where.join(' AND ') : '', params };
}

module.exports = { likeValue, buildRequestFilters };
