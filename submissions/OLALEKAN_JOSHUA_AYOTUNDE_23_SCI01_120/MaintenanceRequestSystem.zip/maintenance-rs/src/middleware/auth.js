// Access-control checks.
// These run BEFORE a page is shown. Hiding a link in the menu is not enough;
// the server itself checks who you are and what you are allowed to do.
const db = require('../db');

// Loads the logged-in user (if any) on every request.
// Only safe fields are loaded - never the password hash.
async function loadUser(req, res, next) {
  res.locals.currentUser = null;
  if (!req.session.userId) return next();
  try {
    const { rows } = await db.query(
      'SELECT id, full_name, email, phone, role, created_at FROM users WHERE id = $1',
      [req.session.userId]
    );
    if (!rows[0]) {
      // User was deleted: end the session
      return req.session.destroy(() => res.redirect('/login'));
    }
    req.user = rows[0];
    res.locals.currentUser = rows[0];
    next();
  } catch (err) {
    next(err);
  }
}

// Page needs a logged-in user
function requireAuth(req, res, next) {
  if (!req.user) {
    req.session.returnTo = req.originalUrl.startsWith('/') ? req.originalUrl : '/';
    req.session.flash = { type: 'info', message: 'Please log in to continue.' };
    return res.redirect('/login');
  }
  next();
}

// Page needs a specific role, e.g. requireRole('admin')
function requireRole(role) {
  return (req, res, next) => {
    if (!req.user) return requireAuth(req, res, next);
    if (req.user.role !== role) {
      const err = new Error('You do not have permission to view this page.');
      err.status = 403;
      return next(err);
    }
    next();
  };
}

// Login / register pages: logged-in users are sent to their home page
function guestOnly(req, res, next) {
  if (req.user) return res.redirect(req.user.role === 'admin' ? '/admin' : '/');
  next();
}

module.exports = { loadUser, requireAuth, requireRole, guestOnly };
