// Error handling.
// Users see a friendly message. Technical details (stack traces, SQL errors)
// are written to the server log only - never shown on the page.
const config = require('../config');
const helpers = require('../helpers');

function notFound(req, res, next) {
  const err = new Error('We could not find that page.');
  err.status = 404;
  next(err);
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  const status = err.status || err.statusCode || 500;

  if (status >= 500) {
    console.error(`[error] ${req.method} ${req.originalUrl}:`, err.stack || err.message);
  } else if (!config.isTest && status !== 404) {
    console.warn(`[warn] ${status} ${req.method} ${req.originalUrl}: ${err.message}`);
  }

  // Body too large, bad form data, etc.
  const message =
    status >= 500
      ? 'Something went wrong on our side. Please try again in a moment.'
      : err.type === 'entity.too.large'
        ? 'The form you sent is too large.'
        : err.message;

  // The error may happen before the normal page values were set up
  const l = res.locals;
  if (l.currentUser === undefined) l.currentUser = req.user || null;
  if (l.flash === undefined) l.flash = null;
  if (l.csrfToken === undefined) l.csrfToken = '';
  l.h = helpers;
  l.path = req.path;
  l.supportPhone = config.supportPhone;

  res.status(status);
  res.render('error', {
    title: status === 404 ? 'Page not found' : status === 403 ? 'Access denied' : 'Something went wrong',
    status,
    message,
  });
}

module.exports = { notFound, errorHandler };
