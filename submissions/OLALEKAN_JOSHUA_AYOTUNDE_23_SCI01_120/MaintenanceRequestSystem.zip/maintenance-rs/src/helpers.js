// Small helpers used inside the HTML templates.
const { icon } = require('./icons');

const CATEGORY_INFO = {
  electrical: { label: 'Electrical', icon: 'bolt', blurb: 'Lights, sockets, wiring, power' },
  plumbing: { label: 'Plumbing', icon: 'drop', blurb: 'Leaks, taps, toilets, drains' },
  carpentry: { label: 'Carpentry', icon: 'hammer', blurb: 'Doors, cupboards, furniture' },
  it: { label: 'IT', icon: 'wifi', blurb: 'Internet, network, devices' },
};

const STATUS_INFO = {
  open: { label: 'Open', step: 1 },
  scheduled: { label: 'Scheduled', step: 2 },
  solved: { label: 'Solved', step: 3 },
};

function formatDate(value) {
  if (!value) return '';
  const d = new Date(value);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'Africa/Lagos' });
}

function formatDateTime(value) {
  if (!value) return '';
  const d = new Date(value);
  return d.toLocaleString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: 'Africa/Lagos',
  });
}

// For <input type="date"> values
function isoDate(value) {
  if (!value) return '';
  const d = new Date(value);
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

function firstName(fullName) {
  return String(fullName || '').split(' ')[0];
}

function initials(fullName) {
  return String(fullName || '?')
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0].toUpperCase())
    .join('');
}

// Request reference shown to users, e.g. MR-00042
function ref(id) {
  return 'MR-' + String(id).padStart(5, '0');
}

// Builds a link with the current filters, changing one value
function filterLink(base, current, changes) {
  const params = new URLSearchParams();
  const merged = { ...current, ...changes };
  for (const [k, v] of Object.entries(merged)) {
    if (v !== undefined && v !== null && v !== '') params.set(k, v);
  }
  const qs = params.toString();
  return qs ? `${base}?${qs}` : base;
}

// Safe page number for lists (always a whole number from 1 to 1000)
function pageNumber(value) {
  const n = parseInt(value, 10);
  return Number.isInteger(n) && n >= 1 ? Math.min(n, 1000) : 1;
}

module.exports = {
  icon, pageNumber, CATEGORY_INFO, STATUS_INFO, formatDate, formatDateTime, isoDate, firstName, initials, ref, filterLink,
};
