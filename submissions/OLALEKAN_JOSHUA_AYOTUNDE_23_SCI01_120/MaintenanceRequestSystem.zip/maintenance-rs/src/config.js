// Reads settings from environment variables (.env file in development).
// Secrets are NEVER written in the code itself.
require('dotenv').config({ quiet: true });

const env = process.env.NODE_ENV || 'development';
const isProd = env === 'production';
const isTest = env === 'test';

const config = {
  env,
  isProd,
  isTest,
  port: Number(process.env.PORT) || 3000,
  databaseUrl: isTest
    ? process.env.TEST_DATABASE_URL || process.env.DATABASE_URL
    : process.env.DATABASE_URL,
  // Some hosts (like Render) need SSL for the database connection
  databaseSsl: process.env.DATABASE_SSL === 'true',
  sessionSecret: process.env.SESSION_SECRET,
  sessionMaxAgeMinutes: Number(process.env.SESSION_MAX_AGE_MINUTES) || 30,
  supportPhone: process.env.SUPPORT_PHONE || '+234 903 093 0463',
};

// Stop the app early if an important setting is missing.
if (!config.databaseUrl) {
  throw new Error('DATABASE_URL is not set. Copy .env.example to .env and fill it in.');
}
if (!config.sessionSecret || (isProd && config.sessionSecret.length < 32)) {
  throw new Error('SESSION_SECRET is missing or too short (use at least 32 random characters in production).');
}

module.exports = config;
