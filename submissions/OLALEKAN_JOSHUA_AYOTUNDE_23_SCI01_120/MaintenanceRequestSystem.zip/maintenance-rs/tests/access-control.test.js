// ACCESS-CONTROL / ROLE TESTING
const { app, db, request, resetDb, createUser, createRequest, loginAs, postForm } = require('./helpers');

beforeEach(resetDb);
afterAll(() => db.pool.end());

describe('Visitors who are not logged in', () => {
  test.each(['/profile', '/account', '/request/plumbing', '/requests/1', '/admin', '/admin/users', '/admin/logs'])(
    '%s redirects to the login page',
    async (url) => {
      const res = await request(app).get(url);
      expect(res.status).toBe(302);
      expect(res.headers.location).toBe('/login');
    }
  );

  test.each(['/', '/login', '/register', '/security', '/support', '/health'])('%s is public', async (url) => {
    const res = await request(app).get(url);
    expect(res.status).toBe(200);
  });
});

describe('Normal users (role: user)', () => {
  let ada, bola, agent;
  beforeEach(async () => {
    ada = await createUser({ email: 'ada@example.com' });
    bola = await createUser({ email: 'bola@example.com' });
    agent = await loginAs(ada);
  });

  test.each(['/admin', '/admin/users', '/admin/logs', '/admin/requests/1'])('cannot open %s (403)', async (url) => {
    await createRequest(bola.id);
    const res = await agent.get(url);
    expect(res.status).toBe(403);
    expect(res.text).toContain('You do not have permission');
  });

  test('cannot see another user\'s request by changing the number in the link', async () => {
    const bolaReq = await createRequest(bola.id, { description: 'Bola private request' });
    const res = await agent.get(`/requests/${bolaReq.id}`);
    expect(res.status).toBe(404); // "not found" - does not even reveal it exists
    expect(res.text).not.toContain('Bola private request');
  });

  test('can see their own request', async () => {
    const mine = await createRequest(ada.id, { description: 'My own leaking tap' });
    const res = await agent.get(`/requests/${mine.id}`);
    expect(res.status).toBe(200);
    expect(res.text).toContain('My own leaking tap');
  });

  test('cannot change a request status by sending the admin form directly', async () => {
    const mine = await createRequest(ada.id);
    const res = await postForm(agent, `/admin/requests/${mine.id}`, { status: 'solved' });
    expect(res.status).toBe(403);
    const { rows } = await db.query('SELECT status FROM requests WHERE id = $1', [mine.id]);
    expect(rows[0].status).toBe('open');
  });

  test('cannot make themselves admin through the admin form', async () => {
    const res = await postForm(agent, `/admin/users/${ada.id}/role`, { role: 'admin' });
    expect(res.status).toBe(403);
    const { rows } = await db.query('SELECT role FROM users WHERE id = $1', [ada.id]);
    expect(rows[0].role).toBe('user');
  });

  test('only sees their own requests in the list', async () => {
    await createRequest(ada.id, { description: 'Ada request one' });
    await createRequest(bola.id, { description: 'Bola request one' });
    const res = await agent.get('/profile');
    expect(res.text).toContain('Ada request one');
    expect(res.text).not.toContain('Bola request one');
  });
});

describe('Admins (role: admin)', () => {
  let admin, agent, ada;
  beforeEach(async () => {
    admin = await createUser({ email: 'admin@example.com', role: 'admin' });
    ada = await createUser({ email: 'ada@example.com' });
    agent = await loginAs(admin);
  });

  test('can see every user\'s requests', async () => {
    await createRequest(ada.id, { description: 'Ada request for admin' });
    const res = await agent.get('/admin');
    expect(res.status).toBe(200);
    expect(res.text).toContain('Ada request for admin');
  });

  test('can promote a user to admin, which ends that user\'s current sessions', async () => {
    const adaAgent = await loginAs(ada);
    const res = await postForm(agent, `/admin/users/${ada.id}/role`, { role: 'admin' }, '/admin/users');
    expect(res.status).toBe(302);
    const { rows } = await db.query('SELECT role FROM users WHERE id = $1', [ada.id]);
    expect(rows[0].role).toBe('admin');
    expect((await adaAgent.get('/profile')).status).toBe(302); // must log in again
  });

  test('cannot change their OWN role (prevents locking themselves out)', async () => {
    await postForm(agent, `/admin/users/${admin.id}/role`, { role: 'user' }, '/admin/users');
    const { rows } = await db.query('SELECT role FROM users WHERE id = $1', [admin.id]);
    expect(rows[0].role).toBe('admin');
  });

  test('cannot set an unknown role', async () => {
    await postForm(agent, `/admin/users/${ada.id}/role`, { role: 'superuser' }, '/admin/users');
    const { rows } = await db.query('SELECT role FROM users WHERE id = $1', [ada.id]);
    expect(rows[0].role).toBe('user');
  });

  test('role changes are written to the activity log', async () => {
    await postForm(agent, `/admin/users/${ada.id}/role`, { role: 'admin' }, '/admin/users');
    const res = await agent.get('/admin/logs?action=ROLE_CHANGED');
    expect(res.text).toContain('ada@example.com is now admin');
  });
});
