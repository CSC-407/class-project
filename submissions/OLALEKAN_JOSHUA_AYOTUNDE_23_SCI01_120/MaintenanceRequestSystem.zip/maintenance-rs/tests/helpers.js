// Shared helpers for the automated tests.
// Tests use a SEPARATE database (TEST_DATABASE_URL) that is wiped before each test file.
const request = require('supertest');
const app = require('../src/app');
const db = require('../src/db');
const migrate = require('../scripts/migrate');
const { hashPassword } = require('../src/security/passwords');

async function resetDb() {
  await migrate();
  await db.query('TRUNCATE requests, audit_logs, users, "session" RESTART IDENTITY CASCADE');
}

async function createUser({ name = 'Test User', email, password = 'Password123', role = 'user', phone = null } = {}) {
  const hash = await hashPassword(password);
  const { rows } = await db.query(
    'INSERT INTO users (full_name, email, phone, password_hash, role) VALUES ($1,$2,$3,$4,$5) RETURNING *',
    [name, email, phone, hash, role]
  );
  return { ...rows[0], password };
}

async function createRequest(userId, overrides = {}) {
  const r = {
    category: 'plumbing', housing_block: 'Block A', flat_number: '12', address: '14 Unity Road, Abuja',
    description: 'Kitchen sink is leaking badly.', urgency: 'normal', status: 'open', ...overrides,
  };
  const { rows } = await db.query(
    `INSERT INTO requests (user_id, category, housing_block, flat_number, address, description, urgency, status)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [userId, r.category, r.housing_block, r.flat_number, r.address, r.description, r.urgency, r.status]
  );
  return rows[0];
}

// Reads the CSRF token from a page, the same way a browser form would
async function getCsrf(agent, url = '/login') {
  const res = await agent.get(url);
  const match = /name="_csrf" value="([a-f0-9]+)"/.exec(res.text);
  if (!match) throw new Error(`No CSRF token found on ${url} (status ${res.status})`);
  return match[1];
}

// Returns a logged-in "browser" (cookie jar) for the given user
async function loginAs(user) {
  const agent = request.agent(app);
  const _csrf = await getCsrf(agent, '/login');
  const res = await agent.post('/login').type('form').send({ _csrf, email: user.email, password: user.password });
  if (res.status !== 302) throw new Error(`Login failed for ${user.email}: ${res.status}`);
  return agent;
}

// Sends a form with a valid CSRF token taken from "pageUrl"
async function postForm(agent, url, data, pageUrl = '/account') {
  const _csrf = await getCsrf(agent, pageUrl);
  return agent.post(url).type('form').send({ _csrf, ...data });
}

module.exports = { app, db, request, resetDb, createUser, createRequest, getCsrf, loginAs, postForm };
