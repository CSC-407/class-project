// LOGIN / REGISTRATION TESTING
const { app, db, request, resetDb, createUser, getCsrf, loginAs } = require('./helpers');

beforeEach(resetDb);
afterAll(() => db.pool.end());

async function register(agent, data) {
  const _csrf = await getCsrf(agent, '/register');
  return agent.post('/register').type('form').send({ _csrf, ...data });
}

const goodUser = {
  full_name: 'Chidi Obi',
  email: 'chidi@example.com',
  phone: '08012345678',
  password: 'StrongPass1',
  confirm_password: 'StrongPass1',
};

describe('Registration', () => {
  test('a new user can register and is logged in straight away', async () => {
    const agent = request.agent(app);
    const res = await register(agent, goodUser);
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/');

    const home = await agent.get('/');
    expect(home.text).toContain('Welcome, Chidi!');
  });

  test('the password is saved as a bcrypt hash, not as plain text', async () => {
    await register(request.agent(app), goodUser);
    const { rows } = await db.query('SELECT password_hash FROM users WHERE email = $1', [goodUser.email]);
    expect(rows[0].password_hash).not.toBe(goodUser.password);
    expect(rows[0].password_hash).toMatch(/^\$2[aby]\$\d{2}\$/);
  });

  test('two users with the same password get different hashes (salt)', async () => {
    await register(request.agent(app), goodUser);
    await register(request.agent(app), { ...goodUser, email: 'other@example.com' });
    const { rows } = await db.query('SELECT password_hash FROM users ORDER BY id');
    expect(rows[0].password_hash).not.toBe(rows[1].password_hash);
  });

  test('a duplicate email is rejected', async () => {
    await createUser({ email: goodUser.email });
    const res = await register(request.agent(app), goodUser);
    expect(res.status).toBe(422);
    expect(res.text).toContain('An account with this email already exists');
  });

  test('email is stored in lower case so "Chidi@Example.com" counts as the same email', async () => {
    await register(request.agent(app), { ...goodUser, email: 'Chidi@Example.COM' });
    const { rows } = await db.query('SELECT email FROM users');
    expect(rows[0].email).toBe('chidi@example.com');
  });

  test('a weak password is rejected', async () => {
    const res = await register(request.agent(app), { ...goodUser, password: 'short', confirm_password: 'short' });
    expect(res.status).toBe(422);
    expect(res.text).toContain('at least 8 characters');
  });

  test('passwords that do not match are rejected', async () => {
    const res = await register(request.agent(app), { ...goodUser, confirm_password: 'Different1' });
    expect(res.status).toBe(422);
    expect(res.text).toContain('do not match');
  });

  test('a user cannot make themselves Admin by adding role=admin to the form', async () => {
    await register(request.agent(app), { ...goodUser, role: 'admin' });
    const { rows } = await db.query('SELECT role FROM users WHERE email = $1', [goodUser.email]);
    expect(rows[0].role).toBe('user');
  });

  test('the form keeps typed values (except passwords) after an error', async () => {
    const res = await register(request.agent(app), { ...goodUser, confirm_password: 'Nope12345' });
    expect(res.text).toContain('value="Chidi Obi"');
    expect(res.text).not.toContain('StrongPass1');
  });
});

describe('Login', () => {
  let user;
  beforeEach(async () => { user = await createUser({ email: 'ada@example.com', password: 'Password123' }); });

  test('correct email and password logs the user in', async () => {
    const agent = await loginAs(user);
    const res = await agent.get('/profile');
    expect(res.status).toBe(200);
    expect(res.text).toContain('My requests');
  });

  test('wrong password shows a general error message', async () => {
    const agent = request.agent(app);
    const _csrf = await getCsrf(agent);
    const res = await agent.post('/login').type('form').send({ _csrf, email: user.email, password: 'WrongPass1' });
    expect(res.status).toBe(401);
    expect(res.text).toContain('Email or password is incorrect.');
  });

  test('unknown email shows the SAME message (does not reveal which emails exist)', async () => {
    const agent = request.agent(app);
    const _csrf = await getCsrf(agent);
    const res = await agent.post('/login').type('form').send({ _csrf, email: 'nobody@example.com', password: 'WrongPass1' });
    expect(res.status).toBe(401);
    expect(res.text).toContain('Email or password is incorrect.');
  });

  test('empty fields are rejected', async () => {
    const agent = request.agent(app);
    const _csrf = await getCsrf(agent);
    const res = await agent.post('/login').type('form').send({ _csrf, email: '', password: '' });
    expect(res.status).toBe(422);
  });

  test('account is locked after 5 wrong passwords, even if the 6th is correct', async () => {
    const agent = request.agent(app);
    for (let i = 0; i < 5; i++) {
      const _csrf = await getCsrf(agent);
      await agent.post('/login').type('form').send({ _csrf, email: user.email, password: 'Wrong' + i + 'xx' });
    }
    const _csrf = await getCsrf(agent);
    const res = await agent.post('/login').type('form').send({ _csrf, email: user.email, password: 'Password123' });
    expect(res.status).toBe(423);
    expect(res.text).toContain('locked');

    const { rows } = await db.query("SELECT COUNT(*)::int AS n FROM audit_logs WHERE action = 'ACCOUNT_LOCKED'");
    expect(rows[0].n).toBe(1);
  });

  test('admin goes to the admin dashboard after login', async () => {
    const admin = await createUser({ email: 'boss@example.com', role: 'admin' });
    const agent = request.agent(app);
    const _csrf = await getCsrf(agent);
    const res = await agent.post('/login').type('form').send({ _csrf, email: admin.email, password: admin.password });
    expect(res.headers.location).toBe('/admin');
  });

  test('after login the user is sent back to the page they wanted', async () => {
    const agent = request.agent(app);
    await agent.get('/request/it'); // not logged in -> remembered
    const _csrf = await getCsrf(agent);
    const res = await agent.post('/login').type('form').send({ _csrf, email: user.email, password: user.password });
    expect(res.headers.location).toBe('/request/it');
  });
});

describe('Logout and sessions', () => {
  test('logout ends the session; protected pages then redirect to login', async () => {
    const user = await createUser({ email: 'ada@example.com' });
    const agent = await loginAs(user);
    const _csrf = await getCsrf(agent, '/profile');
    const out = await agent.post('/logout').type('form').send({ _csrf });
    expect(out.status).toBe(302);

    const res = await agent.get('/profile');
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/login');
  });

  test('a NEW session ID is given at login (stops session fixation)', async () => {
    const user = await createUser({ email: 'ada@example.com' });
    const agent = request.agent(app);
    const before = await agent.get('/login');
    const cookieBefore = before.headers['set-cookie'][0].split(';')[0];

    const _csrf = /name="_csrf" value="([a-f0-9]+)"/.exec(before.text)[1];
    const res = await agent.post('/login').type('form').send({ _csrf, email: user.email, password: user.password });
    const cookieAfter = res.headers['set-cookie'][0].split(';')[0];
    expect(cookieAfter).not.toBe(cookieBefore);
  });

  test('changing the password logs out the user on other devices', async () => {
    const user = await createUser({ email: 'ada@example.com', password: 'Password123' });
    const phone = await loginAs(user);
    const laptop = await loginAs(user);

    const _csrf = await getCsrf(laptop, '/account');
    const res = await laptop.post('/account/password').type('form').send({
      _csrf, current_password: 'Password123', new_password: 'NewPassword9', confirm_password: 'NewPassword9',
    });
    expect(res.status).toBe(302);

    expect((await laptop.get('/profile')).status).toBe(200); // this device stays in
    expect((await phone.get('/profile')).status).toBe(302);  // other device is logged out
  });
});
