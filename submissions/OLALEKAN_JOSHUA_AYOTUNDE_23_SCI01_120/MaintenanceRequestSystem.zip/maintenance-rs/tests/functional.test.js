// FUNCTIONAL TESTING + FORM VALIDATION TESTING
const { app, db, request, resetDb, createUser, createRequest, loginAs, postForm } = require('./helpers');

beforeEach(resetDb);
afterAll(() => db.pool.end());

const validRequest = {
  housing_block: 'Block A',
  flat_number: '12',
  address: '14 Unity Road, Abuja',
  description: 'The kitchen sink is leaking under the cabinet.',
  urgency: 'high',
};

describe('Main user journey', () => {
  test('dashboard shows the four services from the design', async () => {
    const res = await request(app).get('/');
    for (const s of ['Electrical', 'Plumbing', 'Carpentry', 'IT']) expect(res.text).toContain(s);
    expect(res.text).toContain('What service do you need today?');
  });

  test('user sends a request -> sees it -> admin schedules it -> user sees "Scheduled"', async () => {
    const ada = await createUser({ email: 'ada@example.com', name: 'Ada Okafor' });
    const admin = await createUser({ email: 'admin@example.com', role: 'admin' });
    const adaAgent = await loginAs(ada);

    // 1. Send the request
    const sent = await postForm(adaAgent, '/request/plumbing', validRequest, '/request/plumbing');
    expect(sent.status).toBe(302);
    expect(sent.headers.location).toMatch(/^\/requests\/\d+$/);
    const id = sent.headers.location.split('/').pop();

    // 2. It shows on the detail page and in "Ongoing"
    const detail = await adaAgent.get(`/requests/${id}`);
    expect(detail.text).toContain('Your request has been sent');
    expect(detail.text).toContain('data-step="1"');
    expect((await adaAgent.get('/profile')).text).toContain('The kitchen sink is leaking');

    // 3. Admin schedules a visit with a note
    const adminAgent = await loginAs(admin);
    const upd = await postForm(adminAgent, `/admin/requests/${id}`,
      { status: 'scheduled', scheduled_for: '2026-11-02', admin_note: 'Plumber comes in the morning.' }, `/admin/requests/${id}`);
    expect(upd.status).toBe(302);

    // 4. User sees the new status, date and note
    const after = await adaAgent.get(`/requests/${id}`);
    expect(after.text).toContain('data-step="2"');
    expect(after.text).toContain('02 Nov 2026');
    expect(after.text).toContain('Plumber comes in the morning.');
  });

  test('user can update their name and phone', async () => {
    const ada = await createUser({ email: 'ada@example.com', name: 'Ada Okafor' });
    const agent = await loginAs(ada);
    const res = await postForm(agent, '/account', { full_name: 'Ada N. Okafor', phone: '+234 803 111 2222' });
    expect(res.status).toBe(302);
    const { rows } = await db.query('SELECT full_name, phone FROM users WHERE id = $1', [ada.id]);
    expect(rows[0]).toEqual({ full_name: 'Ada N. Okafor', phone: '+234 803 111 2222' });
  });

  test('changing password needs the correct current password', async () => {
    const ada = await createUser({ email: 'ada@example.com', password: 'Password123' });
    const agent = await loginAs(ada);
    const res = await postForm(agent, '/account/password',
      { current_password: 'WrongOne1', new_password: 'NewPassword9', confirm_password: 'NewPassword9' });
    expect(res.status).toBe(422);
    expect(res.text).toContain('current password is not correct');
  });
});

describe('Search and filter', () => {
  let agent, ada;
  beforeEach(async () => {
    ada = await createUser({ email: 'ada@example.com' });
    await createRequest(ada.id, { category: 'plumbing', description: 'Leaking pipe in bathroom', status: 'open' });
    await createRequest(ada.id, { category: 'electrical', description: 'Socket sparks in bedroom', status: 'scheduled' });
    await createRequest(ada.id, { category: 'it', description: 'Router keeps dropping', status: 'solved' });
    agent = await loginAs(ada);
  });

  test('search by words in the description', async () => {
    const res = await agent.get('/profile').query({ q: 'sparks' });
    expect(res.text).toContain('1 found');
    expect(res.text).toContain('Socket sparks');
  });

  test('search is not case-sensitive', async () => {
    const res = await agent.get('/profile').query({ q: 'ROUTER' });
    expect(res.text).toContain('1 found');
  });

  test('search by reference number (MR-00002)', async () => {
    const res = await agent.get('/profile').query({ q: 'MR-00002' });
    expect(res.text).toContain('1 found');
    expect(res.text).toContain('Socket sparks');
  });

  test('filter by status', async () => {
    const res = await agent.get('/profile').query({ status: 'solved' });
    expect(res.text).toContain('1 found');
    expect(res.text).toContain('Router keeps dropping');
  });

  test('filter by category', async () => {
    const res = await agent.get('/profile').query({ category: 'plumbing' });
    expect(res.text).toContain('1 found');
  });

  test('unknown filter values are ignored instead of crashing', async () => {
    const res = await agent.get('/profile').query({ status: 'hacked', category: 'x', page: '-5' });
    expect(res.status).toBe(200);
    expect(res.text).toContain('3 found');
  });

  test('admin can search by resident email', async () => {
    const admin = await createUser({ email: 'admin@example.com', role: 'admin' });
    const res = await (await loginAs(admin)).get('/admin').query({ q: 'ada@example' });
    expect(res.text).toContain('3 requests found');
  });

  test('lists are split into pages', async () => {
    for (let i = 0; i < 10; i++) await createRequest(ada.id, { description: `Extra request number ${i}` });
    const res = await agent.get('/profile');
    expect(res.text).toContain('Page 1 of 2');
    const page2 = await agent.get('/profile').query({ page: 2 });
    expect(page2.text).toContain('Page 2 of 2');
  });
});

describe('Form validation (server side)', () => {
  let agent;
  beforeEach(async () => {
    agent = await loginAs(await createUser({ email: 'ada@example.com' }));
  });

  const send = (data) => postForm(agent, '/request/plumbing', { ...validRequest, ...data }, '/request/plumbing');

  test.each([
    ['empty description', { description: '' }, 'Description must be between 10 and 1000'],
    ['too short description', { description: 'leak' }, 'Description must be between 10 and 1000'],
    ['too long description', { description: 'a'.repeat(1001) }, 'Description must be between 10 and 1000'],
    ['housing block not in the list', { housing_block: 'Block Z' }, 'Choose a housing block'],
    ['flat number with symbols', { flat_number: '12; DROP' }, 'Flat number can only have'],
    ['empty address', { address: '' }, 'Address must be between 5 and 200'],
    ['unknown urgency', { urgency: 'extreme' }, 'Choose how urgent'],
  ])('rejects %s', async (_name, data, message) => {
    const res = await send(data);
    expect(res.status).toBe(422);
    expect(res.text).toContain(message);
    const { rows } = await db.query('SELECT COUNT(*)::int AS n FROM requests');
    expect(rows[0].n).toBe(0);
  });

  test('extra spaces are trimmed before saving', async () => {
    await send({ flat_number: '  7B  ', address: '   5 Garden Close   ' });
    const { rows } = await db.query('SELECT flat_number, address FROM requests');
    expect(rows[0]).toEqual({ flat_number: '7B', address: '5 Garden Close' });
  });

  test('an unknown service category gives "not found"', async () => {
    expect((await agent.get('/request/gardening')).status).toBe(404);
  });

  test('admin must pick a date when setting status to Scheduled', async () => {
    const admin = await createUser({ email: 'admin@example.com', role: 'admin' });
    const req = await createRequest((await db.query('SELECT id FROM users WHERE email = $1', ['ada@example.com'])).rows[0].id);
    const res = await postForm(await loginAs(admin), `/admin/requests/${req.id}`, { status: 'scheduled' }, `/admin/requests/${req.id}`);
    expect(res.status).toBe(422);
    expect(res.text).toContain('Pick a visit date');
  });

  test('invalid email on registration is rejected', async () => {
    const guest = request.agent(app);
    const res = await postForm(guest, '/register',
      { full_name: 'Tunde', email: 'not-an-email', password: 'Password123', confirm_password: 'Password123' }, '/register');
    expect(res.status).toBe(422);
    expect(res.text).toContain('Enter a valid email address.');
  });
});
