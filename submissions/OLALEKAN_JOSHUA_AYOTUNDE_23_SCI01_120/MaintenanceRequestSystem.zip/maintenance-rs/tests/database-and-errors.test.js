// DATABASE TESTING + ERROR HANDLING TESTING
const { app, db, request, resetDb, createUser, createRequest, loginAs } = require('./helpers');

beforeEach(resetDb);
afterAll(() => db.pool.end());

describe('Database rules', () => {
  test('all tables exist', async () => {
    const { rows } = await db.query(
      "SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name"
    );
    expect(rows.map((r) => r.table_name)).toEqual(expect.arrayContaining(['users', 'requests', 'audit_logs', 'session']));
  });

  test('email must be unique', async () => {
    await createUser({ email: 'same@example.com' });
    await expect(createUser({ email: 'same@example.com' })).rejects.toThrow(/duplicate key/);
  });

  test('role can only be "user" or "admin"', async () => {
    await expect(createUser({ email: 'x@example.com', role: 'superadmin' })).rejects.toThrow(/check constraint/);
  });

  test('status can only be open, scheduled or solved', async () => {
    const u = await createUser({ email: 'x@example.com' });
    await expect(createRequest(u.id, { status: 'deleted' })).rejects.toThrow(/check constraint/);
  });

  test('category can only be one of the four services', async () => {
    const u = await createUser({ email: 'x@example.com' });
    await expect(createRequest(u.id, { category: 'gardening' })).rejects.toThrow(/check constraint/);
  });

  test('a request must belong to a real user', async () => {
    await expect(createRequest(9999)).rejects.toThrow(/foreign key/);
  });

  test('deleting a user also deletes their requests', async () => {
    const u = await createUser({ email: 'x@example.com' });
    await createRequest(u.id);
    await db.query('DELETE FROM users WHERE id = $1', [u.id]);
    const { rows } = await db.query('SELECT COUNT(*)::int AS n FROM requests');
    expect(rows[0].n).toBe(0);
  });

  test('new requests start as "open" with the right dates', async () => {
    const u = await createUser({ email: 'x@example.com' });
    const r = await createRequest(u.id);
    expect(r.status).toBe('open');
    expect(r.created_at).toBeInstanceOf(Date);
  });

  test('logins and failed logins are saved in the audit log', async () => {
    const u = await createUser({ email: 'x@example.com' });
    await loginAs(u);
    const { rows } = await db.query('SELECT action FROM audit_logs WHERE user_id = $1', [u.id]);
    expect(rows.map((r) => r.action)).toContain('LOGIN');
  });

  test('sessions are stored in the database', async () => {
    const u = await createUser({ email: 'x@example.com' });
    await loginAs(u);
    const { rows } = await db.query(`SELECT COUNT(*)::int AS n FROM "session" WHERE (sess->>'userId')::int = $1`, [u.id]);
    expect(rows[0].n).toBe(1);
  });
});

describe('Error handling', () => {
  test('unknown pages show a friendly 404 page', async () => {
    const res = await request(app).get('/this-page-does-not-exist');
    expect(res.status).toBe(404);
    expect(res.text).toContain('Page not found');
    expect(res.text).toContain('Go to the home page');
  });

  test('a non-number request id gives 404, not a crash', async () => {
    const u = await createUser({ email: 'x@example.com' });
    const res = await (await loginAs(u)).get('/requests/abc');
    expect(res.status).toBe(404);
  });

  test('a database failure shows a friendly 500 page WITHOUT technical details', async () => {
    const u = await createUser({ email: 'x@example.com' });
    const agent = await loginAs(u);

    const spy = jest.spyOn(console, 'error').mockImplementation(() => {});
    const original = db.query;
    db.query = jest.fn(async (text, params) => {
      if (/FROM requests/.test(text)) throw new Error('relation "requests" secret internal detail');
      return original(text, params);
    });

    const res = await agent.get('/profile');
    db.query = original;
    spy.mockRestore();

    expect(res.status).toBe(500);
    expect(res.text).toContain('Something went wrong on our side');
    expect(res.text).not.toContain('secret internal detail');
    expect(res.text).not.toMatch(/at .*\.js:\d+/); // no stack trace
  });

  test('health check endpoint answers for the hosting platform', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body).toEqual({ status: 'ok' });
  });
});
