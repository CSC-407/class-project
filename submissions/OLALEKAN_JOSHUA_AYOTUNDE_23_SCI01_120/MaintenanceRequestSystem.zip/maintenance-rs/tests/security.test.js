// SECURITY TESTING: SQL injection, XSS, CSRF, headers, cookies
const { app, db, request, resetDb, createUser, createRequest, getCsrf, loginAs, postForm } = require('./helpers');

beforeEach(resetDb);
afterAll(() => db.pool.end());

describe('SQL injection', () => {
  test('classic "OR 1=1" login bypass does not work', async () => {
    await createUser({ email: 'admin@example.com', role: 'admin' });
    const agent = request.agent(app);
    const _csrf = await getCsrf(agent);
    const res = await agent.post('/login').type('form').send({
      _csrf, email: "admin@example.com' OR '1'='1' --", password: "' OR '1'='1",
    });
    expect([401, 422]).toContain(res.status);
    expect((await agent.get('/admin')).status).toBe(302); // still not logged in
  });

  test('SQL in the password field is just treated as a wrong password', async () => {
    const user = await createUser({ email: 'ada@example.com' });
    const agent = request.agent(app);
    const _csrf = await getCsrf(agent);
    const res = await agent.post('/login').type('form').send({ _csrf, email: user.email, password: "x' OR 'x'='x" });
    expect(res.status).toBe(401);
  });

  test('SQL in the search box does not leak other users\' requests or break the database', async () => {
    const ada = await createUser({ email: 'ada@example.com' });
    const bola = await createUser({ email: 'bola@example.com' });
    await createRequest(ada.id, { description: 'Ada leaking pipe here' });
    await createRequest(bola.id, { description: 'Bola secret broken door' });

    const agent = await loginAs(ada);
    const res = await agent.get('/profile').query({ q: "' OR 1=1 --" });
    expect(res.status).toBe(200);
    expect(res.text).not.toContain('Bola secret');

    const drop = await agent.get('/profile').query({ q: "'; DROP TABLE users; --" });
    expect(drop.status).toBe(200);
    const { rows } = await db.query('SELECT COUNT(*)::int AS n FROM users');
    expect(rows[0].n).toBe(2); // table still there
  });

  test('"%" in search is treated as a normal character, not a wildcard', async () => {
    const ada = await createUser({ email: 'ada@example.com' });
    await createRequest(ada.id, { description: 'Normal problem text' });
    const agent = await loginAs(ada);
    const res = await agent.get('/profile').query({ q: '%' });
    expect(res.text).toContain('0 found');
  });

  test('a stored SQL-looking description is saved as plain text', async () => {
    const ada = await createUser({ email: 'ada@example.com' });
    const agent = await loginAs(ada);
    const evil = "Robert'); DROP TABLE requests;-- is my name";
    await postForm(agent, '/request/it', {
      housing_block: 'Block B', flat_number: '4', address: '1 Test Street', description: evil, urgency: 'low',
    }, '/request/it');
    const { rows } = await db.query('SELECT description FROM requests');
    expect(rows[0].description).toBe(evil);
  });
});

describe('Cross-Site Scripting (XSS)', () => {
  const payload = '<script>alert("hacked")</script><img src=x onerror=alert(1)>';

  test('a script in a request description is escaped on the user and admin pages', async () => {
    const ada = await createUser({ email: 'ada@example.com' });
    const admin = await createUser({ email: 'admin@example.com', role: 'admin' });
    const req = await createRequest(ada.id, { description: 'Broken tap ' + payload });

    const userPage = await (await loginAs(ada)).get(`/requests/${req.id}`);
    expect(userPage.text).not.toContain('<script>alert("hacked")</script>');
    expect(userPage.text).toContain('&lt;script&gt;');

    const adminPage = await (await loginAs(admin)).get('/admin');
    expect(adminPage.text).not.toContain('<img src=x onerror');
    expect(adminPage.text).toContain('&lt;img src=x onerror');
  });

  test('a script in the user\'s name is escaped in the header', async () => {
    const user = await createUser({ email: 'x@example.com', name: 'Eve' });
    await db.query('UPDATE users SET full_name = $1 WHERE id = $2', ['<script>evil()</script>', user.id]);
    const res = await (await loginAs(user)).get('/account');
    expect(res.text).not.toContain('<script>evil()</script>');
  });

  test('the registration form refuses HTML in the name', async () => {
    const agent = request.agent(app);
    const _csrf = await getCsrf(agent, '/register');
    const res = await agent.post('/register').type('form').send({
      _csrf, full_name: '<b>Eve</b>', email: 'eve@example.com', password: 'Password123', confirm_password: 'Password123',
    });
    expect(res.status).toBe(422);
  });

  test('Content-Security-Policy only allows scripts from our own site', async () => {
    const res = await request(app).get('/');
    const csp = res.headers['content-security-policy'];
    expect(csp).toContain("script-src 'self'");
    expect(csp).not.toContain('unsafe-inline');
    expect(csp).toContain("frame-ancestors 'none'");
  });
});

describe('CSRF protection', () => {
  test('a form sent WITHOUT the token is rejected', async () => {
    const ada = await createUser({ email: 'ada@example.com' });
    const agent = await loginAs(ada);
    const res = await agent.post('/request/plumbing').type('form').send({
      housing_block: 'Block A', flat_number: '1', address: '1 Test Street', description: 'Should not be saved', urgency: 'low',
    });
    expect(res.status).toBe(403);
    const { rows } = await db.query('SELECT COUNT(*)::int AS n FROM requests');
    expect(rows[0].n).toBe(0);
  });

  test('a form with a WRONG token is rejected', async () => {
    const agent = request.agent(app);
    await agent.get('/login');
    const res = await agent.post('/login').type('form').send({ _csrf: 'a'.repeat(64), email: 'a@b.com', password: 'x' });
    expect(res.status).toBe(403);
  });

  test('another user\'s token does not work in my session', async () => {
    const a = request.agent(app);
    const b = request.agent(app);
    const tokenA = await getCsrf(a);
    await b.get('/login');
    const res = await b.post('/login').type('form').send({ _csrf: tokenA, email: 'a@b.com', password: 'x' });
    expect(res.status).toBe(403);
  });
});

describe('Security headers and cookies', () => {
  test('important security headers are set', async () => {
    const res = await request(app).get('/login');
    expect(res.headers['x-powered-by']).toBeUndefined();
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-frame-options']).toBe('SAMEORIGIN');
    expect(res.headers['referrer-policy']).toBe('same-origin');
  });

  test('the session cookie is HttpOnly and SameSite', async () => {
    const res = await request(app).get('/login');
    const cookie = res.headers['set-cookie'][0];
    expect(cookie).toMatch(/^mrs\.sid=/);
    expect(cookie).toContain('HttpOnly');
    expect(cookie).toContain('SameSite=Lax');
  });

  test('pages with personal data are not cached by the browser', async () => {
    const ada = await createUser({ email: 'ada@example.com' });
    const res = await (await loginAs(ada)).get('/profile');
    expect(res.headers['cache-control']).toBe('no-store');
  });

  test('the password hash never appears in any page', async () => {
    const ada = await createUser({ email: 'ada@example.com' });
    const { rows } = await db.query('SELECT password_hash FROM users WHERE id = $1', [ada.id]);
    const agent = await loginAs(ada);
    for (const url of ['/', '/profile', '/account']) {
      const res = await agent.get(url);
      expect(res.text).not.toContain(rows[0].password_hash);
    }
  });

  test('very large form bodies are refused', async () => {
    const agent = request.agent(app);
    const _csrf = await getCsrf(agent);
    const res = await agent.post('/login').type('form').send({ _csrf, email: 'a@b.com', password: 'x'.repeat(30000) });
    expect(res.status).toBe(413);
  });
});
