-- Maintenance Request System - database schema (PostgreSQL)
-- Run with: npm run migrate
-- Safe to run more than once (uses IF NOT EXISTS).

CREATE TABLE IF NOT EXISTS users (
  id             SERIAL PRIMARY KEY,
  full_name      VARCHAR(80)  NOT NULL,
  email          VARCHAR(120) NOT NULL UNIQUE,
  phone          VARCHAR(20),
  password_hash  VARCHAR(100) NOT NULL,          -- bcrypt hash, never the real password
  role           VARCHAR(10)  NOT NULL DEFAULT 'user'
                 CHECK (role IN ('user', 'admin')),
  failed_logins  INTEGER      NOT NULL DEFAULT 0,
  locked_until   TIMESTAMPTZ,
  created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS requests (
  id             SERIAL PRIMARY KEY,
  user_id        INTEGER      NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category       VARCHAR(20)  NOT NULL
                 CHECK (category IN ('electrical', 'plumbing', 'carpentry', 'it')),
  housing_block  VARCHAR(20)  NOT NULL,
  flat_number    VARCHAR(10)  NOT NULL,
  address        VARCHAR(200) NOT NULL,
  description    TEXT         NOT NULL CHECK (char_length(description) <= 1000),
  urgency        VARCHAR(10)  NOT NULL DEFAULT 'normal'
                 CHECK (urgency IN ('low', 'normal', 'high')),
  status         VARCHAR(10)  NOT NULL DEFAULT 'open'
                 CHECK (status IN ('open', 'scheduled', 'solved')),
  scheduled_for  DATE,
  admin_note     VARCHAR(500),
  created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_requests_user   ON requests(user_id);
CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status);

-- Security log: logins, failed logins, role changes, status changes
CREATE TABLE IF NOT EXISTS audit_logs (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  action      VARCHAR(40)  NOT NULL,
  details     VARCHAR(300),
  ip_address  VARCHAR(60),
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Session store used by connect-pg-simple
CREATE TABLE IF NOT EXISTS "session" (
  "sid"    VARCHAR      NOT NULL PRIMARY KEY,
  "sess"   JSON         NOT NULL,
  "expire" TIMESTAMP(6) NOT NULL
);
CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "session" ("expire");
