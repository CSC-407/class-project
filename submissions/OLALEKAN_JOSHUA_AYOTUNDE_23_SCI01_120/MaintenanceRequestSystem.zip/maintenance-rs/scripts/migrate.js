// Creates the database tables from db/schema.sql
const fs = require('fs');
const path = require('path');
const { pool } = require('../src/db');

async function migrate() {
  const sql = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
  await pool.query(sql);
}

if (require.main === module) {
  migrate()
    .then(() => { console.log('Database tables are ready.'); return pool.end(); })
    .catch((err) => { console.error('Migration failed:', err.message); process.exit(1); });
}

module.exports = migrate;
