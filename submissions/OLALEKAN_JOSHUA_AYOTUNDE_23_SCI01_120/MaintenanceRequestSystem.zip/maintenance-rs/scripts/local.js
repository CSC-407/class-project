// EASY LOCAL START - no need to install PostgreSQL yourself.
//
//   npm run local        -> sets everything up (first time) and starts the website
//   npm run local:test   -> runs all the automated tests
//
// It starts a small private PostgreSQL server inside the project folder
// (in ".local-db"), creates the databases, writes a .env file, creates the
// tables and demo accounts, then starts the website on http://localhost:3000
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const ROOT = path.join(__dirname, '..');
const DB_DIR = path.join(ROOT, '.local-db');
const ENV_FILE = path.join(ROOT, '.env');
const PORT = 5433; // not 5432, so it never clashes with a PostgreSQL you may already have
const DB_PASSWORD = 'local_dev_only';

function writeEnvIfMissing() {
  if (fs.existsSync(ENV_FILE)) return false;
  const secret = crypto.randomBytes(48).toString('hex');
  const env = `# Created by "npm run local" for testing on your own computer.
NODE_ENV=development
PORT=3000
DATABASE_URL=postgres://postgres:${DB_PASSWORD}@localhost:${PORT}/mrs
TEST_DATABASE_URL=postgres://postgres:${DB_PASSWORD}@localhost:${PORT}/mrs_test
DATABASE_SSL=false
SESSION_SECRET=${secret}
SESSION_MAX_AGE_MINUTES=30
ADMIN_NAME=System Admin
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=AdminPass2026
SEED_DEMO=true
SUPPORT_PHONE=+234 903 093 0463
`;
  fs.writeFileSync(ENV_FILE, env);
  return true;
}

async function startDatabase() {
  const { default: EmbeddedPostgres } = await import('embedded-postgres');
  const firstTime = !fs.existsSync(path.join(DB_DIR, 'PG_VERSION'));
  const pg = new EmbeddedPostgres({
    databaseDir: DB_DIR,
    user: 'postgres',
    password: DB_PASSWORD,
    port: PORT,
    persistent: true,
    onLog: () => {},
    onError: (msg) => { if (String(msg).includes('FATAL')) console.error(String(msg)); },
  });

  if (firstTime) {
    console.log('First run: creating a private database in the ".local-db" folder...');
    await pg.initialise();
  }
  await pg.start();
  if (firstTime) {
    await pg.createDatabase('mrs');
    await pg.createDatabase('mrs_test');
  }
  console.log(`Database running on port ${PORT}.`);
  return pg;
}

function run(cmd, args, extraEnv = {}) {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, {
      cwd: ROOT,
      stdio: 'inherit',
      shell: process.platform === 'win32',
      env: { ...process.env, ...extraEnv },
    });
    child.on('close', (code) => resolve(code));
  });
}

async function main() {
  const mode = process.argv[2] || 'start';
  const createdEnv = writeEnvIfMissing();
  if (createdEnv) console.log('Created your .env settings file.');
  require('dotenv').config({ path: ENV_FILE, quiet: true });

  let pg;
  try {
    pg = await startDatabase();
  } catch (err) {
    console.error('\nCould not start the local database:', err.message);
    console.error('Tip: close any other "npm run local" window, then try again.');
    process.exit(1);
  }

  const stop = async () => {
    try { await pg.stop(); } catch (_) { /* already stopped */ }
  };

  if (mode === 'test') {
    const code = await run('npx', ['jest', '--runInBand'], { NODE_ENV: 'test' });
    await stop();
    process.exit(code);
  }

  // Create tables and the demo accounts (safe to run every time)
  if ((await run('node', ['scripts/migrate.js'])) !== 0) { await stop(); process.exit(1); }
  if ((await run('node', ['scripts/seed.js'])) !== 0) { await stop(); process.exit(1); }

  console.log('\n==============================================');
  console.log(' Website: http://localhost:3000');
  console.log(` Admin:    ${process.env.ADMIN_EMAIL}  /  ${process.env.ADMIN_PASSWORD}`);
  if (process.env.SEED_DEMO === 'true') console.log(' Resident: ada@example.com  /  DemoUser#2026');
  console.log(' Press Ctrl + C to stop.');
  console.log('==============================================\n');

  const code = await run('node', ['src/server.js']);
  await stop();
  process.exit(code);
}

// Ctrl + C: the website stops first, then the database is stopped above
process.on('SIGINT', () => {});

main();
