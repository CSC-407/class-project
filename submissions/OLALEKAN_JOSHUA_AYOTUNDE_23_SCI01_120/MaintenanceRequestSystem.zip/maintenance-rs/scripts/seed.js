// Creates the first Admin account from environment variables.
//   ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_NAME
// Optional: SEED_DEMO=true also adds a demo user and some sample requests.
const bcrypt = require('bcryptjs');
const { pool } = require('../src/db');
const { BCRYPT_ROUNDS } = require('../src/security/passwords');

async function seed() {
  const email = (process.env.ADMIN_EMAIL || '').toLowerCase().trim();
  const password = process.env.ADMIN_PASSWORD;
  const name = process.env.ADMIN_NAME || 'System Admin';

  if (!email || !password || password.length < 10) {
    throw new Error('Set ADMIN_EMAIL and ADMIN_PASSWORD (at least 10 characters) before seeding.');
  }

  const hash = await bcrypt.hash(password, BCRYPT_ROUNDS);
  await pool.query(
    `INSERT INTO users (full_name, email, password_hash, role)
     VALUES ($1, $2, $3, 'admin')
     ON CONFLICT (email) DO UPDATE SET role = 'admin'`,
    [name, email, hash]
  );
  console.log(`Admin account ready: ${email}`);

  if (process.env.SEED_DEMO === 'true') {
    const demoHash = await bcrypt.hash('DemoUser#2026', BCRYPT_ROUNDS);
    const { rows } = await pool.query(
      `INSERT INTO users (full_name, email, phone, password_hash)
       VALUES ('Ada Okafor', 'ada@example.com', '08031234567', $1)
       ON CONFLICT (email) DO UPDATE SET full_name = EXCLUDED.full_name
       RETURNING id`,
      [demoHash]
    );
    const uid = rows[0].id;
    const samples = [
      ['plumbing', 'Block A', '12', '14 Unity Road, Abuja', 'Kitchen sink is leaking under the cabinet.', 'high', 'scheduled', '2026-10-21'],
      ['electrical', 'Block A', '12', '14 Unity Road, Abuja', 'Bedroom socket sparks when a plug goes in.', 'high', 'open', null],
      ['carpentry', 'Block A', '12', '14 Unity Road, Abuja', 'Wardrobe door hinge is broken.', 'low', 'solved', '2026-10-04'],
      ['it', 'Block A', '12', '14 Unity Road, Abuja', 'Wi-Fi router in the hallway keeps dropping.', 'normal', 'open', null],
    ];
    const existing = await pool.query('SELECT COUNT(*)::int AS n FROM requests WHERE user_id = $1', [uid]);
    if (existing.rows[0].n === 0) {
      for (const s of samples) {
        await pool.query(
          `INSERT INTO requests (user_id, category, housing_block, flat_number, address, description, urgency, status, scheduled_for)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
          [uid, ...s]
        );
      }
    }
    console.log('Demo user ready: ada@example.com / DemoUser#2026');
  }
}

if (require.main === module) {
  seed()
    .then(() => pool.end())
    .catch((err) => { console.error('Seeding failed:', err.message); process.exit(1); });
}

module.exports = seed;
