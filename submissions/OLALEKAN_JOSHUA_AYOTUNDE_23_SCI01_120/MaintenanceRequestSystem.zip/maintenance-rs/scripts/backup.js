// Makes a backup copy of the database with pg_dump.
//   npm run backup
// Saves to backups/mrs-YYYY-MM-DD-HHMM.sql and keeps only the newest 7 files.
// To restore a backup:  psql "$DATABASE_URL" < backups/<file>.sql
require('dotenv').config({ quiet: true });
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('DATABASE_URL is not set.');
  process.exit(1);
}

const dir = path.join(__dirname, '..', 'backups');
fs.mkdirSync(dir, { recursive: true });
const stamp = new Date().toISOString().slice(0, 16).replace('T', '-').replace(':', '');
const file = path.join(dir, `mrs-${stamp}.sql`);

const out = fs.createWriteStream(file, { mode: 0o600 }); // only the owner can read it
const dump = spawn('pg_dump', ['--no-owner', '--clean', '--if-exists', url]);
dump.stdout.pipe(out);
dump.stderr.on('data', (d) => process.stderr.write(d));
dump.on('error', (err) => {
  console.error('Could not run pg_dump. Is PostgreSQL installed?', err.message);
  process.exit(1);
});
dump.on('close', (code) => {
  if (code !== 0) {
    fs.rmSync(file, { force: true });
    console.error('Backup failed.');
    process.exit(code);
  }
  // Keep only the newest 7 backups
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.sql')).sort().reverse();
  files.slice(7).forEach((f) => fs.rmSync(path.join(dir, f)));
  console.log(`Backup saved: backups/${path.basename(file)}`);
});
