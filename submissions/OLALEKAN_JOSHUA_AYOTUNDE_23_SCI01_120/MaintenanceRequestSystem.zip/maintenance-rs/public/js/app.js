// Small helpers that make forms nicer to use.
// The app still works fully if JavaScript is turned off.
document.addEventListener('DOMContentLoaded', function () {
  // 1. Show / hide password buttons
  document.querySelectorAll('.password-wrap').forEach(function (wrap) {
    var input = wrap.querySelector('input');
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'password-toggle';
    btn.textContent = 'Show';
    btn.setAttribute('aria-label', 'Show password');
    btn.addEventListener('click', function () {
      var hidden = input.type === 'password';
      input.type = hidden ? 'text' : 'password';
      btn.textContent = hidden ? 'Hide' : 'Show';
      btn.setAttribute('aria-label', hidden ? 'Hide password' : 'Show password');
    });
    wrap.appendChild(btn);
  });

  // 2. Character counter for text areas with data-count="max"
  document.querySelectorAll('textarea[data-count]').forEach(function (area) {
    var max = Number(area.getAttribute('data-count'));
    var counter = document.createElement('div');
    counter.className = 'char-count';
    counter.setAttribute('aria-live', 'polite');
    var update = function () { counter.textContent = area.value.length + ' / ' + max; };
    area.insertAdjacentElement('afterend', counter);
    area.addEventListener('input', update);
    update();
  });

  // 3. Ask before important changes (forms with data-confirm)
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!window.confirm(form.getAttribute('data-confirm'))) e.preventDefault();
    });
  });

  // 4. Close the account menu when clicking outside it
  document.addEventListener('click', function (e) {
    document.querySelectorAll('details.menu[open]').forEach(function (menu) {
      if (!menu.contains(e.target)) menu.removeAttribute('open');
    });
  });

  // 5. Stop double-submits (button is disabled after the first click)
  document.querySelectorAll('form[method="post"]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (e.defaultPrevented) return;
      var btn = form.querySelector('button[type="submit"]');
      if (btn) setTimeout(function () { btn.disabled = true; }, 0);
    });
  });
});
