/**
 * npm run db:backup — consistent copy of the database to backups/ (safe while the site is running,
 * using SQLite's online backup API). Keeps the 14 newest backups.
 * Uploaded images live in public/uploads: back that folder up too (see docs/DEPLOYMENT.md).
 */
const fs = require('fs');
const path = require('path');
const config = require('../src/config');
const db = require('../src/db');

const dir = path.join(config.root, 'backups');
fs.mkdirSync(dir, { recursive: true });
const target = path.join(dir, `blogx-${new Date().toISOString().replace(/[:.]/g, '-')}.db`);

db.backup(target)
  .then(() => {
    console.log('Backup written:', target);
    const files = fs.readdirSync(dir).filter((f) => f.endsWith('.db')).sort();
    for (const old of files.slice(0, Math.max(0, files.length - 14))) fs.unlinkSync(path.join(dir, old));
  })
  .catch((err) => { console.error('Backup failed:', err.message); process.exit(1); });
