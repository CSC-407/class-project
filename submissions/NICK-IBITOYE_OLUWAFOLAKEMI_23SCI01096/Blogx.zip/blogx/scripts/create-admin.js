/**
 * npm run create-admin -- "Full Name" email@example.com
 * Creates an administrator (or promotes an existing account). The password is typed in hidden,
 * so it never ends up in your shell history.
 */
const readline = require('readline');
const Users = require('../src/models/users');
const { validateNewUser } = require('../src/utils/validators');

const [name, email] = process.argv.slice(2);
if (!name || !email) { console.error('Usage: npm run create-admin -- "Full Name" email@example.com'); process.exit(1); }

const existing = Users.findForLogin(email.toLowerCase());
if (existing) {
  Users.setRole(existing.id, 'admin');
  Users.setStatus(existing.id, 'active');
  console.log(`${email} is now an administrator.`);
  process.exit(0);
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
rl._writeToOutput = (s) => { if (!rl.muted) rl.output.write(s); };
rl.question('Password for the new admin: ', (password) => {
  rl.close();
  process.stdout.write('\n');
  const { values, errors } = validateNewUser({ name, email, password, role: 'admin' });
  if (Object.keys(errors).length) { console.error('Not created:', Object.values(errors).join(' ')); process.exit(1); }
  Users.create(values);
  console.log(`Administrator ${values.email} created.`);
});
rl.muted = true;
