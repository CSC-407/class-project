#!/usr/bin/env bash
# Generates the abstract cover images used by the demo posts (public/images/covers/*.jpg).
# They are original artwork (colour gradients + soft shapes), so there are no copyright issues.
# Format: make_cover <name> <gradient start> <gradient end> <glow colour> <seed>
# Requires ImageMagick 6+ ("convert"). You do NOT need to run this: the images are already in the repo.
set -euo pipefail
cd "$(dirname "$0")/../public/images/covers"
make_cover () { # name colour1 colour2 colour3 seed
  # Diagonal two-colour gradient, two large soft "light" circles, a little film grain.
  local x1=$(( ($5 * 37) % 1000 + 200 )) y1=$(( ($5 * 53) % 500 + 150 ))
  local x2=$(( ($5 * 71) % 900 + 500 )) y2=$(( ($5 * 29) % 500 + 400 ))
  convert -size 1600x1000 -define gradient:angle=$(( ($5 * 47) % 180 )) gradient:"$2"-"$3" \
    \( -size 1600x1000 xc:none -fill "$4" -draw "circle $x1,$y1 $((x1+380)),$y1" \
       -fill "$2" -draw "circle $x2,$y2 $((x2+300)),$y2" -channel A -evaluate multiply 0.55 +channel -blur 0x140 \) \
    -compose over -composite -attenuate 0.12 +noise Gaussian -quality 82 -strip -interlace JPEG "$1.jpg"
}
make_cover lagos-dusk      '#e76f51' '#3d2c5c' '#ffd6a5' 11
make_cover green-signal    '#2a9d8f' '#0b2b33' '#b8f2e6' 22
make_cover indigo-wave     '#14213d' '#4361ee' '#a0c4ff' 33
make_cover coral-reef      '#f15b7a' '#f7b267' '#ffe5ec' 44
make_cover deep-forest     '#1b4332' '#081c15' '#95d5b2' 55
make_cover desert-sun      '#c8553d' '#f4d6a0' '#fff1d0' 66
make_cover night-code      '#0b132b' '#1c2541' '#5bc0be' 77
make_cover violet-haze     '#5a189a' '#c9184a' '#e0c3fc' 88
make_cover ocean-mist      '#03045e' '#00b4d8' '#caf0f8' 99
make_cover golden-hour     '#6f1d1b' '#d4a373' '#ffe8d6' 111
make_cover mint-paper      '#74c69d' '#e9f5ec' '#ffffff' 122
make_cover ember           '#370617' '#e85d04' '#ffba08' 133
echo "Covers generated."
