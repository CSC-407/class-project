# Blog.x — Presentation and Defence Notes

Plain-English explanations you can say out loud, plus likely examiner questions.

---

## 1. The project in 30 seconds

> "Blog.x is a blog management system modelled on Ghost. Visitors read and search posts; readers sign up to comment and subscribe; contributors, authors, editors and administrators write and manage content through a dashboard with a rich-text editor, a media library, categories with sub-categories, tags, scheduling and SEO settings. The focus is security: five roles enforced on the server, sanitized rich text, CSRF tokens, prepared statements, a strict Content Security Policy and more, tested with 184 automated tests and a 49-case manual test plan."

## 2. Architecture

> "It's a three-layer web app. The **browser** shows pages built on the server. The **Express server** runs every request through a chain of security checks before it reaches the page's code. The **database** is SQLite, one file, accessed only through prepared statements."

```
Browser ──HTTPS──▶ Express ──prepared statements──▶ SQLite (one file)
                    │
                    ├─ 1. Helmet headers (CSP, anti-clickjacking, HSTS)
                    ├─ 2. /theme.css (validated accent colour)
                    ├─ 3. Static files (dotfiles refused)
                    ├─ 4. Form parser (size-limited)
                    ├─ 5. Session (secure cookie)
                    ├─ 6. Page data + flash messages
                    ├─ 7. Load user from DB (role re-checked every request)
                    ├─ 8. CSRF token check
                    ├─ 9. Must-change-password check
                    ├─ 10. Route: requirePermission('…')  ← src/permissions.js
                    ├─ 11. Validate → model (sanitize, SQL) → EJS view (escaped)
                    └─ 12. Error handler (friendly page; details only in the log)
```

**Folder tour:** `src/permissions.js` = who can do what · `src/routes` = what each URL does · `src/models` = every database query · `src/middleware` = security checks · `src/utils/sanitize.js` = rich-text cleaning · `views` = templates · `public/js/editor.js` = the editor · `tests` = automated tests · `docs` = documentation.

**Why this stack?** "Express is the most widely used Node framework, so the security libraries are mature and well documented. Server-rendered pages mean one server to secure instead of a separate API and front end. SQLite needs no database server, so the whole project runs from one folder."

## 3. The roles (memorise this table)

| | Visitor | Reader | Contributor | Author | Editor | Admin |
|---|---|---|---|---|---|---|
| Read, search, subscribe | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Comment | | ✓ | ✓ | ✓ | ✓ | ✓ |
| Write drafts, submit for review | | | ✓ | ✓ | ✓ | ✓ |
| Publish own posts | | | | ✓ | ✓ | ✓ |
| Edit/publish anyone's, moderate, categories | | | | | ✓ | ✓ |
| Users, settings, exports, audit | | | | | | ✓ |

> "All of these rules are in one file, `src/permissions.js`. Every route asks that file before doing anything, so there's one place to read, test and change the rules."

## 4. Security, one line each

1. **Passwords:** "bcrypt with a salt and 12 rounds. A stolen database doesn't reveal passwords."
2. **RBAC:** "Every admin URL checks permissions on the server. Hiding a button isn't security; a reader typing /admin gets 403."
3. **IDOR:** "Writers can only open their own posts. Changing the number in the URL gives 'Access denied'."
4. **Workflow:** "A contributor can't publish even by editing the form. The server re-checks."
5. **Rich text:** "Post HTML goes through an allow-list. Only safe tags survive; scripts, onerror attributes and javascript: links are removed, on save and again on display."
6. **Escaping:** "Comments, names and search terms are plain text and escaped. <script> shows up as text."
7. **CSP:** "The browser may only run scripts from our own site and never inline code. There isn't a single inline script or style in the app, so the CSP needs no exceptions."
8. **SQL injection:** "Every query uses placeholders, so input is data, never code."
9. **CSRF:** "Every form has a secret token, even file uploads and the editor's background uploads."
10. **Sessions:** "HttpOnly, SameSite, Secure in production, 2-hour expiry, new id at sign-in, destroyed at sign-out, and the role is re-read from the database every request."
11. **Brute force:** "10 failed sign-ins per IP per 15 minutes, 5 per account → 15-minute lock, same message and timing for wrong email or password."
12. **Uploads:** "Checked by their real bytes, 3 MB max, no SVG, random file names."
13. **Extra:** "Honeypots and flood limits against spam, formula-safe CSV exports, random unsubscribe tokens, no IP addresses in analytics, temporary passwords that must be changed, and an audit log."

**Live demo (3 minutes):**
1. Sign in with `' OR '1'='1` (JavaScript off) → rejected.
2. As reader, open `/admin` → 403.
3. As author, open an editor's post `/admin/posts/7/edit` → 403.
4. As contributor, add a "Published" option with DevTools → refused.
5. Comment `<script>alert(1)</script>` → shown as text.
6. JavaScript off, publish a post containing `<img src=x onerror=alert(1)>` → stripped.
7. Delete the hidden `_csrf` field and save the profile → 403.
8. `npm test` → 184 passing.

## 5. Testing

> "Jest with Supertest sends real HTTP requests to the app. There are 184 automated tests. One suite checks every admin page against every role, 13 pages × 5 roles. Another throws ten real XSS payloads at the sanitizer. Each test file gets a fresh in-memory database and ignores `.env`, so results are the same on any machine. I also ran 49 manual test cases in Chrome, all passing, with screenshots. Browser testing found a real bug the automated tests couldn't: images inserted from the editor were silently lost because the picker dialog was still open. I fixed it and added a manual test for it."

## 6. Deployment

> "Locally it's `npm install`, copy `.env.example` to `.env`, `npm run db:reset`, `npm run dev`. On GitHub, Actions runs the tests on Node 22 and 24 plus a dependency audit on every push. For a live site, the Render blueprint deploys it with automatic HTTPS and a generated session secret. In production the app switches on Secure cookies and HSTS and refuses to start with a weak secret. Backups are one command, and both the database and uploads can sit on one persistent disk."

## 7. Likely questions

**Q: Why not just escape the post HTML like everything else?**
A: Then bold text and headings would show as raw tags. Posts need real HTML, so they go through an allow-list instead: anything not explicitly allowed is removed. Everything else stays escaped.

**Q: If you sanitize on save, why sanitize again on display?**
A: Defence in depth. If someone ever changed the database directly, or the rules improve later, old content is still cleaned before it reaches a browser. It costs about 7 ms for a very long post.

**Q: How do you stop a contributor from publishing?**
A: The publish option isn't shown to them, but more importantly the server checks `canPublishPost()` on every save and every status change. I tested it by adding the option with DevTools: the server refused.

**Q: Why are drafts 404 instead of 403?**
A: A 403 confirms the post exists. A 404 reveals nothing about unpublished work.

**Q: What stops comment spam?**
A: Sign-in is required, new readers' first comments are held for moderation (configurable), there's a 5-comments-per-10-minutes limit, and a hidden honeypot field catches bots.

**Q: How does scheduling work without a background job?**
A: A scheduled post is stored as "published" with a future publish time. Every public query only shows posts whose time has passed, so it appears automatically, with nothing to run.

**Q: What's the CSV injection issue?**
A: If someone subscribes with a name like `=HYPERLINK(...)`, Excel would run it as a formula when the admin opens the export. Cells starting with = + - or @ are prefixed so they display as text.

**Q: Which OWASP Top 10 (2021) risks are covered?**
A: A01 Broken Access Control (one permission file, server checks, IDOR, instant role changes); A02 Cryptographic Failures (bcrypt, HTTPS, Secure cookies); A03 Injection (prepared statements, sanitizing, escaping, CSP, CSV); A04 Insecure Design (server-enforced workflow, temporary passwords, last-admin rule); A05 Misconfiguration (Helmet, friendly errors, secrets in env, weak-secret refusal); A06 Vulnerable Components (0 npm audit issues, checked in CI); A07 Auth Failures (lockout, rate limit, session regeneration, no enumeration at sign-in); A08 Integrity (upload byte checks, no third-party scripts); A09 Logging (redacted logs, audit log); A10 SSRF (the server never fetches user-supplied URLs).

**Q: Biggest limitations?**
A: No email sending, so no newsletter delivery or password reset by email; free hosting resets SQLite; synchronous bcrypt; no 2FA. All of them are in the review's future improvements.
