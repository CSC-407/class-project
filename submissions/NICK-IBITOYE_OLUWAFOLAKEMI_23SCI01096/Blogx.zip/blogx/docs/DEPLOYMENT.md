# Blog.x — Deployment Guide

Three ways to run Blog.x, from simplest to most "real":

1. **Local server** on your laptop (demo / defence): Section 10
2. **GitHub Codespaces**, so a lecturer can run it from the repository with nothing installed: end of Section 10
3. **Live on the internet** with HTTPS on Render: Sections 1–9

---

## 1. Development vs production

| | Development (`NODE_ENV=development`) | Production (`NODE_ENV=production`) |
|---|---|---|
| Who uses it | You, while building and testing | Real readers and writers |
| Start command | `npm run dev` (restarts on every code change) | `npm start` |
| `SESSION_SECRET` | A development fallback is allowed | **Required**: 32+ random characters, not the placeholder, or the app refuses to start |
| Cookies | Work over http://localhost | `Secure` flag: only sent over HTTPS |
| HSTS header | Off (so localhost keeps working) | On: browsers must use HTTPS for a year |
| CSP `upgrade-insecure-requests` | Off | On |
| Static file caching | Off | 7 days (uploads 30 days) |
| Error details | Console and `logs/app.log`; visitors see friendly pages | Same, plus the host's log viewer |
| Database reset | `npm run db:reset` allowed | Blocked |
| Seeding | Demo passwords allowed (with a warning) | Refuses unless `SEED_ADMIN_PASSWORD` is set |

All switches live in `src/config.js` and are driven by environment variables, so the **same code** runs in both.

## 2. Environment variables

Secrets and settings are never written in the code.

- **Locally:** `cp .env.example .env` (PowerShell: `Copy-Item .env.example .env`) and edit `.env`.
- **On a host:** enter them in the host's dashboard.

`.env` is in `.gitignore`, so it is never uploaded. Only `.env.example` (placeholders) is committed. The automated tests ignore `.env` completely.

| Variable | Example | Purpose |
|---|---|---|
| `NODE_ENV` | `production` | Turns on production security settings |
| `PORT` | `3000` | Port to listen on (hosts usually set this) |
| `SITE_URL` | `https://blogx.onrender.com` | Public address, used in RSS, sitemap and canonical links |
| `SESSION_SECRET` | 96 random hex characters | Signs session cookies. Generate: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `SESSION_MINUTES` | `120` | Idle time before a session expires |
| `DB_FILE` | `data/blogx.db` or `/var/data/blogx.db` | SQLite database file |
| `UPLOAD_DIR` | `public/uploads` or `/var/data/uploads` | Where uploaded images are stored (served at `/uploads`) |
| `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` | your email / a strong password | First administrator, created by the seed script |
| `LOGIN_MAX_ATTEMPTS`, `LOCKOUT_MINUTES`, `LOGIN_RATE_LIMIT` | `5`, `15`, `10` | Brute-force protection |
| `TRUST_PROXY` | `true` | Set on Render/Railway/behind Nginx so HTTPS and client IPs are detected correctly |

## 3. Database configuration, migration and seeding

Blog.x uses **SQLite**: the whole database is a single file, with no database server to install.

| Command | What it does |
|---|---|
| `npm run db:migrate` | Creates any missing tables from `src/db/schema.sql`. Never deletes data. Also runs on every start. |
| `npm run db:seed` | Adds demo users (one per role), 4 categories with 6 sub-categories, 13 posts in every status, comments, subscribers and 30 days of view history. Skips anything that already exists. |
| `npm run db:reset` | **Development only.** Deletes the database and re-seeds it. Use it before a demo. |
| `npm run create-admin -- "Full Name" you@example.com` | Creates another administrator (the password is typed in hidden). |
| `npm run db:backup` | Consistent copy of the database into `backups/` (Section 8). |

When the server starts with an empty database, it seeds it automatically.

### The seeded administrator: change its password

| Email | Default password |
|---|---|
| `admin@blogx.test` (or `SEED_ADMIN_EMAIL`) | `ChangeMe2026!` (or `SEED_ADMIN_PASSWORD`) |

The default password is public (it's in this repository), so change it straight away:

1. Sign in as the admin.
2. Click your avatar (top right) → **Your account**.
3. Under **Security**, click **Change password**, enter the current password and a new one twice, then save.

Staff you invite later get a temporary password and are forced to choose their own at first sign-in.

## 4. Server configuration

- **Runtime:** Node.js 22 or newer (`"engines"` in `package.json`, `.nvmrc`).
- **Build:** `npm ci --omit=dev` (exact versions from `package-lock.json`, no test tools).
- **Start:** `npm start` (`node server.js`).
- **Reverse proxy / HTTPS:** provided by the host (Render, Railway) or Caddy/Nginx on a VPS. Set `TRUST_PROXY=true`.
- **Graceful shutdown:** `server.js` closes cleanly on `SIGTERM`/`SIGINT` (what hosts send on redeploys) and logs crashes before exiting.
- **Persistent storage:** both `DB_FILE` and `UPLOAD_DIR` must point at storage that survives restarts. With one disk mounted at `/var/data`, use `DB_FILE=/var/data/blogx.db` and `UPLOAD_DIR=/var/data/uploads`.
- **Dependencies:** `package.json` pins `sanitize-html` and overrides its HTML parser to a version that works on all Node 22 releases. `npm audit` reports 0 known vulnerabilities, and the CI workflow fails on any high-severity one.

## 5. Hosting and domain options (student budget)

| Host | Cost | Keeps data? | HTTPS | Notes |
|---|---|---|---|---|
| **Render** | Free web service | ❌ on free (resets on each restart); ✅ with a disk (paid, from about $7/month) | Automatic | Easiest. `render.yaml` included. Free tier sleeps after 15 minutes idle. |
| **Railway** | About $5 usage credit/month | ✅ volumes | Automatic | Mount a volume, set `DB_FILE` and `UPLOAD_DIR` inside it |
| **Fly.io** | Pay-as-you-go | ✅ volumes | Automatic | CLI based |
| **GitHub Codespaces** | Free hours with the GitHub Student Developer Pack | ✅ inside the codespace | Automatic forwarded URL | Best for "run it from GitHub" |
| **VPS** (DigitalOcean, Hetzner) | About $4–6/month (credit in the Student Pack) | ✅ | Free with Let's Encrypt via Caddy | Most control |

**Domain:** every host gives a free subdomain (e.g. `blogx.onrender.com`). For your own name, buy one from a registrar (a `.com` is roughly $10/year; the GitHub Student Pack includes a free `.me` from Namecheap; `.com.ng` from a NiRA-accredited registrar). Add it under the host's *Custom domains*, create the DNS record it shows (usually a `CNAME`), then set `SITE_URL` to the new address.

## 6. HTTPS / SSL

HTTPS encrypts everything between readers and the server, so passwords and session cookies can't be read on public Wi-Fi.

- **Render / Railway / Fly:** automatic and free (Let's Encrypt certificates, renewed automatically, also for custom domains).
- **VPS:** use **Caddy**, which gets and renews certificates by itself. The whole `Caddyfile`:
  ```
  blog.example.com {
      reverse_proxy localhost:3000
  }
  ```
- **In the app** (switched on by `NODE_ENV=production`): `Secure` cookies (`src/app.js`), HSTS and `upgrade-insecure-requests` (`src/middleware/security.js`), and `TRUST_PROXY=true` so Express knows the original request used HTTPS.

## 7. Deploying from your computer to live (Render)

### Step 1: put the project on GitHub

```bash
cd blogx
git init
git add .
git status            # .env, data/, node_modules/, logs/ must NOT be listed
git commit -m "Blog.x: secure blog management system"
git branch -M main
git remote add origin https://github.com/<your-username>/blogx.git
git push -u origin main
```

GitHub Actions (`.github/workflows/test.yml`) then runs all 184 tests on Node 22 and 24 plus `npm audit`. Check for the green tick in the **Actions** tab.

### Step 2: create the service on Render

1. Sign up at render.com with GitHub.
2. **New → Blueprint** → choose the repository. Render reads `render.yaml`.
3. When asked, enter `SITE_URL` (e.g. `https://blogx.onrender.com`) and a strong `SEED_ADMIN_PASSWORD`. `SESSION_SECRET` is generated for you.
4. **Apply.** The first deploy takes 2–4 minutes.
5. Open the URL, sign in as the admin and change the password (Section 3).

### Step 3: updating

```bash
git add .
git commit -m "Describe the change"
git push
```

Render redeploys automatically after each push.

> **Free-tier reminder:** without a disk, posts, accounts and uploads reset whenever the service restarts, and the demo content is re-created. That is fine for a demonstration. For real use, add the disk shown in `render.yaml` and set `DB_FILE` and `UPLOAD_DIR`.

## 8. Backup strategy

- **Database:** `npm run db:backup` writes `backups/blogx-<date-time>.db` using SQLite's online backup API, which is safe while the site is running. It keeps the 14 newest.
- **Uploaded images:** copy the `UPLOAD_DIR` folder as well (images are referenced by the database). For example, on Linux: `tar czf backups/uploads-$(date +%F).tar.gz public/uploads`.
- **Schedule:**
  - Linux/VPS (`crontab -e`): `0 2 * * * cd /srv/blogx && npm run db:backup && tar czf backups/uploads-$(date +\%F).tar.gz public/uploads`
  - Windows: Task Scheduler → daily → program `npm`, arguments `run db:backup`, start in the project folder.
  - Render with a disk: daily disk snapshots are automatic.
- **Off-site copy (3-2-1 rule):** 3 copies, on 2 kinds of storage, 1 off-site. Sync `backups/` weekly to Google Drive or OneDrive. Backups contain personal data (emails, comments), so keep them private. `backups/` is in `.gitignore`.
- **Restore:** stop the server, copy the backup over the database file, delete any `-wal`/`-shm` files beside it, restore the uploads folder, start the server.
- **Test a restore** once a month on a copy.

## 9. Error logging and monitoring

- **Application log:** `logs/app.log`, one JSON line per event (start-up, failed sign-ins, CSRF rejections, refused requests, crashes with stack traces). Passwords, tokens, cookies and card-like numbers are replaced with `[REDACTED]` automatically (`src/utils/logger.js`).
  - Follow it live: `tail -f logs/app.log` (PowerShell: `Get-Content logs\app.log -Wait`).
- **Audit log:** sign-ins, failures, lockouts, publishing, deletions, role changes, exports and settings changes, with time and IP. Admins read it at **Admin → Audit log**; the latest 8 are on the dashboard.
- **Host logs:** Render shows console output under **Logs**.
- **Uptime:** a free monitor at uptimerobot.com pointed at `/robots.txt` emails you if the site goes down (and keeps a free Render service awake).
- **Optional error tracking:** Sentry's free plan (`@sentry/node`) is listed under future improvements.
- **What to watch:** many `Failed sign-in` or `Login rate limit hit` lines from one IP (brute force), `CSRF token rejected`, `Request refused` with status 403 (people probing admin pages), and any `Unhandled error`.

## 10. Local demonstration (no internet hosting)

1. **Install Node.js 22 or 24 (LTS)** from nodejs.org. Check in a new terminal: `node -v` → `v22.x` or higher.
2. **Get the project:** unzip it (or `git clone`), open a terminal in the `blogx` folder (VS Code: Terminal → New Terminal).
3. **Install:** `npm install` (stay online).
4. **Settings:** `cp .env.example .env` (PowerShell: `Copy-Item .env.example .env`).
5. **Fresh demo data:** `npm run db:reset`.
6. **Start:** `npm run dev` → open **http://localhost:3000**. Stop with **Ctrl + C**.
7. **Show it on a phone on the same Wi-Fi:** run `ipconfig` (Windows) to find your IPv4 address, e.g. `192.168.0.12`, and open `http://192.168.0.12:3000` on the phone. Allow Node.js through the firewall if Windows asks.
8. **Before the defence:** `npm test` (184 passing) for the screen, then `npm run db:reset` for clean data. Keep a second browser window signed in as a different role to show permissions side by side.

### Running from GitHub with Codespaces

1. On the repository page: **Code → Codespaces → Create codespace on main**.
2. In its terminal: `npm install && cp .env.example .env && npm run dev`.
3. Click **Open in Browser** for port 3000. Codespaces gives it an HTTPS address automatically.
