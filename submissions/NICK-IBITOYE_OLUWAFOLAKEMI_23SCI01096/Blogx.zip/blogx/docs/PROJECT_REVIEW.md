# Blog.x — Project Review and Evaluation

## 1. What the application does

Blog.x is a blog management system: a public website where people read, search and discuss posts, and an admin dashboard where a team writes, reviews, publishes and manages content. Its look and workflow are modelled on [Ghost](https://ghost.org), a popular professional publishing platform: a clean, image-led public theme and a calm admin with a sidebar, a distraction-free editor and colour-coded post statuses.

Five kinds of account share the system, each with its own permissions:

| Role | Can… |
|---|---|
| Visitor (not signed in) | Read published posts, search, subscribe to the newsletter |
| Reader | + comment, manage own comments, profile and newsletter subscription |
| Contributor | + write drafts, upload images, submit posts for review (cannot publish) |
| Author | + publish, schedule and manage their own posts |
| Editor | + edit and publish anyone's posts, feature posts, manage categories, tags and comments, view subscribers and site-wide statistics |
| Administrator | + manage users and roles, site settings, subscriber export and the audit log |

**Technology:** Node.js + Express 5, server-rendered EJS templates, SQLite (better-sqlite3), sanitize-html, bcryptjs, Helmet, express-session with a SQLite session store, express-rate-limit, Multer, Jest + Supertest. No front-end framework and no third-party scripts.

## 2. Features implemented

**Admin dashboard**
- Role-aware dashboard: views in the last 30 and 7 days with a daily chart, published/scheduled/draft/review counts, comments awaiting moderation, subscriber and account counts, top posts, a review queue with one-click Publish, your recent posts, recent security events
- Post management with status tabs (all / drafts / in review / scheduled / published / archived), text search, filters by category, tag and author, five sort orders, pagination
- Categories with sub-categories (create, rename, move, delete only when empty) and tags (create, rename, delete)
- User management: invite staff with a temporary password, change roles, suspend/reactivate, delete (posts are handed over, never lost), search and filter by role
- General settings: site title, description, footer text, accent colour (with colour picker), posts per page, open/close registration, newsletter on/off, comments on/off, three moderation modes
- Audit log of the last 200 security-relevant events

**Content editor**
- Rich-text editing: paragraphs, H2/H3, bold, italic, quotes, bulleted and numbered lists, links, inline code, dividers, images, clear formatting; Ctrl+B / Ctrl+I / Ctrl+S; pasted text is cleaned
- Works without JavaScript too (plain HTML box)
- Feature image from the media library or 12 built-in covers; inline images uploaded straight from the editor
- Media library: upload (3 MB, JPG/PNG/WebP/GIF), alt text, search, delete (blocked while an image is in use)
- Tags with suggestions, category picker, excerpt with counter, automatic URL slug from the title
- Status workflow: draft → submit for review → published (or scheduled with a date and time in Lagos time) → archived
- SEO: meta title and description with live Google-style preview and character counters, canonical URL, noindex option; Open Graph tags; RSS feed; XML sitemap; robots.txt
- Word count and reading time; preview of unpublished posts; warning before leaving with unsaved changes

**Comments and readers**
- Reader sign-up (can be closed by the admin), profile with bio and website, password change, account deletion
- Comments for signed-in users, with moderation modes "hold all", "hold first comment, then trust" and "publish immediately"; approve, unapprove, mark as spam, delete; readers delete their own
- Newsletter sign-up from every page and at registration; one-click unsubscribe link with a random token; subscriber list with search and status filter; CSV export for admins
- Visitor view tracking per post per day; bots, repeat views in a session and the author's own views are not counted

**Public site**
- Home with site cover, role-aware welcome strip (guest / reader / staff), featured post, post grid, popular topics
- Post page with category path, author byline, reading time, feature image, tags, author card, comments, related posts
- Category (including sub-category posts), tag and author archives with sorting; search with category, tag and sort filters
- Fully responsive: 3 / 2 / 1 columns; slide-down menu on phones; admin sidebar becomes a slide-out menu

## 3. Security measures implemented

| # | Measure | Where | Attack prevented |
|---|---|---|---|
| 1 | bcrypt password hashing (12 rounds, salted), strong-password rule | `src/models/users.js`, `src/utils/validators.js` | Password theft from a stolen database |
| 2 | Sign-in / sign-out with full session destruction; sign-out is a POST with a token | `src/routes/auth.js` | Session misuse; forced logout from other sites |
| 3 | Role-based access control: one permission file, checked server-side on every request, roles re-read from the DB each time | `src/permissions.js`, `src/middleware/auth.js` | Broken access control (OWASP A01) |
| 4 | Ownership checks on posts, media and comments; writers only list their own posts | `canEditPost` / `canDeletePost` / `canDeleteMedia` / `canDeleteComment` | IDOR |
| 5 | Publishing workflow enforced on the server; contributors can't publish or feature | `src/routes/admin/posts.js` | Privilege escalation by form tampering |
| 6 | Allow-list HTML sanitizing of post bodies on save **and** on display; images only from our media library; external links get `rel="noopener noreferrer"` | `src/utils/sanitize.js` | Stored XSS, tracking pixels, tab-nabbing |
| 7 | Output escaping for every other user-supplied text; comments are plain text | all EJS views | Reflected and stored XSS |
| 8 | Strict CSP with no `unsafe-inline` (no inline scripts or styles anywhere; the accent colour comes from a validated `/theme.css`) | `src/middleware/security.js`, `src/app.js` | XSS (second layer), clickjacking, CSS injection |
| 9 | Prepared statements everywhere; sort orders from allow-lists | `src/models/*` | SQL injection |
| 10 | CSRF synchronizer tokens on every POST, including multipart uploads and the editor's fetch uploads (header) | `src/middleware/csrf.js`, `public/js/editor.js` | Cross-site request forgery |
| 11 | Session cookie HttpOnly, SameSite=Lax, Secure in production, 2-hour idle expiry; new session id at sign-in and password change | `src/app.js`, `src/routes/auth.js` | Session hijacking and fixation |
| 12 | Per-IP rate limit + per-account lockout; identical message and timing for unknown email and wrong password | `src/middleware/security.js`, `src/models/users.js` | Brute force, credential stuffing, user enumeration |
| 13 | Temporary passwords must be changed at first sign-in | `enforcePasswordChange()` | Shared/leaked initial passwords |
| 14 | Admins can't remove themselves; the last admin can't be removed; deleted writers' posts are transferred | `src/routes/admin/users.js` | Lock-out, data loss |
| 15 | Upload checks: magic bytes, 3 MB, SVG refused, random names, CSRF checked before writing | `src/middleware/upload.js` | Web shells, SVG XSS, path traversal |
| 16 | Honeypot fields, comment flood control, moderation | `src/routes/community.js` | Spam bots, flooding |
| 17 | CSV formula-injection protection in exports | `src/utils/csv.js` | Formula injection against admins |
| 18 | Unsubscribe via 192-bit random tokens; GET only shows a confirmation | `src/models/subscribers.js`, `src/routes/community.js` | Guessable links; unwanted state change on GET |
| 19 | Privacy-friendly analytics (no IPs, no tracking cookies) | `src/middleware/views.js` | Over-collection of personal data |
| 20 | Helmet headers (CSP, XFO, nosniff, Referrer-Policy, HSTS in production), no `X-Powered-By` | `src/middleware/security.js` | Clickjacking, MIME sniffing, downgrade |
| 21 | Secrets only in environment variables; app refuses weak production secrets; log redaction; friendly errors with a safe fallback; open-redirect guard; body-size limits | `src/config.js`, `src/utils/logger.js`, `src/middleware/errors.js`, `safeNext()` | Credential leaks, information disclosure, phishing, DoS |
| 22 | Audit log | `src/models/audit.js` | Undetected attacks |
| 23 | HTTPS configuration for production | `src/config.js`, `src/app.js`, `docs/DEPLOYMENT.md` | Eavesdropping, man-in-the-middle |
| 24 | Dependency hygiene: `npm audit` = 0 vulnerabilities, checked in CI | `package.json`, `.github/workflows/test.yml` | Vulnerable components (OWASP A06) |

## 4. Summary of testing results

**Automated:** 184 tests in 10 suites, **all passing** (15 November 2026). Coverage: 96% of lines, 92% of statements, 95% of functions, 79% of branches.

| Suite | Tests | Result |
|---|---|---|
| Permissions (unit) | 13 | All passed |
| HTML sanitizer, 10 XSS payloads (unit) | 15 | All passed |
| Validators, CSV, logging, uploads, redirects (unit) | 17 | All passed |
| Models: visibility, search, slugs, moderation, stats (unit) | 7 | All passed |
| Authentication and accounts | 22 | All passed |
| Access control (every admin page × every role, IDOR) | 39 | All passed |
| Posts and the publishing workflow | 14 | All passed |
| Comments, newsletter, views, public pages, feeds | 17 | All passed |
| Admin features | 23 | All passed |
| Attack simulations | 17 | All passed |

**Manual:** all 49 cases in `docs/TEST_PLAN.md` (14 functional, 6 login/registration, 5 validation, 14 security, 2 usability, 2 responsive, 2 error handling, 4 database) were executed in Google Chrome: **49 passed, 0 failed**. Screenshots are in `docs/evidence/`. No browser console errors or CSP violations occurred on any page.

## 5. Performance observations

Measured locally (Node 22, 100 sequential requests each):

| Page | Median | 95th percentile |
|---|---|---|
| Home | 3.7 ms | 5.6 ms |
| Post page (sanitized on display) | 3.1 ms | 9.0 ms |
| Search | 2.6 ms | 5.5 ms |
| Category archive (with sub-categories) | 2.8 ms | 5.3 ms |
| RSS feed | 1.1 ms | 2.0 ms |

- 200 simultaneous home-page requests completed in about 0.7 seconds.
- Page weight is small: home HTML about 14 KB, site CSS 24 KB, shared JS 8 KB, editor JS 12 KB (loaded only in the editor). No web fonts, frameworks, analytics or third-party scripts. The 12 cover images total 644 KB (about 54 KB each) and lazy-load below the fold.
- Sanitizing a 4,000-word post takes about 7 ms, so re-sanitizing on every display is affordable.
- Indexes on post status/date, author and category keep listing queries fast; WAL mode lets readers continue while a post is saved.
- **Bottleneck:** bcrypt at 12 rounds takes about 280 ms per hash. That is deliberate (it slows down password cracking), but `bcryptjs` runs synchronously, so a burst of sign-ins briefly delays other requests. See Future improvements.

## 6. Problems encountered and how they were solved

| Problem | Solution |
|---|---|
| **Images inserted from the editor silently disappeared.** Found by driving the editor in a real browser. The upload worked, but the image was inserted while the picker was still open; a modal `<dialog>` makes the page behind it inert, so the editor couldn't take focus and the insert did nothing. | Close the dialog first, then focus the editor, restore the caret position and insert. Also normalised same-site absolute image URLs (`http://host/uploads/…`), which some browsers produce while editing, back to `/uploads/…` in both the editor and the sanitizer, so they pass the allow-list. |
| **First paragraph not wrapped in `<p>`.** Typing into an empty contenteditable creates a bare text node. | On first focus the editor creates an empty paragraph and places the caret inside it. |
| **The HTML sanitizer's parser became ESM-only.** The latest `htmlparser2` can't be loaded by Jest or by early Node 22 releases; the older `sanitize-html` that used a CommonJS parser had a known vulnerability. | Kept the latest `sanitize-html` (0 vulnerabilities) and added an npm `overrides` entry pinning its parser to `htmlparser2` v10, which ships both CommonJS and ESM. Confirmed with `npm audit` and the 15 sanitizer tests. |
| **Tests failed only on my machine.** My `.env` set the sign-in rate limit to 10, and the test suite performs more failed logins than that, so tests started getting HTTP 429. | Test mode now ignores `.env` for limits and demo passwords, so `npm test` gives the same result on every machine and in CI. |
| **Rich text vs XSS.** A blog must store HTML, but HTML is exactly what XSS uses. | Allow-list sanitizing on save and again on display, plain-text comments, escaping everywhere else, plus a strict CSP. Ten real XSS payloads are in the tests. |
| **Accent colour vs CSP.** The admin's colour must reach the CSS, but the CSP forbids inline styles. | A small `/theme.css` route outputs only a strictly validated `#rrggbb` value (tested with a CSS-injection payload). |
| **CSRF on uploads.** Multipart bodies aren't readable until Multer runs, and the editor uploads with `fetch()`. | Multipart routes parse into memory, then verify the token (form field or `X-CSRF-Token` header) before anything touches the disk. |
| **Uploads and database on separate storage.** Hosts usually allow one persistent disk. | Added `UPLOAD_DIR` so both can live on the same disk. |
| **Contributors could publish by editing the form.** The publish option is only hidden from contributors in the page. | The server checks `canPublishPost()` on every save and status change; tested by adding the option with DevTools (TC-35) and by automated tests. |

## 7. Limitations

- **No email delivery.** Newsletter subscribers are collected and can unsubscribe, but posts are not actually emailed, and there is no "forgot password" email. Accounts created by an admin share their temporary password outside the app.
- **SQLite on free hosting resets.** Without a persistent disk, Render's free tier loses posts and uploads on restart. SQLite also allows one writer at a time, which suits a small team.
- **Rich-text editor uses `document.execCommand`.** It works in all current browsers but is a legacy API; complex content such as tables or embeds isn't supported.
- **No image resizing.** Uploads are stored as sent (up to 3 MB); large photos slow pages down.
- **Synchronous bcrypt** briefly blocks other requests during sign-ins.
- **Registration reveals existing emails** ("An account with this email already exists"); sign-in does not, and sign-up is rate-limited.
- **Account lockout can be abused** to lock a known user out for 15 minutes (a trade-off of every lockout scheme).
- **Rate-limit counters are in memory**, so they reset on restart and aren't shared between servers.
- **No two-factor authentication**; no comment replies or reactions; no post revision history; no static pages (About, Contact).
- **View counts are approximate:** bot detection uses the user-agent, which bots can fake.

## 8. Possible future improvements

1. **Send newsletters and password-reset emails** through a provider such as Resend or Brevo, with double opt-in and single-use, time-limited reset links.
2. **Two-factor authentication** (TOTP app codes) for editors and admins.
3. **Async password hashing** (`await bcrypt.hash`) or native **Argon2id**.
4. **PostgreSQL** (e.g. Neon free tier) for multiple writers and managed backups, keeping the same prepared-statement style.
5. **Image processing** with `sharp`: resize, convert to WebP, generate thumbnails and `srcset`.
6. A modern block editor (e.g. Tiptap/ProseMirror) with tables, embeds and autosave, still sanitized on the server.
7. **Revision history** and side-by-side diffs for posts.
8. Threaded comment replies, reactions and email notifications to authors.
9. **Redis** for rate limits and sessions when running more than one server.
10. Static pages, navigation menu editor and theme options in settings.
11. **Sentry** error tracking and an automated **OWASP ZAP** scan in CI.
12. A generic sign-up response plus email verification, to remove the email-enumeration risk.
