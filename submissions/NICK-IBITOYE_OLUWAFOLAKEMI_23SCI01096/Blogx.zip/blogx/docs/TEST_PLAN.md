# Blog.x — Test Plan and Test Results

## 1. Purpose and scope

This plan checks that **Blog.x** works correctly, is secure, and is usable on phones, tablets and computers.

| Area | What is checked | How |
|---|---|---|
| Functional | Reading, search & filters, categories/sub-categories, rich-text editor, media uploads, scheduling, review workflow, settings, newsletter, comments, user invites | Automated + manual |
| Login / registration | Sign-up, sign-in, wrong credentials, lockout, sign-out | Automated + manual |
| Form validation | Empty, wrong-format and tampered input, in the browser and on the server | Automated + manual |
| Security | SQL injection, XSS (reflected and stored), access control for 5 roles, IDOR, privilege escalation, CSRF, headers, cookies, uploads | Automated + manual |
| Usability | Role-specific navigation, clear feedback messages | Manual |
| Responsive | Phone (390 px) and tablet (768 px), public site and admin | Manual |
| Error handling | 404 page, login rate limit, no technical details shown | Automated + manual |
| Database | Password hashing, view counting, data ownership on delete, persistence | Automated + manual |

## 2. Test environment

- Node.js 22 or newer; Google Chrome (latest) plus one other browser
- Start from known data: `npm run db:reset`, then `npm run dev`, open http://localhost:3000
- Demo accounts (created by the seed script):

| Role | Email | Password |
|---|---|---|
| Administrator | admin@blogx.test | `ChangeMe2026!` |
| Editor | editor@blogx.test | `EditorPass2026` |
| Author | author@blogx.test | `AuthorPass2026` |
| Contributor | contributor@blogx.test | `ContribPass2026` |
| Reader | reader@blogx.test | `ReaderPass2026` |

## 3. Automated tests

**Framework:** Jest (test runner) + Supertest (sends real HTTP requests to the app without a browser). Every test file starts with a fresh in-memory database, so tests never touch your real data, and test mode ignores your `.env` file.

| File | Type | Covers |
|---|---|---|
| `tests/unit/permissions.test.js` | Unit | The whole role/permission matrix, ownership rules for posts, media and comments |
| `tests/unit/sanitize.test.js` | Unit | 10 XSS payloads against the rich-text sanitizer; allowed formatting; image and link rules |
| `tests/unit/utils.test.js` | Unit | Validators, CSV formula-injection protection, log redaction, upload byte-checking, open-redirect guard, Lagos-time scheduling |
| `tests/unit/models.test.js` | Unit | Public visibility (drafts, scheduled, archived), sub-category listings, search, slugs, tags, moderation modes, view stats |
| `tests/integration/auth.test.js` | Integration | Sign-up, sign-in per role, lockout, rate limit, cookies, session regeneration, sign-out, profile, password change, temporary passwords |
| `tests/integration/access.test.js` | Integration | Every admin page × every role; visitors redirected; IDOR; drafts hidden; instant role changes; per-role menus |
| `tests/integration/posts.test.js` | Integration | Contributor → review → publish workflow, tampering, scheduling, archiving, SEO output, stored XSS, filters |
| `tests/integration/community.test.js` | Integration | Comments and moderation, honeypot, flood control, newsletter + token unsubscribe, view counting, search, RSS, sitemap |
| `tests/integration/admin.test.js` | Integration | Dashboards per role, categories/sub-categories, tags, media library, comment moderation, subscribers & CSV, users, settings, audit log |
| `tests/integration/security.test.js` | Integration | SQL injection, reflected XSS, CSP (no inline scripts/styles anywhere), CSRF, headers, 404, dotfiles, 413 limit, theme.css injection |

```bash
npm test                  # all 184 tests
npm run test:coverage     # plus a coverage report in coverage/lcov-report/index.html
npx jest tests/integration/security.test.js     # one file
npx jest -t "IDOR"                              # tests whose name matches
```

**Last run (15 November 2026):** 10 suites, **184 tests passed, 0 failed**. Coverage: 96% of lines, 92% of statements, 95% of functions, 79% of branches.

## 4. How to run the manual tests yourself

1. `npm run db:reset` so you start from the same data, then `npm run dev`.
2. Open http://localhost:3000 in Chrome. Use a **private/incognito window** when a test says "visitor" or "logged out".
3. Follow the **Steps**, compare with **Expected Result**, and write what you saw in **Actual Result**. Mark **Pass** or **Fail**.
4. Tools:
   - **Chrome DevTools** (F12): *Elements* to remove hidden fields or add options; *Network* to see status codes and headers; *Application → Cookies* for cookie flags.
   - **Turn JavaScript off** to test server-side validation: F12 → Ctrl+Shift+P → type "Disable JavaScript".
   - **Device mode** (Ctrl+Shift+M) for phone and tablet sizes.
   - **DB Browser for SQLite** (free) to open `data/blogx.db`. Close it before restarting the app.
5. Take screenshots of the security tests as evidence.

## 5. Test cases and results

**Executed:** 15 November 2026, Google Chrome, desktop window 1366×900 (TC-42 at 390×844, TC-43 at 768×1024), starting from `npm run db:reset`. The steps were carried out by a browser-automation script driving a real Chrome window exactly as written; every Actual Result records what the browser showed. Screenshots are in [`docs/evidence/`](evidence/).

| Test ID | Test Case | Steps | Expected Result | Actual Result | Status (Pass/Fail) |
|---|---|---|---|---|---|
| **Functional** | | | | | |
| TC-01 | Home page for a visitor | Logged out, open `/` | Site title and description, a "reading as a guest" strip with Create account / Sign in, one large featured post, a grid of post cards, popular topics, subscribe box, dark footer | Site title "Blog.x" and description shown; strip says "You're reading as a guest. Create a free…" with Create account / Sign in; featured post "Ten habits that keep your web app secure" shown large; 8 more post cards; 10 popular topics; subscribe box and footer. [Screenshot](evidence/TC-01.png) | **Pass** |
| TC-02 | Search posts | Click the 🔍 icon, type `lagos`, Search | Only posts mentioning Lagos are listed with a result count | 2 results for “lagos”: What we learned launching a product in Lagos; A weekend in Abeokuta. | **Pass** |
| TC-03 | Filter and sort search results | On the results from TC-02 choose Category = Business and Sort = Most read, Search | Only the Business post about Lagos remains | With category Business + "Most read": 1 result for “lagos” — What we learned launching a product in Lagos. Food post about Yaba no longer listed. | **Pass** |
| TC-04 | Category with sub-categories | Click **Technology** in the header | Sub-category links (AI, Security, Web Development) and posts from all of them are shown | Technology page shows sub-category links (AI, Security, Web Development) and 4 posts from its sub-categories (AI, SECURITY, TECHNOLOGY, WEB DEVELOPMENT). [Screenshot](evidence/TC-04.png) | **Pass** |
| TC-05 | Read a post | Click the featured post | Category path, title, author, date, reading time, feature image, formatted text, tags, comments section and related posts | Post opened: category path "TECHNOLOGY / SECURITY", byline "CO Chidi Okeke 12 Nov 2026 · 1 min read", feature image, formatted body (headings, quote, list), tags ['Beginners', 'Security', 'Tutorials'], "2 comments", 3 related posts. | **Pass** |
| TC-06 | Write and publish with the rich-text editor | Sign in as author → New post. Type a title (watch the URL slug fill in). In the body type text, make some **bold** (Ctrl+B), make a line a heading (H2), turn text into a link (🔗). Add a feature image (built-in cover). Choose category Technology › Web Development, tags "Tutorials, Manual Testing", status Published, then Publish | "Post published" message; the post appears on the home page with bold text, the heading and the link | Signed in → /admin. Slug filled in automatically ("manual-test-my-first-published-post"). Saved with "Post published. View post". Post is on the home page and shows bold text, an H2 heading and a working link; tags and category shown. [Screenshot](evidence/TC-06.png) [Screenshot 2](evidence/TC-06-editor.png) | **Pass** |
| TC-07 | Upload an image inside the editor | While writing (TC-06) click 🖼 → Upload new image → choose a JPG | Image is saved to the media library under a random name and appears inside the published post | Image uploaded from inside the editor; saved to the media library as /uploads/f6b752b0ab0f1235bfc256608521c9af.jpg (random name, original "inline.jpg") and displays inside the published post. | **Pass** |
| TC-08 | Schedule a post | New post, status Published, Publish date 3 days ahead, Publish | "Post scheduled for …"; the post's public URL gives 404; it is listed under Posts → Scheduled | "Post scheduled for 2026-11-18 16:47 (Lagos time)." Public URL returns HTTP 404; post listed under Posts → Scheduled with a green "Scheduled" label. | **Pass** |
| TC-09 | Contributor review workflow | Sign in as contributor → New post → Status options; choose Submit for review. Sign in as editor → Dashboard → Publish | Contributor sees only Draft / Submit for review. Editor's dashboard lists it under "Waiting for review"; after Publish it is live | Contributor status options: ['draft', 'review'] (no Publish). "Submitted for review. An editor will take a look." Editor dashboard listed it under "Waiting for review"; after Publish the public page returns HTTP 200. [Screenshot](evidence/TC-09.png) [Screenshot 2](evidence/TC-09-queue.png) | **Pass** |
| TC-10 | Categories and sub-categories | As editor → Categories: add "Sport"; add "Football" with parent Sport; delete Football (confirm) | Both created, Football shown indented under Sport; delete works after confirmation | "Category “Sport” added." then "Sub-category “Football” added." — tree shows Football indented under Sport. Deleting it (after the confirm pop-up): "“Football” deleted." [Screenshot](evidence/TC-10.png) | **Pass** |
| TC-11 | General settings | As admin → Settings: change site title and accent colour (#14b886), Save; open the site | "Settings saved"; site title and button colour change everywhere | "Settings saved." Home page title is now "Blog.x Lagos" and accent buttons turned green (rgb(20, 184, 134)). [Screenshot](evidence/TC-11.png) | **Pass** |
| TC-12 | Newsletter subscribe / unsubscribe | Logged out: enter an email in the footer Subscribe box. Open its unsubscribe link `/unsubscribe/<token>` (token from the subscribers table), click Unsubscribe | Subscribed message. The link first asks for confirmation (nothing changes on just opening it); after the button the status is unsubscribed | "You're subscribed! Look out for new posts from Blog.x." Opening the unsubscribe link showed a confirmation (status still subscribed); after the button: "You're unsubscribed", status unsubscribed. | **Pass** |
| TC-13 | Comment moderation | Sign up as a new reader, comment on a post. In another (logged-out) window view the post. As editor → Comments → Pending → Approve | Reader sees "Awaiting approval", the public doesn't see it; after approval it appears publicly | New reader commented: "Thanks! Your comment will appear once a moderator approves it." — shown to them as "Awaiting approval", hidden from the public. Editor approved it in Comments → Pending; it now appears publicly. [Screenshot](evidence/TC-13.png) | **Pass** |
| TC-14 | Invite a staff member | As admin → Staff & members → Invite user: author with a temporary password. Sign in as that user, try `/admin`, then set a new password | The new user is forced to the "Set your password" page until they choose their own password, then reaches the dashboard | "Bisi Writer can now sign in as Author with the temporary password. They will be asked to c…" On first sign-in the new author was sent to /account/password; opening /admin redirected back there. After setting her own password she reached /admin. [Screenshot](evidence/TC-14.png) | **Pass** |
| **Login / registration** | | | | | |
| TC-15 | Valid registration | Sign up with a name, new email, strong password (twice), tick terms | Reader account created and signed in; home greets them by name | Registration as "Kola Ajayi" (TC-13) created a reader account and signed him in immediately (home greeting "Welcome back, Kola. You're subscribed to the newsletter."). | **Pass** |
| TC-16 | Valid login → dashboard | Sign in as author@blogx.test | Lands on the admin Dashboard with a welcome message; sidebar has no Users/Settings | Author signed in and landed on /admin with message "Welcome back, Chidi."; sidebar shows Posts and Media only (no Users/Settings). | **Pass** |
| TC-17 | Wrong password | Sign in as reader@blogx.test with `WrongPass2026` | "Incorrect email or password.", password field cleared | Red message "Incorrect email or password.", stayed on sign-in, password field cleared. [Screenshot](evidence/TC-17.png) | **Pass** |
| TC-18 | Unknown email | Sign in with `nobody@example.com` | **Exactly the same** message as TC-17 | Message "Incorrect email or password.", identical to TC-17. [Screenshot](evidence/TC-18.png) | **Pass** |
| TC-19 | Account lockout | Create an account, enter a wrong password 5 times, then the right one | After the 5th failure: "locked for 15 minutes"; the correct password is also refused | Attempts 1–4: "Incorrect email or password." Attempt 5: "Too many failed attempts. For your security this account is locked for 15 minutes." The correct password was then also refused. [Screenshot](evidence/TC-19.png) | **Pass** |
| TC-20 | Sign out | Sign in, avatar menu → Sign out, press Back, open `/account` | "You have been signed out."; `/account` sends you to sign-in | "You have been signed out." After pressing Back and opening /account: redirected to /signin?next=%2Faccount with "Please sign in to continue." | **Pass** |
| **Form validation** | | | | | |
| TC-21 | Empty registration form | Open Sign up, press Create account with nothing filled. Repeat with JavaScript disabled | Red messages under each required field, both times (browser and server); no account | With JavaScript: 5 red messages (e.g. "Name is required."). With JavaScript off the server returned 4: "Please enter your name.", "Please enter a password.", "Please accept the terms to create an account." No account created. [Screenshot](evidence/TC-21.png) | **Pass** |
| TC-22 | Weak password and mismatch | Sign up: password `password`; then `BlogxPass2026` / `BlogxPass2027` | "at least 10 characters…" then "Passwords do not match." | Weak password: "Password must be at least 10 characters." Mismatch: "Passwords do not match." | **Pass** |
| TC-23 | Post editor validation | As author: title `Hi`, Canonical URL `javascript:alert(1)`, Save. Repeat with JavaScript off | Title and canonical URL errors from the browser and from the server; nothing saved | Browser: "Post title must be at least 3 characters.", "Canonical URL must start with https://". Server (JavaScript off): "Title must be at least 3 characters." and "Canonical URL must be a full web address starting with https://" Nothing saved. [Screenshot](evidence/TC-23.png) | **Pass** |
| TC-24 | Bypass browser validation | JavaScript off. Sign up with email `abc`, everything else valid | Server refuses: "Please enter a valid email address." | With JavaScript off the form was submitted; the server refused it: "Please enter a valid email address." No account created. [Screenshot](evidence/TC-24.png) | **Pass** |
| TC-25 | Settings: malicious colour | As admin → Settings. F12: remove the field's pattern; enter `red;}body{display:none`; Save | Server refuses: "Accent colour must look like #ff1a75."; the site's colours are unchanged | Browser check removed via DevTools; server refused: "Accent colour must look like #ff1a75." /theme.css still ":root{--accent:#ff1a75;}". [Screenshot](evidence/TC-25.png) | **Pass** |
| **Security** | | | | | |
| TC-26 | SQL injection in sign-in | JavaScript off. Email and password `' OR '1'='1` | Normal "Incorrect email or password."; no database error; not signed in | With JavaScript off (so the payload reaches the server): login rejected with "Incorrect email or password."; no database error shown; not signed in. [Screenshot](evidence/TC-26.png) | **Pass** |
| TC-27 | SQL injection in search | Search `' UNION SELECT email, password_hash FROM users --` | "0 results"; no data or errors shown | "0 results for “' UNION SELECT email, password_hash FROM users --”" and "No posts match your search."; no emails, hashes or errors. [Screenshot](evidence/TC-27.png) | **Pass** |
| TC-28 | XSS in a comment | As reader comment `<script>alert('xss')</script> Nice post`; view the post in another window | Comment shown as text; no alert box | Comment shown on the post as plain text: "<script>alert('xss')</script> Nice post"; no alert box appeared. [Screenshot](evidence/TC-28.png) | **Pass** |
| TC-29 | Stored XSS in a post body | JavaScript off (the editor shows the raw HTML box). As author publish a post whose HTML is `<p>Safe paragraph</p><script>alert(document.cookie)</script><img src=x onerror=alert(1)><a href="javascript:alert(1)">click me</a><iframe src="https://evil.com"></iframe>`. Open it | Only the safe parts are saved; no alert, no iframe, the link has no javascript: target | Post published through the raw HTML box (JavaScript off). Saved content is exactly: <p>Safe paragraph</p><a>click me</a> — script, onerror image, javascript: link target and iframe removed; no alert on the public page. [Screenshot](evidence/TC-29.png) | **Pass** |
| TC-30 | XSS in the search box | Search `<script>alert(1)</script>` | Text appears literally; no alert | Search box shows the text literally ("<script>alert(1)</script>"), result line "0 results for “<script>alert(1)</script>”"; no alert. [Screenshot](evidence/TC-30.png) | **Pass** |
| TC-31 | Reader opens admin pages | Signed in as reader, type `/admin` and `/admin/posts/new` | "403 Access denied" for both | /admin → HTTP 403 "Access denied"; /admin/posts/new → HTTP 403 "Access denied". [Screenshot](evidence/TC-31.png) | **Pass** |
| TC-32 | Author opens admin-only pages | Signed in as author, open `/admin/users`, `/admin/settings`, `/admin/comments` | 403 for all; those links are not in the author's sidebar | Author: /admin/users → 403, /admin/settings → 403, /admin/comments → 403 ("Access denied"). Those links are also absent from the author's sidebar. [Screenshot](evidence/TC-32.png) | **Pass** |
| TC-33 | Logged-out user opens protected pages | Incognito: `/admin`, `/admin/posts`, `/account` | Redirected to Sign in with "Please sign in to continue." | /admin → /signin?next=%2Fadmin; /admin/posts → /signin?next=%2Fadmin%2Fposts; /account → /signin?next=%2Faccount, each with "Please sign in to continue." [Screenshot](evidence/TC-33.png) | **Pass** |
| TC-34 | IDOR: editing someone else's post | As author open `/admin/posts/<id of an editor's post>/edit` | "Access denied: You can only edit your own posts" | Author opened the editor's post at /admin/posts/7/edit: HTTP 403 "You can only edit your own posts. Published posts are edited by editors." [Screenshot](evidence/TC-34.png) | **Pass** |
| TC-35 | Contributor tries to self-publish | As contributor, new post; F12 → add `<option value="published">` to Status; choose it and Save | Server refuses with "Contributors cannot publish…"; post not created | Contributor added a "Published" option with DevTools and saved: HTTP 400, "Contributors cannot publish. Choose “Submit for review” and an editor will publish it." Post not created. [Screenshot](evidence/TC-35.png) | **Pass** |
| TC-36 | CSRF: missing token | Signed in as reader → Your account. F12 → delete the hidden `_csrf` input in the profile form; change your name; Save | "Access denied … could not be verified"; name unchanged | "Access denied" (HTTP 403): "Your session form expired or the request could not be verified. Please go back, refresh the page and try again." Name still "Ngozi Eze". [Screenshot](evidence/TC-36.png) | **Pass** |
| TC-37 | Security headers and cookie flags | F12 → Network → reload home → first request → Headers; Application → Cookies | CSP, X-Frame-Options, nosniff, Referrer-Policy present, no X-Powered-By; cookie `bx.sid` HttpOnly, SameSite Lax, with expiry | Headers: Content-Security-Policy ("default-src 'self';script-src 'self';style-src…"), X-Frame-Options SAMEORIGIN, X-Content-Type-Options nosniff, Referrer-Policy strict-origin-when-cross-origin; no X-Powered-By. Cookie bx.sid: HttpOnly=True, SameSite=Lax, has an expiry (2 h idle). | **Pass** |
| TC-38 | Malicious upload | As author → Media. Rename a text file containing PHP to `shell.png`; F12 remove the form's checks; Upload | "Please upload a real JPG, PNG, WebP or GIF image."; nothing added | PHP file renamed shell.png uploaded with the browser check bypassed: "Please upload a real JPG, PNG, WebP or GIF image." Nothing added to the library. [Screenshot](evidence/TC-38.png) | **Pass** |
| TC-39 | Draft privacy | Open the draft "Notes on password managers" (`/posts/notes-on-password-managers`) as a visitor, a reader, then its author | 404 for visitor and reader; the author sees it with a "Preview" banner | Draft URL: visitor HTTP 404, reader HTTP 404; its author sees it with the yellow "Preview · This post is draft" banner (HTTP 200). [Screenshot](evidence/TC-39.png) [Screenshot 2](evidence/TC-39-preview.png) | **Pass** |
| **Usability** | | | | | |
| TC-40 | Navigation per role | Compare the header (visitor), avatar menu (reader), and admin sidebar (author vs admin) | Each role only sees what it can use | Visitor header: Sign in, Sign up. Reader menu: Ngozi Eze, Reader, Your account, Sign out. Author sidebar: B., Blog.x, Dashboard, View site, Posts, Drafts, In review, Scheduled, Published, Media. Admin sidebar adds Categories, Tags, Comments, Subscribers, Staff & members, Settings, Audit log. | **Pass** |
| TC-41 | Clear feedback | Sign in; dismiss the message with × | Green success message after actions, red for errors; dismissible | Sign-in showed "Welcome back, Ngozi." with a green edge (rgb(48, 164, 108)); × removed it. Errors (TC-17, TC-21, TC-23) appear in red next to the field or at the top. | **Pass** |
| **Responsive** | | | | | |
| TC-42 | Phone (390 px) | DevTools device mode iPhone 12: home, a post, search, sign-in, security; then admin dashboard, posts, users, editor | Single-column feed, ☰ menu, no sideways scrolling; admin sidebar becomes a slide-out menu | At 390 px: 1-column post feed; category links tucked into the ☰ menu (hidden True, opens True); no sideways scrolling on 5 public pages or 4 admin pages; admin sidebar becomes a slide-out menu (opens True). [Phone/tablet](evidence/TC-42.png) [Admin](evidence/TC-42-admin.png) | **Pass** |
| TC-43 | Tablet (768 px) | iPad size on the same pages | Two-column feed, no sideways scrolling, admin sidebar behind ☰ | At 768 px: 2-column post feed with the full category menu in the header; no sideways scrolling on public or admin pages; admin sidebar is hidden until the ☰ button is tapped (opens True). [Phone/tablet](evidence/TC-43.png) [Admin](evidence/TC-43-admin.png) | **Pass** |
| **Error handling** | | | | | |
| TC-44 | 404 page | Open `/posts/this-does-not-exist` | Friendly "Page not found" with Home and Search buttons; no technical details | HTTP 404 "Page not found" — "We couldn't find that page. It may have been moved, unpublished or never existed." with Home and Search buttons; no technical details. [Screenshot](evidence/TC-44.png) | **Pass** |
| TC-45 | Sign-in rate limit | Fail sign-in 10 times with different emails, then once more | 11th attempt: "Too many sign-in attempts from your network…" (HTTP 429) | Attempts 1–10 returned HTTP 401. Attempt 11 returned HTTP 429: "Too many sign-in attempts from your network. Please wait 15 minutes and try again." [Screenshot](evidence/TC-45.png) | **Pass** |
| **Database** | | | | | |
| TC-46 | Passwords are hashed | Open `data/blogx.db` → users table | Every `password_hash` starts with `$2b$`; no readable passwords | Opened data/blogx.db: all 9 users have a 60-character password_hash starting "$2b$" (bcrypt); no readable passwords. | **Pass** |
| TC-47 | View counting | Note a post's `view_count`; open the post, refresh, then open it in a new incognito window | +1 for the first view, no change on refresh (same session), +1 for the new session; no IP stored | view_count 600; a visit from the headless test browser (identifies as "HeadlessChrome") was ignored as a bot (600); a normal Chrome visit → 601; refreshing in the same session → 601 (not counted again); a new browser session → 602. No IP address stored in post_views. | **Pass** |
| TC-48 | Deleting a writer keeps their posts | As admin delete the contributor's account | Their posts now belong to the admin; nothing lost | "Amara Bello's account was deleted. Any posts they wrote now belong to you." The contributor's 4 posts now belong to the admin (author_id 1); no posts lost. | **Pass** |
| TC-49 | Data persists after restart | Stop the server (Ctrl+C), start it, sign in as the reader created in TC-13 | Account and approved comment still there | Server stopped (Ctrl+C) and restarted. Kola (created in TC-13) signed in again, and his approved comment is still on the post. | **Pass** |

## 6. Summary

| Area | Cases | Passed | Failed |
|---|---|---|---|
| Functional | 14 | 14 | 0 |
| Login / registration | 6 | 6 | 0 |
| Form validation | 5 | 5 | 0 |
| Security | 14 | 14 | 0 |
| Usability | 2 | 2 | 0 |
| Responsive | 2 | 2 | 0 |
| Error handling | 2 | 2 | 0 |
| Database | 4 | 4 | 0 |
| **Total** | **49** | **49** | **0** |

Automated: 184 / 184 passed.

**Notes from testing**
- During development, browser testing of the editor found a real bug before this run: images uploaded from inside the editor were silently not inserted, because the picker dialog was still open (a modal dialog blocks focus on the page behind it). Fixed by closing the dialog first; covered by TC-07. See the Project Review, section 6.
- TC-47 shows the bot filter working: the automation browser announces itself as "HeadlessChrome", so its visit was correctly not counted; a normal Chrome user-agent was used for the counted visits.

**Before your defence:** repeat a few cases yourself (TC-17, TC-26, TC-29, TC-31, TC-35, TC-36 make a good live demo) and update those rows if your lecturer wants results from your own machine.
