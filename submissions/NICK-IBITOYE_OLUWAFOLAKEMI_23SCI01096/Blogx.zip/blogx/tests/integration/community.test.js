/** Comments, moderation, newsletter, view tracking, public pages, search, feeds. */
const { setup, agent, as, postForm, csrfFrom, post, db } = require('../helpers');
const Settings = require('../../src/models/settings');

let app;
beforeAll(() => { app = setup(); });
const SLUG = 'ten-habits-that-keep-your-web-app-secure';

describe('comments', () => {
  test('visitors must sign in to comment', async () => {
    const page = await agent(app).get(`/posts/${SLUG}`);
    expect(page.text).toContain('to comment');
    const a = agent(app);
    const _csrf = await csrfFrom(a, `/posts/${SLUG}`);
    const res = await a.post(`/posts/${SLUG}/comments`).type('form').send({ _csrf, body: 'Anonymous!' });
    expect(res.headers.location).toMatch(/^\/signin/);
  });

  test("a new reader's first comment is held; once approved, later ones go straight up", async () => {
    const a = agent(app);
    await postForm(a, '/signup', { name: 'New Reader', email: 'newreader@example.com', password: 'Reader20266x', confirmPassword: 'Reader20266x', terms: 'on' }, '/signup');
    await postForm(a, `/posts/${SLUG}/comments`, { body: 'My very first comment' }, `/posts/${SLUG}`);
    const c = db.prepare("SELECT * FROM comments WHERE body = 'My very first comment'").get();
    expect(c.status).toBe('pending');
    expect((await a.get(`/posts/${SLUG}`)).text).toContain('Awaiting approval'); // author sees own pending
    expect((await agent(app).get(`/posts/${SLUG}`)).text).not.toContain('My very first comment'); // public doesn't
    const editor = await as(app, 'editor');
    await postForm(editor, `/admin/comments/${c.id}/status`, { status: 'approved' }, '/admin/comments');
    expect((await agent(app).get(`/posts/${SLUG}`)).text).toContain('My very first comment');
    await postForm(a, `/posts/${SLUG}/comments`, { body: 'Second comment, trusted now' }, `/posts/${SLUG}`);
    expect(db.prepare("SELECT status FROM comments WHERE body = 'Second comment, trusted now'").get().status).toBe('approved');
  });

  test('comments are plain text: a script is shown as text, not run', async () => {
    const r = await as(app, 'reader');
    await postForm(r, `/posts/${SLUG}`.concat('/comments'), { body: '<script>alert("xss")</script> nice' }, `/posts/${SLUG}`);
    const page = await agent(app).get(`/posts/${SLUG}`);
    expect(page.text).toContain('&lt;script&gt;alert(&#34;xss&#34;)&lt;/script&gt; nice');
    expect(page.text).not.toContain('<script>alert("xss")</script>');
    const mod = await (await as(app, 'editor')).get('/admin/comments');
    expect(mod.text).not.toContain('<script>alert("xss")</script>');
  });

  test('empty comments are rejected; the honeypot silently drops bots', async () => {
    const r = await as(app, 'reader');
    const before = db.prepare('SELECT COUNT(*) n FROM comments').get().n;
    await postForm(r, `/posts/${SLUG}/comments`, { body: ' ' }, `/posts/${SLUG}`);
    await postForm(r, `/posts/${SLUG}/comments`, { body: 'Buy followers', website: 'http://spam.example' }, `/posts/${SLUG}`);
    expect(db.prepare('SELECT COUNT(*) n FROM comments').get().n).toBe(before);
  });

  test('flood control: max 5 comments in 10 minutes', async () => {
    const a = agent(app);
    await postForm(a, '/signup', { name: 'Chatty Reader', email: 'chatty@example.com', password: 'Chatty20266x', confirmPassword: 'Chatty20266x', terms: 'on' }, '/signup');
    for (let i = 0; i < 6; i++) await postForm(a, `/posts/${SLUG}/comments`, { body: `Comment number ${i}` }, `/posts/${SLUG}`);
    const n = db.prepare("SELECT COUNT(*) n FROM comments c JOIN users u ON u.id = c.user_id WHERE u.email = 'chatty@example.com'").get().n;
    expect(n).toBe(5);
  });

  test('comments can be closed per post and site-wide', async () => {
    const r = await as(app, 'reader');
    const p = post('Building a blog with Node.js and SQLite');
    db.prepare('UPDATE posts SET allow_comments = 0 WHERE id = ?').run(p.id);
    await postForm(r, `/posts/${p.slug}/comments`, { body: 'Should not save' }, `/posts/${p.slug}`);
    expect(db.prepare("SELECT 1 FROM comments WHERE body = 'Should not save'").get()).toBeUndefined();
    expect((await r.get(`/posts/${p.slug}`)).text).toContain('Comments are closed');
    db.prepare('UPDATE posts SET allow_comments = 1 WHERE id = ?').run(p.id);
    Settings.save({ comments_enabled: '0' });
    await postForm(r, `/posts/${p.slug}/comments`, { body: 'Also should not save' }, `/posts/${p.slug}`);
    expect(db.prepare("SELECT 1 FROM comments WHERE body = 'Also should not save'").get()).toBeUndefined();
    Settings.save({ comments_enabled: '1' });
  });

  test('readers delete their own comments', async () => {
    const r = await as(app, 'reader');
    const mine = db.prepare("SELECT c.id FROM comments c JOIN users u ON u.id = c.user_id WHERE u.email = 'reader@blogx.test' LIMIT 1").get();
    await postForm(r, `/comments/${mine.id}/delete`, {}, '/account');
    expect(db.prepare('SELECT 1 FROM comments WHERE id = ?').get(mine.id)).toBeUndefined();
  });
});

describe('newsletter', () => {
  test('subscribe, then unsubscribe with the one-click token link', async () => {
    const a = agent(app);
    const res = await postForm(a, '/subscribe', { email: 'Fan@Example.com', returnTo: '/' }, '/');
    expect(res.headers.location).toBe('/');
    const sub = db.prepare("SELECT * FROM subscribers WHERE email = 'fan@example.com'").get();
    expect(sub.status).toBe('subscribed');
    expect(sub.unsubscribe_token).toMatch(/^[a-f0-9]{48}$/);
    const confirm = await agent(app).get(`/unsubscribe/${sub.unsubscribe_token}`);
    expect(confirm.text).toContain('Unsubscribe?');
    expect(db.prepare('SELECT status FROM subscribers WHERE id = ?').get(sub.id).status).toBe('subscribed'); // GET changes nothing
    const b = agent(app);
    await postForm(b, `/unsubscribe/${sub.unsubscribe_token}`, {}, `/unsubscribe/${sub.unsubscribe_token}`);
    expect(db.prepare('SELECT status FROM subscribers WHERE id = ?').get(sub.id).status).toBe('unsubscribed');
  });

  test('wrong or malformed tokens give 404', async () => {
    expect((await agent(app).get('/unsubscribe/' + 'a'.repeat(48))).status).toBe(404);
    expect((await agent(app).get("/unsubscribe/1' OR '1'='1")).status).toBe(404);
  });

  test('invalid emails are refused and the open-redirect returnTo is ignored', async () => {
    const res = await postForm(agent(app), '/subscribe', { email: 'not-an-email', returnTo: 'https://evil.com' }, '/');
    expect(res.headers.location).toBe('/');
    expect(db.prepare("SELECT 1 FROM subscribers WHERE email = 'not-an-email'").get()).toBeUndefined();
  });

  test('readers manage their subscription from their account', async () => {
    const r = await as(app, 'reader');
    await postForm(r, '/account/newsletter', { subscribe: '0' }, '/account');
    expect(db.prepare("SELECT status FROM subscribers WHERE email = 'reader@blogx.test'").get().status).toBe('unsubscribed');
    await postForm(r, '/account/newsletter', { subscribe: '1' }, '/account');
    expect(db.prepare("SELECT status FROM subscribers WHERE email = 'reader@blogx.test'").get().status).toBe('subscribed');
  });
});

describe('view tracking', () => {
  const views = () => post('Writing headlines people actually click').view_count;

  test('counts one view per session, ignores repeats, bots and the post\'s own author', async () => {
    const slug = post('Writing headlines people actually click').slug;
    const start = views();
    const a = agent(app);
    await a.get(`/posts/${slug}`);
    await a.get(`/posts/${slug}`);
    expect(views()).toBe(start + 1);
    await agent(app).get(`/posts/${slug}`).set('User-Agent', 'Googlebot/2.1');
    expect(views()).toBe(start + 1);
    const editor = await as(app, 'editor'); // the editor wrote this post
    await editor.get(`/posts/${slug}`);
    expect(views()).toBe(start + 1);
    await agent(app).get(`/posts/${slug}`);
    expect(views()).toBe(start + 2);
  });
});

describe('public pages, search and feeds', () => {
  test('home shows the featured hero and the guest strip', async () => {
    const res = await agent(app).get('/');
    expect(res.text).toContain('post-card-large');
    expect(res.text).toContain("You're reading as a guest");
  });

  test('category page includes sub-categories; tag and author pages work', async () => {
    const tech = await agent(app).get('/category/technology');
    expect(tech.text).toContain('Ten habits that keep your web app secure');
    expect(tech.text).toContain('href="/category/security"');
    expect((await agent(app).get('/tag/lagos')).text).toContain('Saturday morning in Yaba');
    const author = await agent(app).get('/author/chidi-okeke');
    expect(author.text).toContain('Software engineer in Yaba');
    expect((await agent(app).get('/author/ngozi-eze')).status).toBe(404); // readers have no author page
  });

  test('search with text + category + sort; empty and junk searches are safe', async () => {
    const res = await agent(app).get('/search').query({ q: 'lagos', category: 'business', sort: 'popular' });
    expect(res.text).toContain('What we learned launching a product in Lagos');
    expect(res.text).not.toContain('Saturday morning in Yaba');
    expect((await agent(app).get('/search').query({ q: 'zzzznothing' })).text).toContain('No posts match your search.');
    expect((await agent(app).get('/search').query({ q: "' OR 1=1 --", sort: 'x;DROP' })).status).toBe(200);
  });

  test('RSS and sitemap list only live, indexable posts', async () => {
    db.prepare("UPDATE posts SET noindex = 1 WHERE title = 'A weekend in Abeokuta'").run();
    const rss = await agent(app).get('/rss.xml');
    expect(rss.headers['content-type']).toMatch(/rss\+xml/);
    expect(rss.text).toContain('Ten habits that keep your web app secure');
    expect(rss.text).not.toContain('Notes on password managers');
    expect(rss.text).not.toContain('December reading list');
    const map = await agent(app).get('/sitemap.xml');
    expect(map.text).toContain('/posts/ten-habits-that-keep-your-web-app-secure');
    expect(map.text).not.toContain('a-weekend-in-abeokuta');
    expect((await agent(app).get('/robots.txt')).text).toContain('Disallow: /admin');
  });

  test('registration can be closed by the admin', async () => {
    Settings.save({ registration_open: '0' });
    expect((await agent(app).get('/signup')).status).toBe(403);
    expect((await postForm(agent(app), '/signup', { name: 'Late Comer', email: 'late@example.com', password: 'LatePass2026', confirmPassword: 'LatePass2026', terms: 'on' }, '/signin')).status).toBe(403);
    Settings.save({ registration_open: '1' });
  });
});
