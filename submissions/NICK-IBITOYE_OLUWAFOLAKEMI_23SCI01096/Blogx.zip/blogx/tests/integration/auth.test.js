const { setup, agent, login, as, postForm, csrfFrom, db, ACCOUNTS } = require('../helpers');

let app;
beforeAll(() => { app = setup(); });
const newReader = { name: 'Tunde Bakare', email: 'tunde@example.com', password: 'BlogPass2026', confirmPassword: 'BlogPass2026', terms: 'on' };

describe('Sign up', () => {
  test('creates a READER account, logs in, stores only a bcrypt hash', async () => {
    const a = agent(app);
    const res = await postForm(a, '/signup', { ...newReader, newsletter: 'on' }, '/signup');
    expect(res.status).toBe(302);
    const row = db.prepare('SELECT role, password_hash FROM users WHERE email = ?').get('tunde@example.com');
    expect(row.role).toBe('reader');
    expect(row.password_hash).toMatch(/^\$2[aby]\$/);
    expect(row.password_hash).not.toContain('BlogPass2026');
    expect(db.prepare("SELECT status FROM subscribers WHERE email = 'tunde@example.com'").get().status).toBe('subscribed');
    expect((await a.get('/')).text).toContain('Welcome back, <strong>Tunde</strong>');
  });

  test('a role=admin field added by an attacker is ignored', async () => {
    await postForm(agent(app), '/signup', { ...newReader, email: 'sneaky@example.com', role: 'admin' }, '/signup');
    expect(db.prepare("SELECT role FROM users WHERE email = 'sneaky@example.com'").get().role).toBe('reader');
  });

  test('empty form shows messages and creates nothing', async () => {
    const before = db.prepare('SELECT COUNT(*) n FROM users').get().n;
    const res = await postForm(agent(app), '/signup', {}, '/signup');
    expect(res.status).toBe(400);
    expect(res.text).toContain('Please enter your name.');
    expect(res.text).toContain('Please enter a password.');
    expect(res.text).toContain('Please accept the terms');
    expect(db.prepare('SELECT COUNT(*) n FROM users').get().n).toBe(before);
  });

  test('duplicate email refused', async () => {
    const res = await postForm(agent(app), '/signup', { ...newReader, email: ACCOUNTS.reader.email }, '/signup');
    expect(res.status).toBe(400);
    expect(res.text).toContain('already exists');
  });
});

describe('Sign in', () => {
  test.each([
    ['reader', '/'], ['contributor', '/admin'], ['author', '/admin'], ['editor', '/admin'], ['admin', '/admin']
  ])('%s lands on %s', async (role, where) => {
    const res = await login(agent(app), role);
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe(where);
  });

  test('wrong password and unknown email give the same generic message', async () => {
    const a = await login(agent(app), { email: ACCOUNTS.reader2.email, password: 'WrongPass2026' });
    const b = await login(agent(app), { email: 'nobody@example.com', password: 'WrongPass2026' });
    expect(a.status).toBe(401);
    expect(b.status).toBe(401);
    expect(a.text).toContain('Incorrect email or password.');
    expect(b.text).toContain('Incorrect email or password.');
    db.prepare('UPDATE users SET failed_logins = 0 WHERE email = ?').run(ACCOUNTS.reader2.email);
  });

  test('empty sign-in form shows a validation message', async () => {
    const res = await login(agent(app), { email: '', password: '' });
    expect(res.status).toBe(400);
    expect(res.text).toContain('Please enter your email and password.');
  });

  test('5 wrong passwords lock the account, even against the right password', async () => {
    const victim = { email: 'lockme@example.com', password: 'Correct2026x' };
    await postForm(agent(app), '/signup', { ...newReader, email: victim.email, password: victim.password, confirmPassword: victim.password }, '/signup');
    for (let i = 0; i < 5; i++) await login(agent(app), { email: victim.email, password: `Guess${i}xxxxxx` });
    const res = await login(agent(app), victim);
    expect(res.status).toBe(423);
    expect(res.text).toContain('locked');
  });

  test('session cookie: HttpOnly, SameSite, expiry; new id after login', async () => {
    const a = agent(app);
    const first = await a.get('/signin');
    const before = first.headers['set-cookie'].find((c) => c.startsWith('bx.sid'));
    expect(before).toMatch(/HttpOnly/i);
    expect(before).toMatch(/SameSite=Lax/i);
    expect(before).toMatch(/Expires=/i);
    const res = await login(a, 'reader');
    const after = res.headers['set-cookie'].find((c) => c.startsWith('bx.sid'));
    expect(after.split(';')[0]).not.toBe(before.split(';')[0]);
  });

  test('per-IP rate limit returns 429 after the limit', async () => {
    const limited = setup({ loginRateLimit: 3 });
    const a = agent(limited);
    for (let i = 0; i < 3; i++) await login(a, { email: `x${i}@example.com`, password: 'Nope12345678' });
    const res = await login(a, { email: 'y@example.com', password: 'Nope12345678' });
    expect(res.status).toBe(429);
    expect(res.text).toContain('Too many sign-in attempts');
  });

  test('suspended accounts cannot sign in', async () => {
    db.prepare("UPDATE users SET status = 'suspended' WHERE email = ?").run(ACCOUNTS.reader2.email);
    const res = await login(agent(app), 'reader2');
    expect(res.status).toBe(403);
    expect(res.text).toContain('suspended');
    db.prepare("UPDATE users SET status = 'active' WHERE email = ?").run(ACCOUNTS.reader2.email);
  });
});

describe('Sign out', () => {
  test('destroys the session; protected pages then need sign-in', async () => {
    const a = await as(app, 'reader');
    expect((await a.get('/account')).status).toBe(200);
    const res = await postForm(a, '/signout', {}, '/account');
    expect(res.headers['set-cookie'].join(';')).toMatch(/bx\.sid=;/);
    const after = await a.get('/account');
    expect(after.status).toBe(302);
    expect(after.headers.location).toMatch(/^\/signin/);
  });

  test('sign out via GET is not possible', async () => {
    expect((await agent(app).get('/signout')).status).toBe(404);
  });
});

describe('Account', () => {
  test('profile update and password change (with wrong current password first)', async () => {
    const a = agent(app);
    await postForm(a, '/signup', { ...newReader, email: 'profile@example.com' }, '/signup');
    let res = await postForm(a, '/account/profile', { name: 'Tunde B', email: 'profile@example.com', bio: 'Hi', website: 'https://tunde.dev' }, '/account');
    expect(res.headers.location).toBe('/account');
    expect((await a.get('/account')).text).toContain('https://tunde.dev');
    res = await postForm(a, '/account/password', { currentPassword: 'wrong', newPassword: 'NewPass20266', confirmPassword: 'NewPass20266' }, '/account/password');
    expect(res.status).toBe(400);
    expect(res.text).toContain('current password is incorrect');
    res = await postForm(a, '/account/password', { currentPassword: newReader.password, newPassword: 'NewPass20266', confirmPassword: 'NewPass20266' }, '/account/password');
    expect(res.headers.location).toBe('/account');
    expect((await login(agent(app), { email: 'profile@example.com', password: 'NewPass20266' })).status).toBe(302);
  });

  test('profile rejects javascript: website links', async () => {
    const a = await as(app, 'reader');
    const res = await postForm(a, '/account/profile', { name: 'Ngozi Eze', email: ACCOUNTS.reader.email, website: 'javascript:alert(1)' }, '/account');
    expect(res.status).toBe(400);
  });

  test('a hidden id field cannot redirect a profile update to another account', async () => {
    const a = await as(app, 'reader');
    await postForm(a, '/account/profile', { id: 1, userId: 1, name: 'Hacked', email: ACCOUNTS.reader.email }, '/account');
    expect(db.prepare('SELECT name FROM users WHERE id = 1').get().name).toBe('Site Admin');
  });

  test('readers can delete their own account with their password', async () => {
    const a = agent(app);
    await postForm(a, '/signup', { ...newReader, email: 'leaving@example.com' }, '/signup');
    let res = await postForm(a, '/account/delete', { password: 'wrong' }, '/account');
    expect(db.prepare("SELECT 1 FROM users WHERE email = 'leaving@example.com'").get()).toBeDefined();
    res = await postForm(a, '/account/delete', { password: newReader.password }, '/account');
    expect(res.headers.location).toBe('/signin?signedout=1');
    expect(db.prepare("SELECT 1 FROM users WHERE email = 'leaving@example.com'").get()).toBeUndefined();
  });
});

describe('Temporary passwords', () => {
  test('a user created by an admin must change the password before doing anything else', async () => {
    const admin = await as(app, 'admin');
    await postForm(admin, '/admin/users/new', { name: 'New Writer', email: 'writer@example.com', role: 'author', password: 'TempPass20266' }, '/admin/users/new');
    const w = agent(app);
    const res = await login(w, { email: 'writer@example.com', password: 'TempPass20266' });
    expect(res.status).toBe(302);
    const dash = await w.get('/admin');
    expect(dash.headers.location).toBe('/account/password');
    expect((await w.get('/account/password')).text).toContain('Set your password');
    const _csrf = await csrfFrom(w, '/account/password');
    const blocked = await w.post('/admin/posts/new').type('form').send({ _csrf, title: 'x' });
    expect(blocked.status).toBe(403);
    await postForm(w, '/account/password', { currentPassword: 'TempPass20266', newPassword: 'MyOwnPass2026', confirmPassword: 'MyOwnPass2026' }, '/account/password');
    expect((await w.get('/admin')).status).toBe(200);
  });
});
