/** Attack simulations: SQL injection, XSS, CSRF, headers, error leakage, request limits. */
const { setup, agent, as, login, postForm, csrfFrom, db } = require('../helpers');

let app;
beforeAll(() => { app = setup(); });

describe('SQL injection', () => {
  test.each(["' OR '1'='1", "admin@blogx.test' --", "'; DROP TABLE users; --"])('sign-in payload %p is rejected with no error leak', async (payload) => {
    const res = await login(agent(app), { email: payload, password: payload });
    expect(res.status).toBe(401);
    expect(res.text).toContain('Incorrect email or password.');
    expect(res.text).not.toMatch(/sqlite|syntax error|SqliteError|stack/i);
    expect(db.prepare('SELECT COUNT(*) n FROM users').get().n).toBeGreaterThan(0);
  });

  test('search box and filters treat SQL as text', async () => {
    const res = await agent(app).get('/search').query({ q: "' UNION SELECT email, password_hash FROM users --", category: "x' OR 1=1 --", sort: 'popular; DROP TABLE posts' });
    expect(res.status).toBe(200);
    expect(res.text).toContain('No posts match');
    expect(res.text).not.toContain('$2');
    expect(db.prepare('SELECT COUNT(*) n FROM posts').get().n).toBeGreaterThan(0);
  });

  test('numeric ids in URLs reject injection', async () => {
    const ed = await as(app, 'editor');
    expect((await ed.get('/admin/posts/1%20OR%201=1/edit')).status).toBe(404);
    expect((await ed.get("/admin/categories?edit=1'--")).status).toBe(200);
  });
});

describe('cross-site scripting (reflected)', () => {
  test('search term is escaped', async () => {
    const res = await agent(app).get('/search').query({ q: '<script>alert(1)</script>' });
    expect(res.text).not.toContain('<script>alert(1)</script>');
    expect(res.text).toContain('&lt;script&gt;alert(1)&lt;/script&gt;');
  });

  test('a strict Content-Security-Policy is sent on every page', async () => {
    const res = await agent(app).get('/');
    const csp = res.headers['content-security-policy'];
    expect(csp).toContain("script-src 'self'");
    expect(csp).toContain("style-src 'self'");
    expect(csp).not.toContain('unsafe-inline');
    expect(csp).toContain("frame-ancestors 'none'");
    expect(csp).toContain("object-src 'none'");
  });

  test('no inline <script> or style="" exists in the pages (so the CSP never needs unsafe-inline)', async () => {
    const ed = await as(app, 'admin');
    for (const url of ['/', '/posts/ten-habits-that-keep-your-web-app-secure', '/security', '/admin', '/admin/posts/new', '/admin/settings']) {
      const html = (await ed.get(url)).text;
      expect([url, /<script(?![^>]*\bsrc=)[^>]*>/.test(html)]).toEqual([url, false]);
      expect([url, / style="/.test(html)]).toEqual([url, false]);
    }
  });
});

describe('cross-site request forgery', () => {
  test('missing token → 403 with a friendly page and nothing changed', async () => {
    const r = await as(app, 'reader');
    const res = await r.post('/account/profile').type('form').send({ name: 'Evil', email: 'evil@example.com' });
    expect(res.status).toBe(403);
    expect(res.text).toContain('could not be verified');
    expect(res.text).toContain('site-header');
    expect(res.text).not.toMatch(/ReferenceError|\.ejs:\d|node_modules/);
    expect(db.prepare("SELECT 1 FROM users WHERE email = 'evil@example.com'").get()).toBeUndefined();
  });

  test('a wrong token or another session\'s token is refused', async () => {
    const r = await as(app, 'reader');
    expect((await r.post('/account/profile').type('form').send({ _csrf: 'a'.repeat(64), name: 'Evil', email: 'e@x.co' })).status).toBe(403);
    const stolen = await csrfFrom(agent(app), '/signin');
    expect((await r.post('/account/profile').type('form').send({ _csrf: stolen, name: 'Evil', email: 'e@x.co' })).status).toBe(403);
  });

  test('forged "publish" and "delete" requests are refused', async () => {
    const ed = await as(app, 'editor');
    const draft = db.prepare("SELECT id FROM posts WHERE status = 'draft'").get();
    expect((await ed.post(`/admin/posts/${draft.id}/status`).type('form').send({ status: 'published' })).status).toBe(403);
    expect((await ed.post(`/admin/posts/${draft.id}/delete`).type('form').send({})).status).toBe(403);
    expect(db.prepare('SELECT status FROM posts WHERE id = ?').get(draft.id).status).toBe('draft');
  });

  test('sign-out, comments and newsletter forms are protected too', async () => {
    expect((await agent(app).post('/subscribe').type('form').send({ email: 'x@y.co' })).status).toBe(403);
    expect((await agent(app).post('/signout').type('form').send({})).status).toBe(403);
  });
});

describe('headers, errors and limits', () => {
  test('security headers are set and Express is not advertised', async () => {
    const res = await agent(app).get('/');
    expect(res.headers['x-content-type-options']).toBe('nosniff');
    expect(res.headers['x-frame-options']).toBe('SAMEORIGIN');
    expect(res.headers['referrer-policy']).toBe('strict-origin-when-cross-origin');
    expect(res.headers['x-powered-by']).toBeUndefined();
  });

  test('404 page is friendly with no technical details', async () => {
    const res = await agent(app).get('/posts/does-not-exist');
    expect(res.status).toBe(404);
    expect(res.text).toContain('find that page');
    expect(res.text).not.toMatch(/at .*\.js:\d+/);
  });

  test('dotfiles such as .env are never served', async () => {
    expect((await agent(app).get('/.env')).status).not.toBe(200);
    expect((await agent(app).get('/uploads/.gitkeep')).status).not.toBe(200);
  });

  test('oversized requests are refused with 413', async () => {
    const a = agent(app);
    const _csrf = await csrfFrom(a, '/signin');
    const res = await a.post('/signin').type('form').send({ _csrf, email: 'a@b.co', password: 'x'.repeat(400000) });
    expect(res.status).toBe(413);
  });

  test('theme.css only ever contains a validated colour', async () => {
    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('accent_color', 'red;}*{display:none')").run();
    require('../../src/models/settings').clearCache();
    expect((await agent(app).get('/theme.css')).text).toBe(':root{--accent:#ff1a75;}\n');
  });
});
