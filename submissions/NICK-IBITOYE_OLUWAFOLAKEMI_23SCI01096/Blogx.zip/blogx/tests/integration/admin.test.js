/** Admin dashboard: categories, tags, media, comments, subscribers, users, settings. */
const fs = require('fs');
const path = require('path');
const { setup, agent, as, postForm, csrfFrom, post, postData, db } = require('../helpers');
const config = require('../../src/config');

let app;
const A = {};
const uploaded = [];
// Smallest valid PNG (1×1 pixel)
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');

beforeAll(async () => {
  app = setup();
  for (const r of ['author', 'editor', 'admin', 'contributor']) A[r] = await as(app, r);
});
afterAll(() => { for (const p of uploaded) fs.rmSync(path.join(config.uploadDir, path.basename(p)), { force: true }); });

describe('dashboard', () => {
  test('editors see site-wide stats and the review queue; authors only their own numbers', async () => {
    const ed = await A.editor.get('/admin');
    expect(ed.text).toContain('Site-wide overview');
    expect(ed.text).toContain('Waiting for review');
    expect(ed.text).toContain('My favourite street foods in Surulere');
    expect(ed.text).toContain('Comments to moderate');
    const au = await A.author.get('/admin');
    expect(au.text).toContain('Your posts and their readers');
    expect(au.text).not.toContain('Waiting for review');
    expect(au.text).not.toContain('Subscribers');
    expect((await A.admin.get('/admin')).text).toContain('Recent security events');
  });
});

describe('categories and sub-categories', () => {
  test('create a category and a sub-category, rename, then delete', async () => {
    await postForm(A.editor, '/admin/categories', { name: 'Sport', description: 'Games' }, '/admin/categories');
    const sport = db.prepare("SELECT * FROM categories WHERE name = 'Sport'").get();
    expect(sport.parent_id).toBeNull();
    await postForm(A.editor, '/admin/categories', { name: 'Football', parentId: String(sport.id) }, '/admin/categories');
    const football = db.prepare("SELECT * FROM categories WHERE name = 'Football'").get();
    expect(football.parent_id).toBe(sport.id);
    // A parent with children can't be deleted
    await postForm(A.editor, `/admin/categories/${sport.id}/delete`, {}, '/admin/categories');
    expect(db.prepare('SELECT 1 FROM categories WHERE id = ?').get(sport.id)).toBeDefined();
    await postForm(A.editor, `/admin/categories/${football.id}/edit`, { name: 'Soccer', parentId: String(sport.id) }, '/admin/categories');
    expect(db.prepare('SELECT slug FROM categories WHERE id = ?').get(football.id).slug).toBe('soccer');
    await postForm(A.editor, `/admin/categories/${football.id}/delete`, {}, '/admin/categories');
    await postForm(A.editor, `/admin/categories/${sport.id}/delete`, {}, '/admin/categories');
    expect(db.prepare("SELECT COUNT(*) n FROM categories WHERE name IN ('Sport', 'Soccer')").get().n).toBe(0);
  });

  test('sub-categories cannot have children (one level) and duplicate names are refused', async () => {
    const security = db.prepare("SELECT id FROM categories WHERE slug = 'security'").get().id;
    const res = await postForm(A.editor, '/admin/categories', { name: 'Deep', parentId: String(security) }, '/admin/categories');
    expect(res.status).toBe(400);
    const dup = await postForm(A.editor, '/admin/categories', { name: 'technology' }, '/admin/categories');
    expect(dup.status).toBe(400);
  });

  test('a category in use cannot be deleted', async () => {
    const food = db.prepare("SELECT id FROM categories WHERE slug = 'food'").get().id;
    await postForm(A.editor, `/admin/categories/${food}/delete`, {}, '/admin/categories');
    expect((await A.editor.get('/admin/categories')).text).toContain('posts still use it');
  });
});

describe('tags', () => {
  test('create, rename, delete (removed from posts)', async () => {
    await postForm(A.editor, '/admin/tags', { name: 'Nollywood' }, '/admin/tags');
    const t = db.prepare("SELECT * FROM tags WHERE name = 'Nollywood'").get();
    await postForm(A.editor, `/admin/tags/${t.id}/edit`, { name: 'Film' }, '/admin/tags');
    expect(db.prepare('SELECT slug FROM tags WHERE id = ?').get(t.id).slug).toBe('film');
    const lagos = db.prepare("SELECT id FROM tags WHERE name = 'Lagos'").get().id;
    await postForm(A.editor, `/admin/tags/${lagos}/delete`, {}, '/admin/tags');
    expect(db.prepare('SELECT COUNT(*) n FROM post_tags WHERE tag_id = ?').get(lagos).n).toBe(0);
    expect((await postForm(A.editor, '/admin/tags', { name: '<script>' }, '/admin/tags')).status).toBe(400);
  });
});

describe('media library', () => {
  async function upload(a, buffer, name, type, withToken = true) {
    const _csrf = await csrfFrom(a, '/admin/media');
    let req = a.post('/admin/media');
    if (withToken) req = req.field('_csrf', _csrf);
    return req.field('alt', 'Test image').attach('file', buffer, { filename: name, contentType: type });
  }

  test('a contributor uploads a real PNG; it gets a random name', async () => {
    const res = await upload(A.contributor, PNG, 'holiday.png', 'image/png');
    expect(res.status).toBe(302);
    const m = db.prepare("SELECT * FROM media WHERE original_name = 'holiday.png'").get();
    expect(m.path).toMatch(/^\/uploads\/[a-f0-9]{32}\.png$/);
    uploaded.push(m.path);
    expect(fs.existsSync(path.join(config.uploadDir, path.basename(m.path)))).toBe(true);
  });

  test('scripts and SVGs disguised as images are refused', async () => {
    await upload(A.author, Buffer.from('<?php system($_GET["c"]); ?>'), 'shell.png', 'image/png');
    await upload(A.author, Buffer.from('<svg xmlns="http://www.w3.org/2000/svg" onload="alert(1)"/>'), 'logo.svg', 'image/svg+xml');
    expect(db.prepare("SELECT COUNT(*) n FROM media WHERE original_name IN ('shell.png', 'logo.svg')").get().n).toBe(0);
    expect((await A.author.get('/admin/media')).text).toContain('Please upload a real JPG, PNG, WebP or GIF image.');
  });

  test('uploads without a CSRF token are rejected before anything is saved', async () => {
    const before = db.prepare('SELECT COUNT(*) n FROM media').get().n;
    const res = await upload(A.author, PNG, 'notoken.png', 'image/png', false);
    expect(res.status).toBe(403);
    expect(db.prepare('SELECT COUNT(*) n FROM media').get().n).toBe(before);
  });

  test('editor JSON upload needs the X-CSRF-Token header', async () => {
    const _csrf = await csrfFrom(A.author, '/admin/posts/new');
    const ok = await A.author.post('/admin/media/upload.json').set('X-CSRF-Token', _csrf).attach('file', PNG, { filename: 'inline.png', contentType: 'image/png' });
    expect(ok.status).toBe(200);
    expect(ok.body.path).toMatch(/^\/uploads\/[a-f0-9]{32}\.png$/);
    uploaded.push(ok.body.path);
    const bad = await A.author.post('/admin/media/upload.json').attach('file', PNG, { filename: 'x.png', contentType: 'image/png' });
    expect(bad.status).toBe(403);
    expect(bad.body.error).toBeDefined();
  });

  test("writers see and delete only their own uploads; images in use can't be deleted", async () => {
    const mine = db.prepare("SELECT * FROM media WHERE original_name = 'holiday.png'").get();
    expect((await A.author.get('/admin/media')).text).not.toContain('holiday.png');
    expect((await postForm(A.author, `/admin/media/${mine.id}/delete`, {}, '/admin/media')).status).toBe(403);
    // contributor puts it in a post, then can't delete it
    await postForm(A.contributor, '/admin/posts/new', postData({ title: 'Uses an image', featureImage: mine.path }), '/admin/posts/new');
    await postForm(A.contributor, `/admin/media/${mine.id}/delete`, {}, '/admin/media');
    expect(db.prepare('SELECT 1 FROM media WHERE id = ?').get(mine.id)).toBeDefined();
    expect(post('Uses an image').feature_image).toBe(mine.path);
  });

  test('a feature image path that is not in the library is rejected', async () => {
    const res = await postForm(A.author, '/admin/posts/new', postData({ title: 'Ghost image', featureImage: '/uploads/' + 'f'.repeat(32) + '.jpg' }), '/admin/posts/new');
    expect(res.status).toBe(400);
    expect(res.text).toContain('not in the media library');
  });
});

describe('comment moderation', () => {
  test('approve, mark spam, delete; filters by status', async () => {
    const pending = db.prepare("SELECT id FROM comments WHERE status = 'pending'").get();
    expect((await A.editor.get('/admin/comments?status=pending')).text).toContain('Totally agree');
    await postForm(A.editor, `/admin/comments/${pending.id}/status`, { status: 'spam' }, '/admin/comments');
    expect(db.prepare('SELECT status FROM comments WHERE id = ?').get(pending.id).status).toBe('spam');
    await postForm(A.editor, `/admin/comments/${pending.id}/status`, { status: 'hacked' }, '/admin/comments');
    expect(db.prepare('SELECT status FROM comments WHERE id = ?').get(pending.id).status).toBe('spam');
    await postForm(A.editor, `/admin/comments/${pending.id}/delete`, {}, '/admin/comments');
    expect(db.prepare('SELECT 1 FROM comments WHERE id = ?').get(pending.id)).toBeUndefined();
  });
});

describe('subscribers', () => {
  test('editors can view but not export; admins export a formula-safe CSV', async () => {
    await postForm(agent(app), '/subscribe', { email: 'evil@example.com', name: "=HYPERLINK('http://evil','click')" }, '/');
    // name fails validation (contains = and brackets) → saved without a name? check it's refused
    expect(db.prepare("SELECT name FROM subscribers WHERE email = 'evil@example.com'").get()).toBeUndefined();
    db.prepare("INSERT INTO subscribers (email, name, unsubscribe_token) VALUES ('evil2@example.com', '=1+1', ?)").run('c'.repeat(48));
    expect((await A.editor.get('/admin/subscribers')).status).toBe(200);
    expect((await A.editor.get('/admin/subscribers.csv')).status).toBe(403);
    const csv = await A.admin.get('/admin/subscribers.csv');
    expect(csv.headers['content-type']).toMatch(/text\/csv/);
    expect(csv.headers['content-disposition']).toContain('subscribers.csv');
    expect(csv.text).toContain(`"evil2@example.com","'=1+1"`);
    expect(csv.text).not.toContain('old.reader@example.com'); // unsubscribed people are not exported
  });

  test('admins can remove a subscriber; editors cannot', async () => {
    const s = db.prepare("SELECT id FROM subscribers WHERE email = 'evil2@example.com'").get();
    expect((await postForm(A.editor, `/admin/subscribers/${s.id}/delete`, {}, '/admin')).status).toBe(403);
    await postForm(A.admin, `/admin/subscribers/${s.id}/delete`, {}, '/admin/subscribers');
    expect(db.prepare('SELECT 1 FROM subscribers WHERE id = ?').get(s.id)).toBeUndefined();
  });
});

describe('users (admin only)', () => {
  const id = (email) => db.prepare('SELECT id FROM users WHERE email = ?').get(email).id;

  test('invite a user with a temporary password; weak passwords and duplicates refused', async () => {
    let res = await postForm(A.admin, '/admin/users/new', { name: 'Guest Writer', email: 'guest@example.com', role: 'contributor', password: 'short' }, '/admin/users/new');
    expect(res.status).toBe(400);
    res = await postForm(A.admin, '/admin/users/new', { name: 'Guest Writer', email: 'guest@example.com', role: 'contributor', password: 'TempPass20266' }, '/admin/users/new');
    expect(res.status).toBe(302);
    const row = db.prepare("SELECT role, must_change_password FROM users WHERE email = 'guest@example.com'").get();
    expect(row).toEqual({ role: 'contributor', must_change_password: 1 });
    res = await postForm(A.admin, '/admin/users/new', { name: 'Again', email: 'guest@example.com', role: 'author', password: 'TempPass20266' }, '/admin/users/new');
    expect(res.status).toBe(400);
  });

  test('change role, suspend and reactivate', async () => {
    const g = id('guest@example.com');
    await postForm(A.admin, `/admin/users/${g}/role`, { role: 'author' }, '/admin/users');
    expect(db.prepare('SELECT role FROM users WHERE id = ?').get(g).role).toBe('author');
    await postForm(A.admin, `/admin/users/${g}/role`, { role: 'superuser' }, '/admin/users');
    expect(db.prepare('SELECT role FROM users WHERE id = ?').get(g).role).toBe('author');
    await postForm(A.admin, `/admin/users/${g}/status`, { status: 'suspended' }, '/admin/users');
    expect(db.prepare('SELECT status FROM users WHERE id = ?').get(g).status).toBe('suspended');
    await postForm(A.admin, `/admin/users/${g}/status`, { status: 'active' }, '/admin/users');
  });

  test('an admin cannot demote, suspend or delete themselves', async () => {
    const me = id('admin@blogx.test');
    await postForm(A.admin, `/admin/users/${me}/role`, { role: 'reader' }, '/admin/users');
    await postForm(A.admin, `/admin/users/${me}/status`, { status: 'suspended' }, '/admin/users');
    await postForm(A.admin, `/admin/users/${me}/delete`, {}, '/admin/users');
    expect(db.prepare('SELECT role, status FROM users WHERE id = ?').get(me)).toEqual({ role: 'admin', status: 'active' });
  });

  test('two admins can manage each other, but nobody can remove the last remaining admin', async () => {
    await postForm(A.admin, '/admin/users/new', { name: 'Second Admin', email: 'second@example.com', role: 'admin', password: 'SecondPass2026' }, '/admin/users/new');
    db.prepare("UPDATE users SET must_change_password = 0 WHERE email = 'second@example.com'").run();
    const second = await as(app, { email: 'second@example.com', password: 'SecondPass2026' });
    // With two admins, the second may demote the first…
    await postForm(second, `/admin/users/${id('admin@blogx.test')}/role`, { role: 'editor' }, '/admin/users');
    expect(db.prepare("SELECT role FROM users WHERE email = 'admin@blogx.test'").get().role).toBe('editor');
    // …but now it is the LAST admin, and the only person who could act on it is itself, which is refused.
    await postForm(second, `/admin/users/${id('second@example.com')}/role`, { role: 'editor' }, '/admin/users');
    await postForm(second, `/admin/users/${id('second@example.com')}/delete`, {}, '/admin/users');
    expect(db.prepare("SELECT role FROM users WHERE email = 'second@example.com'").get().role).toBe('admin');
    expect(db.prepare("SELECT COUNT(*) n FROM users WHERE role = 'admin' AND status = 'active'").get().n).toBe(1);
    // restore for the following tests
    db.prepare("UPDATE users SET role = 'admin' WHERE email = 'admin@blogx.test'").run();
  });

  test('deleting a writer hands their posts to the admin', async () => {
    const contributorId = id('contributor@blogx.test');
    const adminId = id('admin@blogx.test');
    const theirPosts = db.prepare('SELECT COUNT(*) n FROM posts WHERE author_id = ?').get(contributorId).n;
    expect(theirPosts).toBeGreaterThan(0);
    const adminAgent = await as(app, 'admin');
    await postForm(adminAgent, `/admin/users/${contributorId}/delete`, {}, '/admin/users');
    expect(db.prepare('SELECT 1 FROM users WHERE id = ?').get(contributorId)).toBeUndefined();
    expect(db.prepare("SELECT author_id FROM posts WHERE title = 'A weekend in Abeokuta'").get().author_id).toBe(adminId);
  });

  test('user list search and role filter', async () => {
    const a = await as(app, 'admin');
    const res = await a.get('/admin/users?role=editor');
    expect(res.text).toContain('Tolu Adebayo');
    expect(res.text).not.toContain('Ngozi Eze');
    expect((await a.get('/admin/users?q=ngozi')).text).toContain('reader@blogx.test');
  });
});

describe('settings (admin only)', () => {
  test('saves title, accent colour and posts per page; theme.css follows', async () => {
    const a = await as(app, 'admin');
    await postForm(a, '/admin/settings', { site_title: 'Lagos Notes', site_description: 'Hi', accent_color: '#14b886', posts_per_page: '6', comment_moderation: 'all', comments_enabled: 'on', registration_open: 'on', newsletter_enabled: 'on', footer_text: 'x' }, '/admin/settings');
    expect((await agent(app).get('/')).text).toContain('<title>Lagos Notes</title>');
    expect((await agent(app).get('/theme.css')).text).toContain('--accent:#14b886');
  });

  test('CSS injection through the accent colour is refused', async () => {
    const a = await as(app, 'admin');
    const res = await postForm(a, '/admin/settings', { site_title: 'Lagos Notes', accent_color: 'red;}body{display:none', posts_per_page: '6', comment_moderation: 'all' }, '/admin/settings');
    expect(res.status).toBe(400);
    expect(res.text).toContain('Accent colour must look like');
    expect((await agent(app).get('/theme.css')).text).toBe(':root{--accent:#14b886;}\n');
  });

  test('every admin action is in the audit log', async () => {
    const res = await (await as(app, 'admin')).get('/admin/audit');
    for (const action of ['settings_updated', 'user_created', 'user_role', 'user_deleted', 'category_created', 'media_uploaded', 'subscribers_exported']) {
      expect(res.text).toContain(action);
    }
    expect(res.text).not.toMatch(/TempPass20266|SecondPass2026/);
  });
});
