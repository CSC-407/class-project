/** Role-based access control across every area, plus ownership (IDOR) checks. */
const { setup, agent, as, postForm, csrfFrom, post, postData, db } = require('../helpers');

let app;
const A = {};
beforeAll(async () => {
  app = setup();
  for (const r of ['reader', 'contributor', 'author', 'editor', 'admin']) A[r] = await as(app, r);
});

const ADMIN_PAGES = {
  '/admin': 'contributor',
  '/admin/posts': 'contributor',
  '/admin/posts/new': 'contributor',
  '/admin/media': 'contributor',
  '/admin/categories': 'editor',
  '/admin/tags': 'editor',
  '/admin/comments': 'editor',
  '/admin/subscribers': 'editor',
  '/admin/users': 'admin',
  '/admin/users/new': 'admin',
  '/admin/settings': 'admin',
  '/admin/audit': 'admin',
  '/admin/subscribers.csv': 'admin'
};
const RANK = ['reader', 'contributor', 'author', 'editor', 'admin'];

describe('visitors (not signed in)', () => {
  test.each(Object.keys(ADMIN_PAGES).concat(['/account', '/account/password']))('%s redirects to sign-in', async (url) => {
    const res = await agent(app).get(url);
    expect(res.status).toBe(302);
    expect(res.headers.location).toMatch(/^\/signin/);
  });
});

describe('role matrix for admin pages', () => {
  for (const [url, min] of Object.entries(ADMIN_PAGES)) {
    test(`${url} needs ${min}`, async () => {
      for (const role of RANK) {
        const res = await A[role].get(url);
        const allowed = RANK.indexOf(role) >= RANK.indexOf(min);
        expect([role, res.status]).toEqual([role, allowed ? 200 : 403]);
      }
    });
  }

  test('403 page is friendly and reveals nothing', async () => {
    const res = await A.reader.get('/admin/users');
    expect(res.text).toContain('Access denied');
    expect(res.text).not.toMatch(/at .*\.js:\d+/);
  });
});

describe('admin actions are refused when POSTed directly by lower roles', () => {
  test('author cannot change a user role, settings, or delete a category', async () => {
    const readerId = db.prepare("SELECT id FROM users WHERE email = 'reader@blogx.test'").get().id;
    expect((await postForm(A.author, `/admin/users/${readerId}/role`, { role: 'admin' }, '/admin')).status).toBe(403);
    expect(db.prepare('SELECT role FROM users WHERE id = ?').get(readerId).role).toBe('reader');
    expect((await postForm(A.editor, '/admin/settings', { site_title: 'Hacked' }, '/admin')).status).toBe(403);
    expect((await postForm(A.author, '/admin/categories/1/delete', {}, '/admin')).status).toBe(403);
  });

  test('reader cannot create posts or moderate comments', async () => {
    expect((await postForm(A.reader, '/admin/posts/new', postData(), '/account')).status).toBe(403);
    expect((await postForm(A.reader, '/admin/comments/1/status', { status: 'approved' }, '/account')).status).toBe(403);
  });
});

describe('ownership (IDOR)', () => {
  test("author cannot open, edit, publish or delete the editor's post", async () => {
    const p = post('How AI is changing customer support'); // editor's post
    expect((await A.author.get(`/admin/posts/${p.id}/edit`)).status).toBe(403);
    expect((await postForm(A.author, `/admin/posts/${p.id}/edit`, postData({ title: 'Hijacked', status: 'published' }), '/admin')).status).toBe(403);
    expect((await postForm(A.author, `/admin/posts/${p.id}/status`, { status: 'archived' }, '/admin')).status).toBe(403);
    expect((await postForm(A.author, `/admin/posts/${p.id}/delete`, {}, '/admin')).status).toBe(403);
    expect(post('How AI is changing customer support').status).toBe('published');
  });

  test('contributor cannot edit their post once it is published', async () => {
    const p = post('A weekend in Abeokuta'); // contributor's, published
    expect((await A.contributor.get(`/admin/posts/${p.id}/edit`)).status).toBe(403);
    expect((await postForm(A.contributor, `/admin/posts/${p.id}/delete`, {}, '/admin')).status).toBe(403);
  });

  test("writers' post lists only show their own posts", async () => {
    const res = await A.author.get('/admin/posts');
    expect(res.text).toContain('Ten habits that keep your web app secure');
    expect(res.text).not.toContain('How AI is changing customer support');
    expect((await A.editor.get('/admin/posts')).text).toContain('Ten habits that keep your web app secure');
  });

  test("drafts are invisible to the public and to other writers, but previewable by the owner", async () => {
    const draft = post('Notes on password managers'); // author's draft
    expect((await agent(app).get(`/posts/${draft.slug}`)).status).toBe(404);
    expect((await A.reader.get(`/posts/${draft.slug}`)).status).toBe(404);
    expect((await A.contributor.get(`/posts/${draft.slug}`)).status).toBe(404);
    const preview = await A.author.get(`/posts/${draft.slug}`);
    expect(preview.status).toBe(200);
    expect(preview.text).toContain('Preview');
    expect(preview.text).toContain('noindex');
    expect((await A.editor.get(`/posts/${draft.slug}`)).status).toBe(200);
  });

  test('a reader cannot delete someone else\'s comment', async () => {
    const c = db.prepare("SELECT c.id FROM comments c JOIN users u ON u.id = c.user_id WHERE u.email = 'femi@blogx.test' AND c.status = 'approved'").get();
    const res = await postForm(A.reader, `/comments/${c.id}/delete`, {}, '/account');
    expect(res.status).toBe(403);
    expect(db.prepare('SELECT 1 FROM comments WHERE id = ?').get(c.id)).toBeDefined();
  });
});

describe('role changes and suspensions apply immediately', () => {
  test('a demoted editor loses access on the next request; a suspended user is signed out', async () => {
    const a = agent(app);
    await postForm(a, '/signup', { name: 'Temp Editor', email: 'temped@example.com', password: 'TempEdit2026', confirmPassword: 'TempEdit2026', terms: 'on' }, '/signup');
    db.prepare("UPDATE users SET role = 'editor' WHERE email = 'temped@example.com'").run();
    expect((await a.get('/admin/comments')).status).toBe(200);
    db.prepare("UPDATE users SET role = 'reader' WHERE email = 'temped@example.com'").run();
    expect((await a.get('/admin/comments')).status).toBe(403);
    db.prepare("UPDATE users SET status = 'suspended' WHERE email = 'temped@example.com'").run();
    const res = await a.get('/account');
    expect(res.status).toBe(302);
    expect(res.headers.location).toMatch(/^\/signin/);
  });
});

describe('navigation changes by role', () => {
  test('guest, reader and staff see different menus', async () => {
    const guest = await agent(app).get('/');
    expect(guest.text).toContain('href="/signin"');
    expect(guest.text).not.toContain('href="/admin"');
    const reader = await A.reader.get('/');
    expect(reader.text).toContain('Your account');
    expect(reader.text).not.toContain('href="/admin"');
    const author = await A.author.get('/admin');
    expect(author.text).not.toContain('href="/admin/users"');
    expect(author.text).not.toContain('href="/admin/comments"');
    const admin = await A.admin.get('/admin');
    expect(admin.text).toContain('href="/admin/users"');
    expect(admin.text).toContain('href="/admin/settings"');
  });
});

describe('open redirect protection', () => {
  test('sign-in ignores an external "next" URL', async () => {
    const a = agent(app);
    const _csrf = await csrfFrom(a, '/signin');
    const res = await a.post('/signin').type('form').send({ _csrf, email: 'reader@blogx.test', password: 'ReaderPass2026', next: '//evil.example.com' });
    expect(res.headers.location).toBe('/');
  });
});
