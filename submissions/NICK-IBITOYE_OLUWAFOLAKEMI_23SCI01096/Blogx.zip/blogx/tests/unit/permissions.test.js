const P = require('../../src/permissions');

const u = (role, id = 1, status = 'active') => ({ id, role, status });
const postBy = (authorId, status = 'draft') => ({ author_id: authorId, status });

describe('general permissions', () => {
  test.each([
    ['admin.access', ['contributor', 'author', 'editor', 'admin'], ['reader']],
    ['comments.moderate', ['editor', 'admin'], ['reader', 'contributor', 'author']],
    ['users.manage', ['admin'], ['reader', 'contributor', 'author', 'editor']],
    ['settings.manage', ['admin'], ['editor']],
    ['subscribers.view', ['editor', 'admin'], ['author']],
    ['subscribers.manage', ['admin'], ['editor']]
  ])('%s', (perm, allowed, denied) => {
    for (const r of allowed) expect(P.can(u(r), perm)).toBe(true);
    for (const r of denied) expect(P.can(u(r), perm)).toBe(false);
  });

  test('visitors (no user) and suspended users have no permissions', () => {
    expect(P.can(null, 'admin.access')).toBe(false);
    expect(P.can(u('admin', 1, 'suspended'), 'users.manage')).toBe(false);
  });

  test('an unknown permission name throws instead of silently allowing', () => {
    expect(() => P.can(u('admin'), 'everything')).toThrow();
  });
});

describe('post ownership rules', () => {
  test('contributors edit only their own drafts/reviews', () => {
    expect(P.canEditPost(u('contributor', 5), postBy(5, 'draft'))).toBe(true);
    expect(P.canEditPost(u('contributor', 5), postBy(5, 'review'))).toBe(true);
    expect(P.canEditPost(u('contributor', 5), postBy(5, 'published'))).toBe(false);
    expect(P.canEditPost(u('contributor', 5), postBy(6, 'draft'))).toBe(false);
  });

  test('authors edit their own posts in any status, not other people\'s', () => {
    expect(P.canEditPost(u('author', 5), postBy(5, 'published'))).toBe(true);
    expect(P.canEditPost(u('author', 5), postBy(6, 'draft'))).toBe(false);
  });

  test('editors and admins edit everything; readers nothing', () => {
    expect(P.canEditPost(u('editor', 5), postBy(9, 'published'))).toBe(true);
    expect(P.canEditPost(u('admin', 5), postBy(9, 'draft'))).toBe(true);
    expect(P.canEditPost(u('reader', 5), postBy(5, 'draft'))).toBe(false);
  });

  test('publishing: authors (own) and editors only', () => {
    expect(P.canPublishPost(u('contributor', 5), postBy(5))).toBe(false);
    expect(P.canPublishPost(u('author', 5), postBy(5))).toBe(true);
    expect(P.canPublishPost(u('author', 5), postBy(6))).toBe(false);
    expect(P.canPublishPost(u('author', 5), null)).toBe(true); // new post
    expect(P.canPublishPost(u('editor', 5), postBy(6))).toBe(true);
  });

  test('deleting posts, media and comments', () => {
    expect(P.canDeletePost(u('contributor', 5), postBy(5, 'draft'))).toBe(true);
    expect(P.canDeletePost(u('contributor', 5), postBy(5, 'published'))).toBe(false);
    expect(P.canDeletePost(u('author', 5), postBy(6, 'draft'))).toBe(false);
    expect(P.canDeleteMedia(u('author', 5), { uploaded_by: 6 })).toBe(false);
    expect(P.canDeleteMedia(u('editor', 5), { uploaded_by: 6 })).toBe(true);
    expect(P.canDeleteComment(u('reader', 5), { user_id: 5 })).toBe(true);
    expect(P.canDeleteComment(u('reader', 5), { user_id: 6 })).toBe(false);
    expect(P.canDeleteComment(u('editor', 5), { user_id: 6 })).toBe(true);
  });
});
