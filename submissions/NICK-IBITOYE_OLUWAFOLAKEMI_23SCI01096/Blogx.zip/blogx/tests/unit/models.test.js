process.env.NODE_ENV = 'test';
const db = require('../../src/db');
const seed = require('../../src/db/seed');
const Posts = require('../../src/models/posts');
const Comments = require('../../src/models/comments');
const Stats = require('../../src/models/stats');
const { categories, tags } = require('../../src/models/taxonomy');

beforeAll(() => seed({ quiet: true }));
const byTitle = (t) => Posts.findById(db.prepare('SELECT id FROM posts WHERE title = ?').get(t).id);

test('only published posts whose time has come are public', () => {
  const titles = Posts.searchPublic({ perPage: 50 }).items.map((p) => p.title);
  expect(titles).toContain('Welcome to Blog.x');
  expect(titles).not.toContain('Coming soon: our December reading list'); // scheduled
  expect(titles).not.toContain('Notes on password managers'); // draft
  expect(titles).not.toContain('My favourite street foods in Surulere'); // in review
  expect(titles).not.toContain('Our 2025 roadmap (archived)');
  expect(byTitle('Coming soon: our December reading list').display_status).toBe('scheduled');
});

test('a category listing includes its sub-categories', () => {
  const tech = categories.findBySlug('technology');
  const titles = Posts.searchPublic({ category: tech, perPage: 50 }).items.map((p) => p.title);
  expect(titles).toEqual(expect.arrayContaining(['Ten habits that keep your web app secure', 'Building a blog with Node.js and SQLite', 'How AI is changing customer support']));
});

test('search looks in titles and body text; tag filter works', () => {
  expect(Posts.searchPublic({ q: 'akara' }).items.map((p) => p.title)).toEqual(['The joy of a Saturday morning in Yaba']);
  const sec = tags.findBySlug('security');
  expect(Posts.searchPublic({ tag: sec }).total).toBe(1);
});

test('saving a post sanitizes it, makes a unique slug and computes reading time', () => {
  const author = db.prepare("SELECT id FROM users WHERE role = 'author'").get().id;
  const values = { title: 'Welcome to Blog.x', slug: '', excerpt: '', contentHtml: '<p>Hi</p><script>bad()</script>' + '<p>word </p>'.repeat(10), featureImage: '', categoryId: null, tags: ['A', 'a', 'B'], featured: false, allowComments: true, metaTitle: '', metaDescription: '', canonicalUrl: '', noindex: false };
  const p = Posts.save({ authorId: author, values, status: 'draft', publishedAt: null });
  expect(p.slug).toBe('welcome-to-blog-x-2');
  expect(p.content_html).not.toContain('<script>');
  expect(p.excerpt).toMatch(/^Hi/);
  expect(tags.forPost(p.id).map((t) => t.name)).toEqual(['A', 'B']); // duplicates (any case) ignored
});

test('category with sub-categories or posts cannot be deleted', () => {
  expect(categories.remove(categories.findBySlug('technology').id)).toMatch(/sub-categories/);
  expect(categories.remove(categories.findBySlug('business').id)).toMatch(/posts/);
});

test('comment moderation modes', () => {
  const reader = { id: db.prepare("SELECT id FROM users WHERE email = 'reader@blogx.test'").get().id, role: 'reader' };
  const newbie = { id: db.prepare("SELECT id FROM users WHERE email = 'femi@blogx.test'").get().id, role: 'reader' };
  expect(Comments.initialStatus(reader, 'all')).toBe('pending');
  expect(Comments.initialStatus(reader, 'none')).toBe('approved');
  expect(Comments.initialStatus(reader, 'first')).toBe('approved'); // already has approved comments
  db.prepare("UPDATE comments SET status = 'pending' WHERE user_id = ?").run(newbie.id);
  expect(Comments.initialStatus(newbie, 'first')).toBe('pending');
  expect(Comments.initialStatus({ id: 1, role: 'editor' }, 'all')).toBe('approved'); // staff
});

test('view statistics: daily series is zero-filled and totals add up', () => {
  const p = byTitle('Welcome to Blog.x');
  const before = Stats.total(30);
  Stats.recordView(p.id);
  expect(Stats.total(30)).toBe(before + 1);
  const daily = Stats.daily(7);
  expect(daily).toHaveLength(7);
  expect(daily[6].day).toBe(new Date().toISOString().slice(0, 10));
});
