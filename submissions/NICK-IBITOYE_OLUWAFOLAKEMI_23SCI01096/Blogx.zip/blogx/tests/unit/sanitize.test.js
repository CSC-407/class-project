process.env.NODE_ENV = 'test';
const { cleanPostHtml, htmlToText, readingMinutes, makeExcerpt } = require('../../src/utils/sanitize');

const IMG = '/uploads/' + 'a'.repeat(32) + '.jpg';

describe('cleanPostHtml (stored-XSS defence)', () => {
  test.each([
    ['<script>alert(1)</script><p>ok</p>', '<p>ok</p>'],
    ['<p onclick="steal()">hi</p>', '<p>hi</p>'],
    ['<img src=x onerror=alert(1)>', ''],
    ['<a href="javascript:alert(1)">x</a>', '<a>x</a>'],
    ['<a href="data:text/html;base64,PHNjcmlwdD4=">x</a>', '<a>x</a>'],
    ['<iframe src="https://evil.com"></iframe>', ''],
    ['<p style="background:url(javascript:alert(1))">x</p>', '<p>x</p>'],
    ['<svg><script>alert(1)</script></svg>', ''],
    ['<form action="https://evil.com"><input name=pw></form>', ''],
    ['<object data="x"></object><embed src="x">', '']
  ])('removes %p', (dirty, expected) => {
    expect(cleanPostHtml(dirty)).toBe(expected);
  });

  test('keeps the formatting the editor produces', () => {
    const html = '<h2>Title</h2><p><strong>b</strong> <em>i</em> <code>c</code></p><blockquote>q</blockquote><ul><li>x</li></ul><ol><li>y</li></ol><pre><code>z</code></pre><hr />';
    expect(cleanPostHtml(html)).toBe(html);
  });

  test('external links open safely in a new tab; internal links stay as they are', () => {
    expect(cleanPostHtml('<a href="https://ok.com">ok</a>')).toBe('<a href="https://ok.com" target="_blank" rel="noopener noreferrer">ok</a>');
    expect(cleanPostHtml('<a href="/security">s</a>')).toBe('<a href="/security">s</a>');
  });

  test('images are only allowed from our own media library', () => {
    expect(cleanPostHtml(`<img src="${IMG}" alt="A">`)).toBe(`<img src="${IMG}" alt="A" loading="lazy" />`);
    expect(cleanPostHtml('<img src="https://tracker.example/pixel.gif">')).toBe('');
    expect(cleanPostHtml('<img src="/uploads/../../server.js">')).toBe('');
    expect(cleanPostHtml(`<img src="http://localhost:3000${IMG}">`)).toContain(`src="${IMG}"`);
  });

  test('b/i become strong/em and empty paragraphs are dropped', () => {
    expect(cleanPostHtml('<p><b>x</b><i>y</i></p><p><br></p>')).toBe('<p><strong>x</strong><em>y</em></p>');
  });
});

test('htmlToText, readingMinutes and makeExcerpt', () => {
  expect(htmlToText('<p>Hello <strong>world</strong> &amp; friends</p>')).toBe('Hello world & friends');
  expect(readingMinutes('word '.repeat(460))).toBe(2);
  expect(readingMinutes('')).toBe(1);
  expect(makeExcerpt('one two three four', 9)).toBe('one two…');
});
