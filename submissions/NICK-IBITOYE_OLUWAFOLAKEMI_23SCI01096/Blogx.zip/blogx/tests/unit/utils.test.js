process.env.NODE_ENV = 'test';
const v = require('../../src/utils/validators');
const { toCsv } = require('../../src/utils/csv');
const { slugify, randomToken, toPositiveInt, lagosLocalToSql, sqlToLagosLocal, formatDate } = require('../../src/utils/helpers');
const { redact } = require('../../src/utils/logger');
const { detectImageType } = require('../../src/middleware/upload');
const { safeNext } = require('../../src/middleware/auth');

describe('validators', () => {
  const reg = { name: 'Adaeze Okafor', email: 'ADA@Example.com', password: 'GoodPass2026', confirmPassword: 'GoodPass2026', terms: 'on' };

  test('valid registration is normalised', () => {
    const { values, errors } = v.validateRegister(reg);
    expect(errors).toEqual({});
    expect(values.email).toBe('ada@example.com');
  });

  test('empty registration reports every required field', () => {
    expect(Object.keys(v.validateRegister({}).errors)).toEqual(expect.arrayContaining(['name', 'email', 'password', 'terms']));
  });

  test.each([['short1A', 'at least 10'], ['alllowercase1', 'uppercase'], ['NoDigitsHereAtAll', 'uppercase']])('weak password %p', (pw, msg) => {
    expect(v.validateRegister({ ...reg, password: pw, confirmPassword: pw }).errors.password).toMatch(msg);
  });

  test('HTML in a name and array-tampered fields are rejected', () => {
    expect(v.validateRegister({ ...reg, name: '<img src=x>' }).errors.name).toBeDefined();
    expect(v.validateRegister({ ...reg, email: ['a@b.co'] }).errors.email).toBeDefined();
  });

  test('post validation: status allow-list, slug format, canonical URL scheme, tags', () => {
    const { errors } = v.validatePost({ title: 'Hi there', status: 'hacked', slug: 'Bad Slug!', canonicalUrl: 'javascript:alert(1)', tags: 'ok, <script>' }, { categoryIds: [1] });
    expect(Object.keys(errors)).toEqual(expect.arrayContaining(['status', 'slug', 'canonicalUrl', 'tags']));
    expect(v.validatePost({ title: 'Hi there', status: 'draft', categoryId: '99' }, { categoryIds: [1] }).errors.categoryId).toBeDefined();
    expect(v.validatePost({ title: 'Hi there', status: 'draft', featureImage: 'https://evil.com/x.jpg' }, { categoryIds: [] }).errors.featureImage).toBeDefined();
  });

  test('settings: accent colour must be a strict #rrggbb value', () => {
    const base = { site_title: 'Blog', accent_color: '#ff1a75', posts_per_page: '9', comment_moderation: 'first' };
    expect(v.validateSettings(base).errors).toEqual({});
    expect(v.validateSettings({ ...base, accent_color: 'red;}body{display:none' }).errors.accent_color).toBeDefined();
    expect(v.validateSettings({ ...base, posts_per_page: '500' }).errors.posts_per_page).toBeDefined();
  });

  test('comments: 2–2000 characters', () => {
    expect(v.validateComment({ body: ' ' }).errors.body).toBeDefined();
    expect(v.validateComment({ body: 'x'.repeat(2001) }).errors.body).toBeDefined();
    expect(v.validateComment({ body: 'Nice post' }).errors).toEqual({});
  });
});

describe('helpers', () => {
  test('slugify', () => expect(slugify('Ẹ káàbọ̀: Lagos & Co!')).toBe('e-kaabo-lagos-co'));
  test('random tokens are long and unique', () => {
    const set = new Set(Array.from({ length: 200 }, () => randomToken()));
    expect(set.size).toBe(200);
    for (const t of set) expect(t).toMatch(/^[a-f0-9]{48}$/);
  });
  test('toPositiveInt rejects junk', () => {
    for (const bad of ['0', '-1', '1.5', '1 OR 1=1', undefined]) expect(toPositiveInt(bad)).toBeNull();
  });
  test('Lagos time round-trips through UTC', () => {
    expect(lagosLocalToSql('2026-12-01T09:30')).toBe('2026-12-01 08:30:00');
    expect(sqlToLagosLocal('2026-12-01 08:30:00')).toBe('2026-12-01T09:30');
    expect(lagosLocalToSql('next tuesday')).toBeNull();
    expect(formatDate('2026-11-15 10:00:00')).toBe('15 Nov 2026');
  });
});

test('CSV export neutralises spreadsheet formulas', () => {
  const csv = toCsv(['email', 'name'], [['a@b.co', '=HYPERLINK("http://evil","click")'], ['c@d.co', '+1+1'], ['e@f.co', 'Ada "The" Best']]);
  expect(csv).toContain(`"'=HYPERLINK(""http://evil"",""click"")"`);
  expect(csv).toContain(`"'+1+1"`);
  expect(csv).toContain('"Ada ""The"" Best"');
});

test('logger redacts secrets', () => {
  const out = redact({ password: 'x', nested: { csrfToken: 'y', note: 'card 4111111111111111' }, email: 'a@b.co' });
  expect(out.password).toBe('[REDACTED]');
  expect(out.nested.csrfToken).toBe('[REDACTED]');
  expect(out.nested.note).not.toContain('4111111111111111');
});

test('image type comes from file bytes, not the name', () => {
  expect(detectImageType(Buffer.from('GIF89a......'))).toBe('gif');
  expect(detectImageType(Buffer.from([0xff, 0xd8, 0xff, 0, 0, 0, 0, 0, 0, 0, 0, 0]))).toBe('jpg');
  expect(detectImageType(Buffer.from('<svg onload=alert(1)></svg>'))).toBeNull();
  expect(detectImageType(Buffer.from('<?php system($_GET[c]); ?>'))).toBeNull();
});

test('safeNext blocks open redirects', () => {
  expect(safeNext('/admin/posts')).toBe('/admin/posts');
  for (const bad of ['//evil.com', 'https://evil.com', '/\\evil.com', 'javascript:alert(1)']) expect(safeNext(bad)).toBeNull();
});
