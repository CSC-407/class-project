/**
 * Shared test helpers. Each Jest test FILE gets a brand-new in-memory database
 * (NODE_ENV=test → ':memory:'), so tests never touch real data.
 */
process.env.NODE_ENV = 'test';
const request = require('supertest');
const createApp = require('../src/app');
const seed = require('../src/db/seed');
const db = require('../src/db');

const ACCOUNTS = {
  admin: { email: 'admin@blogx.test', password: 'ChangeMe2026!' },
  editor: { email: 'editor@blogx.test', password: 'EditorPass2026' },
  author: { email: 'author@blogx.test', password: 'AuthorPass2026' },
  contributor: { email: 'contributor@blogx.test', password: 'ContribPass2026' },
  reader: { email: 'reader@blogx.test', password: 'ReaderPass2026' },
  reader2: { email: 'femi@blogx.test', password: 'ReaderPass2026' }
};

function setup(options) {
  seed({ quiet: true });
  return createApp(options);
}

const agent = (app) => request.agent(app);

/** Read the CSRF token from any page's hidden _csrf field. */
async function csrfFrom(a, url = '/signin') {
  const res = await a.get(url);
  const m = res.text.match(/name="_csrf" value="([a-f0-9]{64})"/);
  if (!m) throw new Error(`No CSRF token on ${url} (status ${res.status})`);
  return m[1];
}

async function login(a, who) {
  const creds = typeof who === 'string' ? ACCOUNTS[who] : who;
  const _csrf = await csrfFrom(a, '/signin');
  return a.post('/signin').type('form').send({ _csrf, ...creds });
}

/** Signed-in agent for a seeded role. */
async function as(app, role) {
  const a = agent(app);
  await login(a, role);
  return a;
}

/** POST a form with a valid CSRF token taken from `pageUrl`. */
async function postForm(a, url, data = {}, pageUrl = '/') {
  const _csrf = await csrfFrom(a, pageUrl);
  return a.post(url).type('form').send({ _csrf, ...data });
}

const post = (title) => db.prepare('SELECT * FROM posts WHERE title = ?').get(title);
const userId = (role) => db.prepare('SELECT id FROM users WHERE email = ?').get(ACCOUNTS[role].email).id;

/** Minimal valid editor form. */
function postData(over = {}) {
  return { title: 'A test post', slug: '', excerpt: '', contentHtml: '<p>Hello world from the tests.</p>', featureImage: '', categoryId: '', tags: '', status: 'draft', publishAt: '', allowComments: 'on', metaTitle: '', metaDescription: '', canonicalUrl: '', ...over };
}

module.exports = { request, db, setup, agent, csrfFrom, login, as, postForm, post, userId, postData, ACCOUNTS };
