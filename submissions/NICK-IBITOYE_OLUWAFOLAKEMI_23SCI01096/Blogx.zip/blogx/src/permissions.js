/**
 * ROLE-BASED ACCESS CONTROL (RBAC)
 *
 * Every permission check in Blog.x goes through this ONE file, so the rules are easy to
 * read, test and defend. Routes call these functions on the SERVER before doing anything;
 * hiding a button in the page is only a convenience, never the protection.
 *
 * Roles, from least to most powerful:
 *   reader       – registered visitor: comment, manage own comments, newsletter, profile
 *   contributor  – write posts and submit them for review; cannot publish
 *   author       – publish and manage their OWN posts
 *   editor       – manage ALL posts, categories, tags, comments and subscribers; view stats
 *   admin        – everything, plus users, site settings and the audit log
 * (Visitors who are not logged in can only read published content and subscribe.)
 */

const ROLES = ['reader', 'contributor', 'author', 'editor', 'admin'];
const RANK = Object.fromEntries(ROLES.map((r, i) => [r, i]));

const ROLE_LABELS = {
  reader: 'Reader',
  contributor: 'Contributor',
  author: 'Author',
  editor: 'Editor',
  admin: 'Administrator'
};

// Minimum role needed for each general permission.
const MIN_ROLE = {
  'admin.access': 'contributor',
  'post.create': 'contributor',
  'media.upload': 'contributor',
  'post.editAny': 'editor',
  'post.publishAny': 'editor',
  'media.deleteAny': 'editor',
  'taxonomy.manage': 'editor',
  'comments.moderate': 'editor',
  'subscribers.view': 'editor',
  'stats.viewAll': 'editor',
  'subscribers.manage': 'admin',
  'users.manage': 'admin',
  'settings.manage': 'admin',
  'audit.view': 'admin'
};

function atLeast(user, role) {
  return !!user && user.status === 'active' && RANK[user.role] >= RANK[role];
}

/** General permission check, e.g. can(user, 'comments.moderate') */
function can(user, permission) {
  const min = MIN_ROLE[permission];
  if (!min) throw new Error(`Unknown permission: ${permission}`); // typos fail loudly, never silently allow
  return atLeast(user, min);
}

const isOwner = (user, post) => !!user && !!post && post.author_id === user.id;

/** Who may open a post in the editor and save changes to it. */
function canEditPost(user, post) {
  if (!post || !atLeast(user, 'contributor')) return false;
  if (can(user, 'post.editAny')) return true;
  if (!isOwner(user, post)) return false;
  if (user.role === 'author') return true;
  // Contributors lose edit rights once an editor has published (or archived) their post.
  return post.status === 'draft' || post.status === 'review';
}

/** Who may set a post's status to "published" (or schedule it). */
function canPublishPost(user, post) {
  if (can(user, 'post.publishAny')) return true;
  return atLeast(user, 'author') && (post ? isOwner(user, post) : true);
}

function canDeletePost(user, post) {
  if (!post || !atLeast(user, 'contributor')) return false;
  if (can(user, 'post.editAny')) return true;
  if (!isOwner(user, post)) return false;
  return user.role === 'author' || post.status !== 'published';
}

function canDeleteMedia(user, item) {
  if (!item) return false;
  return can(user, 'media.deleteAny') || (atLeast(user, 'contributor') && item.uploaded_by === user.id);
}

/** Readers may delete their own comments; moderators may delete any. */
function canDeleteComment(user, comment) {
  if (!comment || !user || user.status !== 'active') return false;
  return can(user, 'comments.moderate') || comment.user_id === user.id;
}

module.exports = {
  ROLES,
  ROLE_LABELS,
  MIN_ROLE,
  atLeast,
  can,
  canEditPost,
  canPublishPost,
  canDeletePost,
  canDeleteMedia,
  canDeleteComment
};
