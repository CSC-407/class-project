/**
 * Builds the Express application (server.js starts it; tests import it directly).
 * Every request flows through the middleware below from top to bottom.
 */
const path = require('path');
const express = require('express');
const session = require('express-session');
const config = require('./config');
const db = require('./db');
const Settings = require('./models/settings');
const { categories } = require('./models/taxonomy');
const { securityHeaders } = require('./middleware/security');
const { csrfProtection } = require('./middleware/csrf');
const { loadUser, enforcePasswordChange } = require('./middleware/auth');
const { notFound, errorHandler } = require('./middleware/errors');
const permissions = require('./permissions');
const { formatDate } = require('./utils/helpers');

function createApp(options = {}) {
  const app = express();
  if (config.trustProxy) app.set('trust proxy', 1); // behind Render/Nginx: trust X-Forwarded-Proto for HTTPS detection

  app.set('view engine', 'ejs');
  app.set('views', path.join(config.root, 'views'));

  // 1. SECURITY HEADERS: Content-Security-Policy, anti-clickjacking, nosniff, HSTS (production)…
  app.use(securityHeaders());

  // 2. Theme stylesheet built from the admin's accent colour. Served from our own origin, so the
  //    strict CSP (no inline styles) still holds. The colour is validated as #rrggbb on save.
  app.get('/theme.css', (req, res) => {
    const accent = Settings.get('accent_color');
    const safe = /^#[0-9a-f]{6}$/i.test(accent) ? accent : '#ff1a75';
    res.type('text/css').set('Cache-Control', 'no-cache').send(`:root{--accent:${safe};}\n`);
  });

  // 3. Static files. dotfiles are refused so a stray .env could never be downloaded.
  //    Uploads come from UPLOAD_DIR (which may live on a separate disk in production).
  app.use('/uploads', express.static(config.uploadDir, { dotfiles: 'deny', maxAge: config.isProd ? '30d' : 0, index: false }));
  app.use(express.static(path.join(config.root, 'public'), { dotfiles: 'deny', maxAge: config.isProd ? '7d' : 0 }));

  // 4. Form parsing with size limits (big enough for long posts, small enough to stop abuse).
  app.use(express.urlencoded({ extended: false, limit: '300kb', parameterLimit: 60 }));

  // 5. SESSIONS — the cookie only holds a signed random id; data stays on the server.
  let store;
  if (!config.isTest) {
    const SqliteStore = require('better-sqlite3-session-store')(session);
    store = new SqliteStore({ client: db, expired: { clear: true, intervalMs: 15 * 60 * 1000 } });
  }
  app.use(session({
    name: 'bx.sid',               // custom name, doesn't advertise Express
    secret: config.sessionSecret, // from .env; signs the cookie so it can't be forged
    store,
    resave: false,
    saveUninitialized: false,
    rolling: true,                // each request restarts the idle timer…
    cookie: {
      httpOnly: true,             // JavaScript can't read it → XSS can't steal the session
      secure: config.isProd,      // HTTPS only in production
      sameSite: 'lax',            // not sent with cross-site form posts → blocks most CSRF
      maxAge: config.sessionMinutes * 60 * 1000 // …and the session expires after this much inactivity
    }
  }));

  // 6. Values every template needs. Set BEFORE the security checks so even a rejected request
  //    can be shown a normal error page.
  app.use((req, res, next) => {
    res.locals.site = Settings.all();
    res.locals.navCategories = categories.tree();
    res.locals.currentPath = req.path;
    res.locals.currentUser = null;
    res.locals.csrfToken = '';
    res.locals.errors = {};
    res.locals.values = {};
    res.locals.meta = {};
    res.locals.formatDate = formatDate;
    res.locals.can = (perm) => permissions.can(req.user, perm);
    res.locals.ROLE_LABELS = permissions.ROLE_LABELS;
    res.locals.siteUrl = config.siteUrl;
    res.locals.flash = req.session.flash || null; // one-time banner after a redirect
    delete req.session.flash;
    next();
  });

  // 7. Who is logged in (re-checked against the database on every request)
  app.use(loadUser);
  // 8. CSRF token check on every state-changing request
  app.use(csrfProtection);
  // 9. Accounts with a temporary password must change it first
  app.use(enforcePasswordChange);

  app.use(require('./routes/public'));
  app.use(require('./routes/auth')(options));
  app.use(require('./routes/community'));
  app.use('/account', require('./routes/account'));
  app.use('/admin', require('./routes/admin'));

  app.use(notFound);
  app.use(errorHandler);
  return app;
}

module.exports = createApp;
