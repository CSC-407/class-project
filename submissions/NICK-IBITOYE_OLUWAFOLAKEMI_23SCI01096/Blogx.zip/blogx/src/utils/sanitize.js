/**
 * RICH-TEXT (HTML) SANITIZING — the main XSS defence for blog posts.
 *
 * The editor sends HTML to the server. Anyone can bypass the editor and send their own
 * HTML (e.g. <img src=x onerror="steal()"> or <a href="javascript:...">). So the server
 * rebuilds every post through an ALLOW-LIST: only the tags and attributes listed below
 * survive; everything else (scripts, event handlers, styles, iframes, forms, unknown
 * URL schemes) is removed BEFORE the post is saved.
 */
const sanitizeHtml = require('sanitize-html');

const POST_OPTIONS = {
  allowedTags: ['h2', 'h3', 'h4', 'p', 'br', 'hr', 'strong', 'b', 'em', 'i', 'u', 's', 'blockquote',
    'ul', 'ol', 'li', 'a', 'code', 'pre', 'figure', 'figcaption', 'img'],
  allowedAttributes: {
    a: ['href', 'title', 'target', 'rel'],
    img: ['src', 'alt', 'width', 'height', 'loading']
  },
  // Links: only web, email and on-site links. javascript:, data:, vbscript: … are dropped.
  allowedSchemes: ['http', 'https', 'mailto'],
  allowedSchemesByTag: { img: [] },
  allowProtocolRelative: false,
  disallowedTagsMode: 'discard',
  exclusiveFilter: (frame) =>
    // Images may only come from our own media library, never from other sites (no tracking pixels).
    frame.tag === 'img' && !/^\/uploads\/[a-f0-9]{32}\.(jpg|png|webp|gif)$/.test(frame.attribs.src || ''),
  transformTags: {
    b: 'strong',
    i: 'em',
    // External links open safely: rel="noopener noreferrer" stops the new tab controlling ours.
    a: (tagName, attribs) => {
      const out = { href: attribs.href || '' };
      if (attribs.title) out.title = attribs.title;
      if (/^https?:\/\//i.test(out.href)) {
        out.target = '_blank';
        out.rel = 'noopener noreferrer';
      }
      return { tagName: 'a', attribs: out };
    },
    // Same-site absolute image URLs (http://host/uploads/…) are shortened to /uploads/… before the allow-list check.
    img: (tagName, attribs) => ({
      tagName: 'img',
      attribs: { src: String(attribs.src || '').replace(/^https?:\/\/[^/]+(?=\/uploads\/)/i, ''), alt: attribs.alt || '', loading: 'lazy' }
    })
  }
};

/** Clean post HTML. Also drops empty paragraphs left by the editor. */
function cleanPostHtml(html) {
  const cleaned = sanitizeHtml(String(html || ''), POST_OPTIONS);
  return cleaned.replace(/<p>(\s|&nbsp;|<br \/>)*<\/p>/g, '').trim();
}

/** Plain text from HTML (for search, excerpts and reading time). */
function htmlToText(html) {
  return sanitizeHtml(String(html || ''), { allowedTags: [], allowedAttributes: {} })
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

/** Average adult reading speed ≈ 230 words per minute. */
function readingMinutes(text) {
  const words = String(text || '').split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 230));
}

/** First ~maxLen characters, cut at a word boundary. */
function makeExcerpt(text, maxLen = 200) {
  const t = String(text || '').trim();
  if (t.length <= maxLen) return t;
  return t.slice(0, maxLen).replace(/\s+\S*$/, '') + '…';
}

module.exports = { cleanPostHtml, htmlToText, readingMinutes, makeExcerpt };
