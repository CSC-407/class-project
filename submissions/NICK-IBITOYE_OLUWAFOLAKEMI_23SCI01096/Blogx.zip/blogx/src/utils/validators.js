/**
 * SERVER-SIDE VALIDATION
 *
 * The browser checks forms too (HTML attributes + public/js/site.js), but that can be
 * switched off or bypassed with tools like curl or Postman. These functions are the real
 * gatekeepers: every form is validated here before anything touches the database.
 *
 * Each validator returns { values, errors }. Empty errors = valid.
 */

const EMAIL_RE = /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[a-z]{2,}$/i;
const NAME_RE = /^[\p{L}][\p{L}\s.'-]*$/u;
const HEX_RE = /^#[0-9a-f]{6}$/i;
const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

/** Trimmed string; anything that is not a string (arrays/objects from tampered forms) becomes ''. */
function str(value, max = 1000) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}

function raw(value, max) {
  return typeof value === 'string' ? value.slice(0, max) : '';
}

const has = (errors) => Object.keys(errors).length > 0;

function checkName(name, errors) {
  if (!name) errors.name = 'Please enter your name.';
  else if (name.length < 2 || name.length > 60) errors.name = 'Name must be 2–60 characters.';
  else if (!NAME_RE.test(name)) errors.name = 'Name can only contain letters, spaces, hyphens and apostrophes.';
}

function checkEmail(email, errors) {
  if (!email) errors.email = 'Please enter your email address.';
  else if (email.length > 254 || !EMAIL_RE.test(email)) errors.email = 'Please enter a valid email address.';
}

/** Strong password: 10–72 characters (72 is bcrypt's limit) with upper, lower and a number. */
function checkPassword(pw, errors, field = 'password') {
  if (!pw) errors[field] = 'Please enter a password.';
  else if (pw.length < 10) errors[field] = 'Password must be at least 10 characters.';
  else if (Buffer.byteLength(pw) > 72) errors[field] = 'Password is too long (maximum 72 characters).';
  else if (!/[a-z]/.test(pw) || !/[A-Z]/.test(pw) || !/\d/.test(pw)) {
    errors[field] = 'Password must include an uppercase letter, a lowercase letter and a number.';
  }
}

/** Only absolute http(s) URLs are accepted for links shown on the site. */
function checkUrl(url, errors, field, label) {
  if (!url) return;
  let ok = false;
  try {
    const u = new URL(url);
    ok = (u.protocol === 'https:' || u.protocol === 'http:') && url.length <= 300;
  } catch { ok = false; }
  if (!ok) errors[field] = `${label} must be a full web address starting with https://`;
}

function validateRegister(body) {
  const errors = {};
  const values = { name: str(body.name, 60), email: str(body.email, 254).toLowerCase(), newsletter: body.newsletter === 'on' };
  const password = raw(body.password, 200);
  checkName(values.name, errors);
  checkEmail(values.email, errors);
  checkPassword(password, errors);
  if (!errors.password && password !== raw(body.confirmPassword, 200)) errors.confirmPassword = 'Passwords do not match.';
  if (body.terms !== 'on') errors.terms = 'Please accept the terms to create an account.';
  return { values: { ...values, password }, errors };
}

function validateLogin(body) {
  const errors = {};
  const values = { email: str(body.email, 254).toLowerCase() };
  const password = raw(body.password, 200);
  if (!values.email) errors.email = 'Please enter your email address.';
  if (!password) errors.password = 'Please enter your password.';
  return { values: { ...values, password }, errors };
}

function validateProfile(body) {
  const errors = {};
  const values = { name: str(body.name, 60), email: str(body.email, 254).toLowerCase(), bio: str(body.bio, 300), website: str(body.website, 300) };
  checkName(values.name, errors);
  checkEmail(values.email, errors);
  checkUrl(values.website, errors, 'website', 'Website');
  return { values, errors };
}

function validatePasswordChange(body, { requireCurrent = true } = {}) {
  const errors = {};
  const current = raw(body.currentPassword, 200);
  const next = raw(body.newPassword, 200);
  if (requireCurrent && !current) errors.currentPassword = 'Please enter your current password.';
  checkPassword(next, errors, 'newPassword');
  if (!errors.newPassword && next !== raw(body.confirmPassword, 200)) errors.confirmPassword = 'Passwords do not match.';
  if (!errors.newPassword && current && current === next) errors.newPassword = 'Choose a password different from your current one.';
  return { values: { current, next }, errors };
}

const POST_STATUSES = ['draft', 'review', 'published', 'archived'];

/**
 * Post editor form. Content HTML is length-checked here and SANITIZED in the model
 * (src/utils/sanitize.js) before it is stored.
 */
function validatePost(body, { categoryIds }) {
  const errors = {};
  const values = {
    title: str(body.title, 150),
    slug: str(body.slug, 80).toLowerCase(),
    excerpt: str(body.excerpt, 300),
    contentHtml: raw(body.contentHtml, 200000),
    featureImage: str(body.featureImage, 120),
    categoryId: body.categoryId ? Number(body.categoryId) : null,
    tags: str(body.tags, 300).split(',').map((t) => t.trim()).filter(Boolean),
    status: str(body.status, 20),
    publishAt: str(body.publishAt, 20),
    featured: body.featured === 'on',
    allowComments: body.allowComments === 'on',
    metaTitle: str(body.metaTitle, 70),
    metaDescription: str(body.metaDescription, 170),
    canonicalUrl: str(body.canonicalUrl, 300),
    noindex: body.noindex === 'on'
  };
  if (values.title.length < 3) errors.title = 'Title must be at least 3 characters.';
  if (values.slug && !SLUG_RE.test(values.slug)) errors.slug = 'URL slug may only contain lowercase letters, numbers and single hyphens.';
  if (typeof body.contentHtml === 'string' && body.contentHtml.length > 200000) errors.contentHtml = 'The post is too long (maximum 200,000 characters of HTML).';
  if (values.categoryId !== null && !categoryIds.includes(values.categoryId)) errors.categoryId = 'Please choose a category from the list.';
  if (!POST_STATUSES.includes(values.status)) errors.status = 'Please choose a status.';
  if (values.featureImage && !/^\/(uploads\/[a-f0-9]{32}\.(jpg|png|webp|gif)|images\/covers\/[a-z0-9-]+\.jpg)$/.test(values.featureImage)) {
    errors.featureImage = 'Choose the feature image from the media library.';
  }
  if (values.tags.length > 10) errors.tags = 'Use at most 10 tags.';
  else if (values.tags.some((t) => t.length > 30 || !/^[\p{L}\p{N}][\p{L}\p{N} .&'-]*$/u.test(t))) {
    errors.tags = 'Tags may use letters, numbers, spaces and - . & \' (max 30 characters each).';
  }
  if (values.publishAt && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(values.publishAt)) errors.publishAt = 'Enter a valid date and time.';
  checkUrl(values.canonicalUrl, errors, 'canonicalUrl', 'Canonical URL');
  return { values, errors };
}

function validateCategory(body, { parentIds }) {
  const errors = {};
  const values = { name: str(body.name, 50), description: str(body.description, 200), parentId: body.parentId ? Number(body.parentId) : null };
  if (values.name.length < 2) errors.name = 'Name must be at least 2 characters.';
  if (values.parentId !== null && !parentIds.includes(values.parentId)) errors.parentId = 'Choose a top-level category as the parent.';
  return { values, errors };
}

function validateTag(body) {
  const errors = {};
  const values = { name: str(body.name, 30) };
  if (!values.name || !/^[\p{L}\p{N}][\p{L}\p{N} .&'-]*$/u.test(values.name)) errors.name = 'Tag names may use letters, numbers, spaces and - . & \'';
  return { values, errors };
}

function validateComment(body) {
  const errors = {};
  const values = { body: str(body.body, 2000) };
  if (values.body.length < 2) errors.body = 'Please write a comment (at least 2 characters).';
  if (typeof body.body === 'string' && body.body.trim().length > 2000) errors.body = 'Comments can be at most 2,000 characters.';
  return { values, errors };
}

function validateSubscribe(body) {
  const errors = {};
  const values = { email: str(body.email, 254).toLowerCase(), name: str(body.name, 60) };
  checkEmail(values.email, errors);
  if (values.name && !NAME_RE.test(values.name)) errors.name = 'Name can only contain letters, spaces, hyphens and apostrophes.';
  return { values, errors };
}

const STAFF_ROLES = ['reader', 'contributor', 'author', 'editor', 'admin'];

function validateNewUser(body) {
  const errors = {};
  const values = { name: str(body.name, 60), email: str(body.email, 254).toLowerCase(), role: str(body.role, 20) };
  const password = raw(body.password, 200);
  checkName(values.name, errors);
  checkEmail(values.email, errors);
  if (!STAFF_ROLES.includes(values.role)) errors.role = 'Please choose a role.';
  checkPassword(password, errors);
  return { values: { ...values, password }, errors };
}

function validateSettings(body) {
  const errors = {};
  const values = {
    site_title: str(body.site_title, 60),
    site_description: str(body.site_description, 200),
    accent_color: str(body.accent_color, 7).toLowerCase(),
    posts_per_page: Number(body.posts_per_page),
    comments_enabled: body.comments_enabled === 'on' ? '1' : '0',
    comment_moderation: str(body.comment_moderation, 10),
    registration_open: body.registration_open === 'on' ? '1' : '0',
    newsletter_enabled: body.newsletter_enabled === 'on' ? '1' : '0',
    footer_text: str(body.footer_text, 200)
  };
  if (values.site_title.length < 2) errors.site_title = 'Site title must be at least 2 characters.';
  // SECURITY: the accent colour is written into theme.css, so only a strict #rrggbb value is allowed.
  if (!HEX_RE.test(values.accent_color)) errors.accent_color = 'Accent colour must look like #ff1a75.';
  if (!Number.isInteger(values.posts_per_page) || values.posts_per_page < 3 || values.posts_per_page > 30) errors.posts_per_page = 'Posts per page must be between 3 and 30.';
  if (!['all', 'first', 'none'].includes(values.comment_moderation)) errors.comment_moderation = 'Choose a moderation option.';
  values.posts_per_page = String(values.posts_per_page);
  return { values, errors };
}

module.exports = {
  str,
  has,
  POST_STATUSES,
  STAFF_ROLES,
  HEX_RE,
  validateRegister,
  validateLogin,
  validateProfile,
  validatePasswordChange,
  validatePost,
  validateCategory,
  validateTag,
  validateComment,
  validateSubscribe,
  validateNewUser,
  validateSettings
};
