const crypto = require('crypto');

/** "Hello, Lagos!" -> "hello-lagos" */
function slugify(text) {
  return String(text)
    .toLowerCase()
    .normalize('NFKD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 80) || 'untitled';
}

/** SECURITY: cryptographically secure random token (hex), e.g. for unsubscribe links. */
function randomToken(bytes = 24) {
  return crypto.randomBytes(bytes).toString('hex');
}

/** Parse a positive integer from untrusted input, or null. */
function toPositiveInt(value) {
  const n = Number(value);
  return Number.isInteger(n) && n > 0 ? n : null;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
/** SQLite "2026-11-15 10:00:00" (UTC) -> "15 Nov 2026" */
function formatDate(sqlDate) {
  if (!sqlDate) return '';
  const d = new Date(sqlDate.replace(' ', 'T') + 'Z');
  if (Number.isNaN(d.getTime())) return '';
  return `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()]} ${d.getUTCFullYear()}`;
}

/** Current time in SQLite's UTC text format. */
function sqlNow() {
  return new Date().toISOString().slice(0, 19).replace('T', ' ');
}

/** Turn an HTML datetime-local value (treated as Lagos time, UTC+1) into SQLite UTC text. */
function lagosLocalToSql(value) {
  if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(value || '')) return null;
  const d = new Date(value + ':00+01:00');
  return Number.isNaN(d.getTime()) ? null : d.toISOString().slice(0, 19).replace('T', ' ');
}

/** SQLite UTC text -> value for an <input type="datetime-local"> in Lagos time. */
function sqlToLagosLocal(sqlDate) {
  if (!sqlDate) return '';
  const d = new Date(sqlDate.replace(' ', 'T') + 'Z');
  return new Date(d.getTime() + 60 * 60 * 1000).toISOString().slice(0, 16);
}

module.exports = { slugify, randomToken, toPositiveInt, formatDate, sqlNow, lagosLocalToSql, sqlToLagosLocal };
