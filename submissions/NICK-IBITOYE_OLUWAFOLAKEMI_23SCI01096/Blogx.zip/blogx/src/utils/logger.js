/**
 * Minimal logger: writes one JSON line per event to logs/app.log (and the console).
 *
 * SECURITY: sensitive fields are REDACTED before anything is written, so passwords,
 * CSRF tokens, session ids and card-like numbers never end up in log files.
 * Query strings are stripped from logged URLs for the same reason.
 */
const fs = require('fs');
const path = require('path');
const config = require('../config');

const SENSITIVE_KEYS = /pass(word)?|secret|token|csrf|cookie|session|authorization|card|cvv|pin/i;

function redact(value, depth = 0) {
  if (depth > 4 || value === null || typeof value !== 'object') {
    if (typeof value === 'string') return value.replace(/\b\d{12,19}\b/g, '[REDACTED-NUMBER]');
    return value;
  }
  const out = Array.isArray(value) ? [] : {};
  for (const [key, val] of Object.entries(value)) {
    out[key] = SENSITIVE_KEYS.test(key) ? '[REDACTED]' : redact(val, depth + 1);
  }
  return out;
}

let stream = null;
function getStream() {
  if (config.isTest) return null;
  if (!stream) {
    fs.mkdirSync(config.logDir, { recursive: true });
    stream = fs.createWriteStream(path.join(config.logDir, 'app.log'), { flags: 'a' });
  }
  return stream;
}

function write(level, message, meta = {}) {
  const entry = { time: new Date().toISOString(), level, message, ...redact(meta) };
  const line = JSON.stringify(entry);
  const s = getStream();
  if (s) s.write(line + '\n');
  if (!config.isTest) (level === 'error' ? console.error : console.log)(line);
}

module.exports = {
  info: (msg, meta) => write('info', msg, meta),
  warn: (msg, meta) => write('warn', msg, meta),
  error: (msg, meta) => write('error', msg, meta),
  redact
};
