/**
 * CSV export helper.
 * SECURITY (CSV / formula injection): a subscriber could sign up with a name like
 * =HYPERLINK("http://evil",...). When an admin opens the export in Excel, cells that start
 * with = + - @ (or tab/carriage return) are run as FORMULAS. We prefix such cells with an
 * apostrophe so spreadsheets show them as plain text.
 */
function cell(value) {
  let s = value === null || value === undefined ? '' : String(value);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return '"' + s.replace(/"/g, '""') + '"';
}

function toCsv(headers, rows) {
  const lines = [headers.map(cell).join(',')];
  for (const row of rows) lines.push(row.map(cell).join(','));
  return lines.join('\r\n') + '\r\n';
}

module.exports = { toCsv, cell };
