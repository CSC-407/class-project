/**
 * Visitor view tracking.
 * PRIVACY: only a daily counter per post is stored. No IP addresses, cookies-for-tracking or
 * personal data. Repeat views from the same browser session and obvious bots are not counted
 * (see middleware/views.js).
 */
const db = require('../db');

module.exports = {
  recordView(postId) {
    const day = new Date().toISOString().slice(0, 10);
    db.transaction(() => {
      db.prepare(`INSERT INTO post_views (post_id, day, views) VALUES (?, ?, 1)
                  ON CONFLICT(post_id, day) DO UPDATE SET views = views + 1`).run(postId, day);
      db.prepare('UPDATE posts SET view_count = view_count + 1 WHERE id = ?').run(postId);
    })();
  },

  /** Views per day for the last `days` days (zero-filled), optionally for one author's posts. */
  daily(days = 30, authorId = 0) {
    const rows = db.prepare(
      `SELECT v.day, SUM(v.views) AS views FROM post_views v JOIN posts p ON p.id = v.post_id
        WHERE v.day >= date('now', ?) AND (@a = 0 OR p.author_id = @a) GROUP BY v.day`
    ).all(`-${days - 1} days`, { a: authorId });
    const map = Object.fromEntries(rows.map((r) => [r.day, r.views]));
    const out = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      out.push({ day: d, views: map[d] || 0 });
    }
    return out;
  },

  topPosts(limit = 5, days = 30, authorId = 0) {
    return db.prepare(
      `SELECT p.id, p.title, p.slug, SUM(v.views) AS views FROM post_views v JOIN posts p ON p.id = v.post_id
        WHERE v.day >= date('now', ?) AND (@a = 0 OR p.author_id = @a) GROUP BY p.id ORDER BY views DESC LIMIT @limit`
    ).all(`-${days - 1} days`, { a: authorId, limit });
  },

  total(days = 30, authorId = 0) {
    return db.prepare(
      `SELECT COALESCE(SUM(v.views), 0) AS n FROM post_views v JOIN posts p ON p.id = v.post_id
        WHERE v.day >= date('now', ?) AND (@a = 0 OR p.author_id = @a)`
    ).get(`-${days - 1} days`, { a: authorId }).n;
  }
};
