/** Categories (with one level of sub-categories) and tags. */
const db = require('../db');
const { slugify } = require('../utils/helpers');

function uniqueSlug(table, name, exceptId = 0) {
  const base = slugify(name);
  let slug = base;
  for (let n = 2; db.prepare(`SELECT 1 FROM ${table} WHERE slug = ? AND id != ?`).get(slug, exceptId); n++) slug = `${base}-${n}`;
  return slug;
}

// Only published posts whose time has come are counted for the public site.
const LIVE = `p.status = 'published' AND p.published_at <= datetime('now')`;

const categories = {
  /** All categories with post counts, parents first then their children. */
  all() {
    const rows = db.prepare(
      `SELECT c.*, parent.name AS parent_name,
              (SELECT COUNT(*) FROM posts p WHERE p.category_id = c.id) AS post_count,
              (SELECT COUNT(*) FROM posts p WHERE p.category_id = c.id AND ${LIVE}) AS live_count
         FROM categories c LEFT JOIN categories parent ON parent.id = c.parent_id
        ORDER BY COALESCE(parent.name, c.name), c.parent_id IS NOT NULL, c.name`
    ).all();
    return rows;
  },

  /** Tree for navigation: [{...parent, children: [...] }] */
  tree() {
    const rows = this.all();
    const parents = rows.filter((c) => !c.parent_id).map((c) => ({ ...c, children: [] }));
    const byId = Object.fromEntries(parents.map((p) => [p.id, p]));
    for (const c of rows) if (c.parent_id && byId[c.parent_id]) byId[c.parent_id].children.push(c);
    return parents;
  },

  topLevel() {
    return db.prepare('SELECT * FROM categories WHERE parent_id IS NULL ORDER BY name').all();
  },

  findById(id) {
    return db.prepare('SELECT * FROM categories WHERE id = ?').get(id);
  },

  findBySlug(slug) {
    return db.prepare(
      `SELECT c.*, parent.name AS parent_name, parent.slug AS parent_slug
         FROM categories c LEFT JOIN categories parent ON parent.id = c.parent_id WHERE c.slug = ?`
    ).get(slug);
  },

  children(id) {
    return db.prepare('SELECT * FROM categories WHERE parent_id = ? ORDER BY name').all(id);
  },

  nameTaken(name, parentId, exceptId = 0) {
    return !!db.prepare('SELECT 1 FROM categories WHERE name = ? COLLATE NOCASE AND parent_id IS ? AND id != ?').get(name, parentId, exceptId);
  },

  create({ name, description, parentId }) {
    const info = db.prepare('INSERT INTO categories (name, slug, description, parent_id) VALUES (?, ?, ?, ?)')
      .run(name, uniqueSlug('categories', name), description || null, parentId);
    return this.findById(info.lastInsertRowid);
  },

  update(id, { name, description, parentId }) {
    db.prepare('UPDATE categories SET name = ?, slug = ?, description = ?, parent_id = ? WHERE id = ?')
      .run(name, uniqueSlug('categories', name, id), description || null, parentId, id);
  },

  /** Refuses (returns a reason) while sub-categories or posts still depend on the category. */
  remove(id) {
    if (db.prepare('SELECT 1 FROM categories WHERE parent_id = ?').get(id)) return 'it still has sub-categories';
    if (db.prepare('SELECT 1 FROM posts WHERE category_id = ?').get(id)) return 'posts still use it';
    db.prepare('DELETE FROM categories WHERE id = ?').run(id);
    return null;
  }
};

const tags = {
  all() {
    return db.prepare(
      `SELECT t.*, (SELECT COUNT(*) FROM post_tags pt WHERE pt.tag_id = t.id) AS post_count FROM tags t ORDER BY t.name COLLATE NOCASE`
    ).all();
  },

  /** Tags that have at least one live post (for the public tag cloud). */
  popular(limit = 12) {
    return db.prepare(
      `SELECT t.*, COUNT(*) AS post_count FROM tags t
         JOIN post_tags pt ON pt.tag_id = t.id JOIN posts p ON p.id = pt.post_id
        WHERE ${LIVE} GROUP BY t.id ORDER BY post_count DESC, t.name LIMIT ?`
    ).all(limit);
  },

  findById(id) {
    return db.prepare('SELECT * FROM tags WHERE id = ?').get(id);
  },

  findBySlug(slug) {
    return db.prepare('SELECT * FROM tags WHERE slug = ?').get(slug);
  },

  forPost(postId) {
    return db.prepare('SELECT t.* FROM tags t JOIN post_tags pt ON pt.tag_id = t.id WHERE pt.post_id = ? ORDER BY t.name').all(postId);
  },

  /** Find-or-create each tag name and link exactly these tags to the post. */
  setForPost(postId, names) {
    const find = db.prepare('SELECT id FROM tags WHERE name = ?');
    const insert = db.prepare('INSERT INTO tags (name, slug) VALUES (?, ?)');
    const link = db.prepare('INSERT OR IGNORE INTO post_tags (post_id, tag_id) VALUES (?, ?)');
    db.prepare('DELETE FROM post_tags WHERE post_id = ?').run(postId);
    const seen = new Set();
    for (const name of names) {
      const key = name.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      const row = find.get(name);
      const id = row ? row.id : insert.run(name, uniqueSlug('tags', name)).lastInsertRowid;
      link.run(postId, id);
    }
  },

  nameTaken(name, exceptId = 0) {
    return !!db.prepare('SELECT 1 FROM tags WHERE name = ? AND id != ?').get(name, exceptId);
  },

  create(name) {
    return db.prepare('INSERT INTO tags (name, slug) VALUES (?, ?)').run(name, uniqueSlug('tags', name)).lastInsertRowid;
  },

  rename(id, name) {
    db.prepare('UPDATE tags SET name = ?, slug = ? WHERE id = ?').run(name, uniqueSlug('tags', name, id), id);
  },

  remove(id) {
    db.prepare('DELETE FROM tags WHERE id = ?').run(id); // post_tags rows cascade
  }
};

module.exports = { categories, tags, LIVE };
