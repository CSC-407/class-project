/** Reader comments. Stored as PLAIN TEXT and escaped when displayed (no HTML allowed at all). */
const db = require('../db');

const SELECT = `SELECT cm.*, u.name AS user_name, u.role AS user_role, p.title AS post_title, p.slug AS post_slug
                  FROM comments cm JOIN users u ON u.id = cm.user_id JOIN posts p ON p.id = cm.post_id`;

module.exports = {
  /**
   * Decide the initial status from the moderation setting:
   *   all   → every comment waits for approval
   *   first → a reader's first comment waits; once one is approved, later ones go straight up
   *   none  → published immediately
   * Staff comments are always approved.
   */
  initialStatus(user, moderation) {
    if (user.role !== 'reader' || moderation === 'none') return 'approved';
    if (moderation === 'first') {
      const trusted = db.prepare(`SELECT 1 FROM comments WHERE user_id = ? AND status = 'approved'`).get(user.id);
      return trusted ? 'approved' : 'pending';
    }
    return 'pending';
  },
  create({ postId, userId, body, status }) {
    const info = db.prepare('INSERT INTO comments (post_id, user_id, body, status) VALUES (?, ?, ?, ?)').run(postId, userId, body, status);
    return this.findById(info.lastInsertRowid);
  },
  findById(id) {
    return db.prepare(`${SELECT} WHERE cm.id = ?`).get(id);
  },
  /** Approved comments for a post, plus the viewer's own pending ones (so they see "awaiting approval"). */
  forPost(postId, viewerId = 0) {
    return db.prepare(`${SELECT} WHERE cm.post_id = ? AND (cm.status = 'approved' OR (cm.user_id = ? AND cm.status = 'pending')) ORDER BY cm.id`).all(postId, viewerId);
  },
  forUser(userId) {
    return db.prepare(`${SELECT} WHERE cm.user_id = ? ORDER BY cm.id DESC`).all(userId);
  },
  list({ status = '', q = '', postId = 0 } = {}) {
    return db.prepare(
      `${SELECT} WHERE (@status = '' OR cm.status = @status) AND (@postId = 0 OR cm.post_id = @postId)
                   AND (@q = '' OR cm.body LIKE @like OR u.name LIKE @like OR p.title LIKE @like)
        ORDER BY cm.id DESC LIMIT 300`
    ).all({ status, q, like: `%${q}%`, postId });
  },
  setStatus(id, status) {
    db.prepare('UPDATE comments SET status = ? WHERE id = ?').run(status, id);
  },
  remove(id) {
    db.prepare('DELETE FROM comments WHERE id = ?').run(id);
  },
  counts() {
    return db.prepare(`SELECT SUM(status='pending') AS pending, SUM(status='approved') AS approved, SUM(status='spam') AS spam FROM comments`).get();
  },
  /** Simple flood control: how many comments has this user posted in the last N minutes? */
  recentCount(userId, minutes = 10) {
    return db.prepare(`SELECT COUNT(*) AS n FROM comments WHERE user_id = ? AND created_at > datetime('now', ?)`).get(userId, `-${minutes} minutes`).n;
  }
};
