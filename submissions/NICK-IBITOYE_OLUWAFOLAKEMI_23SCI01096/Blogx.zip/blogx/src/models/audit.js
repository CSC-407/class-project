/** Security audit trail: who did what, when, from which IP. Never stores passwords or tokens. */
const db = require('../db');

module.exports = {
  log(req, action, detail = '') {
    db.prepare('INSERT INTO audit_log (user_id, action, detail, ip) VALUES (?, ?, ?, ?)')
      .run((req.user && req.user.id) || (req.session && req.session.userId) || null, action, String(detail).slice(0, 300), req.ip || null);
  },
  recent(limit = 30) {
    return db.prepare(`SELECT a.*, u.name AS user_name FROM audit_log a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT ?`).all(limit);
  }
};
