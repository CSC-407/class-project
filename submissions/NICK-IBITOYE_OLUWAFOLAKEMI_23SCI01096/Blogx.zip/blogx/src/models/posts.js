/**
 * Posts.
 * SECURITY:
 *  - content is SANITIZED (allow-list) in save() before it is stored, so stored XSS is impossible
 *    even if someone bypasses the editor and posts raw HTML;
 *  - all queries use bound parameters; ORDER BY comes from a fixed allow-list (SORTS);
 *  - public queries only ever return posts that are published AND whose publish time has passed.
 */
const db = require('../db');
const { slugify, sqlNow } = require('../utils/helpers');
const { cleanPostHtml, htmlToText, readingMinutes, makeExcerpt } = require('../utils/sanitize');
const { tags, LIVE } = require('./taxonomy');

const SORTS = {
  newest: 'p.published_at DESC, p.id DESC',
  oldest: 'p.published_at ASC, p.id ASC',
  popular: 'p.view_count DESC, p.published_at DESC',
  updated: 'p.updated_at DESC, p.id DESC',
  title: 'p.title COLLATE NOCASE ASC'
};

const SELECT = `
  SELECT p.*, u.name AS author_name, u.slug AS author_slug, u.bio AS author_bio,
         c.name AS category_name, c.slug AS category_slug, pc.name AS parent_category_name, pc.slug AS parent_category_slug,
         CASE WHEN p.status = 'published' AND p.published_at > datetime('now') THEN 'scheduled' ELSE p.status END AS display_status,
         (SELECT COUNT(*) FROM comments cm WHERE cm.post_id = p.id AND cm.status = 'approved') AS comment_count
    FROM posts p
    JOIN users u ON u.id = p.author_id
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN categories pc ON pc.id = c.parent_id`;

function uniqueSlug(base, exceptId = 0) {
  const start = slugify(base);
  let slug = start;
  for (let n = 2; db.prepare('SELECT 1 FROM posts WHERE slug = ? AND id != ?').get(slug, exceptId); n++) slug = `${start}-${n}`;
  return slug;
}

function paginate(sqlWhere, params, sort, page, perPage) {
  const total = db.prepare(`SELECT COUNT(*) AS n FROM posts p LEFT JOIN categories c ON c.id = p.category_id ${sqlWhere}`).get(params).n;
  const pages = Math.max(1, Math.ceil(total / perPage));
  const current = Math.min(Math.max(1, page || 1), pages);
  const items = db.prepare(`${SELECT} ${sqlWhere} ORDER BY ${SORTS[sort] || SORTS.newest} LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit: perPage, offset: (current - 1) * perPage });
  return { items, total, page: current, pages };
}

module.exports = {
  SORTS,

  /** PUBLIC listing: search + filters. Only live posts. A category includes its sub-categories. */
  searchPublic({ q = '', category = null, tag = null, author = null, sort = 'newest', page = 1, perPage = 9, excludeId = 0 } = {}) {
    const params = {
      q, like: `%${q}%`, excludeId,
      categoryId: category ? category.id : 0,
      tagId: tag ? tag.id : 0,
      authorId: author ? author.id : 0
    };
    const where = `
      WHERE ${LIVE}
        AND p.id != @excludeId
        AND (@q = '' OR p.title LIKE @like OR p.excerpt LIKE @like OR p.content_text LIKE @like)
        AND (@categoryId = 0 OR p.category_id = @categoryId OR c.parent_id = @categoryId)
        AND (@tagId = 0 OR EXISTS (SELECT 1 FROM post_tags pt WHERE pt.post_id = p.id AND pt.tag_id = @tagId))
        AND (@authorId = 0 OR p.author_id = @authorId)`;
    return paginate(where, params, Object.keys(SORTS).includes(sort) && sort !== 'title' && sort !== 'updated' ? sort : 'newest', page, perPage);
  },

  /** ADMIN listing. `onlyAuthorId` restricts contributors/authors to their own posts. */
  searchAdmin({ q = '', status = '', categoryId = 0, tagId = 0, authorId = 0, onlyAuthorId = 0, sort = 'updated', page = 1, perPage = 20 } = {}) {
    const params = { q, like: `%${q}%`, status, categoryId, tagId, authorId, onlyAuthorId };
    const where = `
      WHERE (@onlyAuthorId = 0 OR p.author_id = @onlyAuthorId)
        AND (@q = '' OR p.title LIKE @like OR p.content_text LIKE @like)
        AND (@status = ''
             OR (@status = 'scheduled' AND p.status = 'published' AND p.published_at > datetime('now'))
             OR (@status = 'published' AND p.status = 'published' AND p.published_at <= datetime('now'))
             OR (@status NOT IN ('scheduled', 'published') AND p.status = @status))
        AND (@categoryId = 0 OR p.category_id = @categoryId OR c.parent_id = @categoryId)
        AND (@tagId = 0 OR EXISTS (SELECT 1 FROM post_tags pt WHERE pt.post_id = p.id AND pt.tag_id = @tagId))
        AND (@authorId = 0 OR p.author_id = @authorId)`;
    return paginate(where, params, SORTS[sort] ? sort : 'updated', page, perPage);
  },

  featured(limit = 1) {
    return db.prepare(`${SELECT} WHERE ${LIVE} AND p.featured = 1 ORDER BY p.published_at DESC LIMIT ?`).all(limit);
  },

  findById(id) {
    return db.prepare(`${SELECT} WHERE p.id = ?`).get(id);
  },

  findBySlug(slug) {
    return db.prepare(`${SELECT} WHERE p.slug = ?`).get(slug);
  },

  /** A post the public may see right now. */
  isLive(post) {
    return !!post && post.status === 'published' && post.display_status === 'published';
  },

  related(post, limit = 3) {
    return db.prepare(
      `${SELECT} WHERE ${LIVE} AND p.id != @id AND (p.category_id = @cat OR EXISTS (
          SELECT 1 FROM post_tags a JOIN post_tags b ON a.tag_id = b.tag_id WHERE a.post_id = p.id AND b.post_id = @id))
        ORDER BY p.published_at DESC LIMIT @limit`
    ).all({ id: post.id, cat: post.category_id || 0, limit });
  },

  /**
   * Create or update a post. `values` comes from validators.validatePost; the route has already
   * decided the final status/publish time based on the user's permissions.
   */
  save({ id = null, authorId, values, status, publishedAt }) {
    const contentHtml = cleanPostHtml(values.contentHtml); // ← XSS defence: allow-list sanitizing
    const contentText = htmlToText(contentHtml);
    const row = {
      title: values.title,
      slug: uniqueSlug(values.slug || values.title, id || 0),
      excerpt: values.excerpt || makeExcerpt(contentText),
      contentHtml,
      contentText,
      featureImage: values.featureImage || null,
      status,
      featured: values.featured ? 1 : 0,
      allowComments: values.allowComments ? 1 : 0,
      categoryId: values.categoryId,
      metaTitle: values.metaTitle || null,
      metaDescription: values.metaDescription || null,
      canonicalUrl: values.canonicalUrl || null,
      noindex: values.noindex ? 1 : 0,
      readingMinutes: readingMinutes(contentText),
      publishedAt
    };
    return db.transaction(() => {
      let postId = id;
      if (id) {
        db.prepare(
          `UPDATE posts SET title=@title, slug=@slug, excerpt=@excerpt, content_html=@contentHtml, content_text=@contentText,
                  feature_image=@featureImage, status=@status, featured=@featured, allow_comments=@allowComments,
                  category_id=@categoryId, meta_title=@metaTitle, meta_description=@metaDescription,
                  canonical_url=@canonicalUrl, noindex=@noindex, reading_minutes=@readingMinutes,
                  published_at=@publishedAt, updated_at=datetime('now')
            WHERE id=@id`
        ).run({ ...row, id });
      } else {
        postId = db.prepare(
          `INSERT INTO posts (title, slug, excerpt, content_html, content_text, feature_image, status, featured, allow_comments,
                              author_id, category_id, meta_title, meta_description, canonical_url, noindex, reading_minutes, published_at)
           VALUES (@title, @slug, @excerpt, @contentHtml, @contentText, @featureImage, @status, @featured, @allowComments,
                   @authorId, @categoryId, @metaTitle, @metaDescription, @canonicalUrl, @noindex, @readingMinutes, @publishedAt)`
        ).run({ ...row, authorId }).lastInsertRowid;
      }
      tags.setForPost(postId, values.tags);
      return this.findById(postId);
    })();
  },

  setStatus(id, status) {
    const post = this.findById(id);
    const publishedAt = status === 'published' ? post.published_at || sqlNow() : post.published_at;
    db.prepare(`UPDATE posts SET status = ?, published_at = ?, updated_at = datetime('now') WHERE id = ?`).run(status, publishedAt, id);
  },

  remove(id) {
    db.prepare('DELETE FROM posts WHERE id = ?').run(id);
  },

  /** Count of posts per status (optionally just one author's). */
  statusCounts(onlyAuthorId = 0) {
    const row = db.prepare(
      `SELECT SUM(status = 'draft') AS draft, SUM(status = 'review') AS review,
              SUM(status = 'published' AND published_at <= datetime('now')) AS published,
              SUM(status = 'published' AND published_at > datetime('now')) AS scheduled,
              SUM(status = 'archived') AS archived, COUNT(*) AS total
         FROM posts WHERE (@a = 0 OR author_id = @a)`
    ).get({ a: onlyAuthorId });
    for (const k of Object.keys(row)) row[k] = row[k] || 0;
    return row;
  },

  /** For sitemap.xml and the RSS feed. */
  liveForFeeds(limit = 500) {
    return db.prepare(`${SELECT} WHERE ${LIVE} AND p.noindex = 0 ORDER BY p.published_at DESC LIMIT ?`).all(limit);
  }
};
