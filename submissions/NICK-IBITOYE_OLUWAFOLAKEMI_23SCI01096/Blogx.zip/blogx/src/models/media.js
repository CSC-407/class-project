/** Media library (uploaded images). Files live in public/uploads under random names. */
const db = require('../db');

module.exports = {
  create({ path, originalName, mime, size, alt, uploadedBy }) {
    const info = db.prepare('INSERT INTO media (path, original_name, mime, size, alt, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)')
      .run(path, originalName, mime, size, alt || null, uploadedBy);
    return this.findById(info.lastInsertRowid);
  },
  findById(id) {
    return db.prepare('SELECT m.*, u.name AS uploader FROM media m LEFT JOIN users u ON u.id = m.uploaded_by WHERE m.id = ?').get(id);
  },
  findByPath(path) {
    return db.prepare('SELECT * FROM media WHERE path = ?').get(path);
  },
  /** onlyUserId: contributors/authors see their own uploads only. */
  list({ q = '', onlyUserId = 0 } = {}) {
    return db.prepare(
      `SELECT m.*, u.name AS uploader FROM media m LEFT JOIN users u ON u.id = m.uploaded_by
        WHERE (@u = 0 OR m.uploaded_by = @u) AND (@q = '' OR m.original_name LIKE @like OR m.alt LIKE @like)
        ORDER BY m.id DESC LIMIT 200`
    ).all({ u: onlyUserId, q, like: `%${q}%` });
  },
  updateAlt(id, alt) {
    db.prepare('UPDATE media SET alt = ? WHERE id = ?').run(alt || null, id);
  },
  /** Is this image still used as a feature image or inside a post? */
  usage(path) {
    return db.prepare('SELECT COUNT(*) AS n FROM posts WHERE feature_image = ? OR instr(content_html, ?) > 0').get(path, path).n;
  },
  remove(id) {
    db.prepare('DELETE FROM media WHERE id = ?').run(id);
  }
};
