/** Site-wide settings, stored as key/value rows. Values are validated in validators.validateSettings. */
const db = require('../db');

const DEFAULTS = {
  site_title: 'Blog.x',
  site_description: 'Stories, ideas and notes from Lagos and beyond.',
  accent_color: '#ff1a75',
  posts_per_page: '9',
  comments_enabled: '1',
  comment_moderation: 'first', // all = hold every comment | first = hold a reader's first comment | none = publish at once
  registration_open: '1',
  newsletter_enabled: '1',
  footer_text: 'Blog.x is a university project on web application security.'
};

let cache = null;

function all() {
  if (!cache) {
    cache = { ...DEFAULTS };
    for (const row of db.prepare('SELECT key, value FROM settings').all()) cache[row.key] = row.value;
  }
  return cache;
}

function save(values) {
  const upsert = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  db.transaction(() => {
    for (const [k, v] of Object.entries(values)) if (k in DEFAULTS) upsert.run(k, String(v));
  })();
  cache = null;
}

module.exports = { DEFAULTS, all, save, get: (k) => all()[k], flag: (k) => all()[k] === '1', clearCache: () => { cache = null; } };
