/** Newsletter subscribers. Each has a random unsubscribe token for one-click unsubscribe links. */
const db = require('../db');
const { randomToken } = require('../utils/helpers');

module.exports = {
  /** Subscribe (or re-subscribe). Returns { subscriber, created }. */
  subscribe({ email, name, userId = null }) {
    const existing = db.prepare('SELECT * FROM subscribers WHERE email = ?').get(email);
    if (existing) {
      db.prepare(`UPDATE subscribers SET status = 'subscribed', name = COALESCE(?, name), user_id = COALESCE(?, user_id), updated_at = datetime('now') WHERE id = ?`)
        .run(name || null, userId, existing.id);
      return { subscriber: this.findById(existing.id), created: false };
    }
    const info = db.prepare('INSERT INTO subscribers (email, name, unsubscribe_token, user_id) VALUES (?, ?, ?, ?)')
      .run(email, name || null, randomToken(24), userId);
    return { subscriber: this.findById(info.lastInsertRowid), created: true };
  },
  findById(id) {
    return db.prepare('SELECT * FROM subscribers WHERE id = ?').get(id);
  },
  findByEmail(email) {
    return db.prepare('SELECT * FROM subscribers WHERE email = ?').get(email);
  },
  findByToken(token) {
    if (!/^[a-f0-9]{48}$/.test(token || '')) return null;
    return db.prepare('SELECT * FROM subscribers WHERE unsubscribe_token = ?').get(token);
  },
  setStatus(id, status) {
    db.prepare(`UPDATE subscribers SET status = ?, updated_at = datetime('now') WHERE id = ?`).run(status, id);
  },
  list({ q = '', status = '' } = {}) {
    return db.prepare(
      `SELECT * FROM subscribers WHERE (@status = '' OR status = @status) AND (@q = '' OR email LIKE @like OR name LIKE @like)
        ORDER BY id DESC`
    ).all({ q, like: `%${q}%`, status });
  },
  remove(id) {
    db.prepare('DELETE FROM subscribers WHERE id = ?').run(id);
  },
  counts() {
    return db.prepare(`SELECT SUM(status='subscribed') AS subscribed, SUM(status='unsubscribed') AS unsubscribed FROM subscribers`).get();
  }
};
