/** User accounts. SECURITY: all SQL uses bound parameters; password hashes never leave this file except for login checks. */
const bcrypt = require('bcryptjs');
const db = require('../db');
const config = require('../config');
const { slugify } = require('../utils/helpers');

// Columns safe to load into a request or show on a page (never password_hash).
const SAFE = 'id, name, email, slug, role, bio, website, status, must_change_password, created_at';

/** SECURITY: bcrypt = salted + deliberately slow, so a stolen database does not reveal passwords. */
const hash = (plain) => bcrypt.hashSync(plain, config.bcryptRounds);
const verify = (plain, h) => bcrypt.compareSync(plain, h);
// Checked when the email doesn't exist, so "no such user" takes as long as "wrong password".
const DUMMY_HASH = hash('timing-equaliser-not-a-password');

function uniqueSlug(name, exceptId = 0) {
  const base = slugify(name);
  let slug = base;
  for (let n = 2; db.prepare('SELECT 1 FROM users WHERE slug = ? AND id != ?').get(slug, exceptId); n++) slug = `${base}-${n}`;
  return slug;
}

module.exports = {
  hash,
  verify,
  DUMMY_HASH,

  create({ name, email, password, role = 'reader', bio = null, mustChangePassword = false }) {
    const info = db.prepare(
      `INSERT INTO users (name, email, slug, password_hash, role, bio, must_change_password) VALUES (?, ?, ?, ?, ?, ?, ?)`
    ).run(name, email, uniqueSlug(name), hash(password), role, bio, mustChangePassword ? 1 : 0);
    return this.findById(info.lastInsertRowid);
  },

  findById(id) {
    return db.prepare(`SELECT ${SAFE} FROM users WHERE id = ?`).get(id);
  },

  findBySlug(slug) {
    return db.prepare(`SELECT ${SAFE} FROM users WHERE slug = ? AND role != 'reader'`).get(slug);
  },

  findForLogin(email) {
    return db.prepare('SELECT id, name, role, status, password_hash, failed_logins, locked_until FROM users WHERE email = ?').get(email);
  },

  passwordHash(id) {
    const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(id);
    return row ? row.password_hash : DUMMY_HASH;
  },

  emailTaken(email, exceptId = 0) {
    return !!db.prepare('SELECT 1 FROM users WHERE email = ? AND id != ?').get(email, exceptId);
  },

  /** Count a failed login; lock the account for LOCKOUT_MINUTES after LOGIN_MAX_ATTEMPTS. */
  recordFailedLogin(id) {
    const attempts = db.prepare('SELECT failed_logins FROM users WHERE id = ?').get(id).failed_logins + 1;
    const lockedUntil = attempts >= config.loginMaxAttempts ? Date.now() + config.lockoutMinutes * 60000 : null;
    db.prepare('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?').run(lockedUntil ? 0 : attempts, lockedUntil, id);
    return lockedUntil;
  },

  clearFailedLogins(id) {
    db.prepare('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = ?').run(id);
  },

  updateProfile(id, { name, email, bio, website }) {
    db.prepare(`UPDATE users SET name = ?, email = ?, bio = ?, website = ?, slug = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(name, email, bio || null, website || null, uniqueSlug(name, id), id);
  },

  setPassword(id, plain, { mustChange = false } = {}) {
    db.prepare(`UPDATE users SET password_hash = ?, must_change_password = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(hash(plain), mustChange ? 1 : 0, id);
  },

  setRole(id, role) {
    db.prepare(`UPDATE users SET role = ?, updated_at = datetime('now') WHERE id = ?`).run(role, id);
  },

  setStatus(id, status) {
    db.prepare(`UPDATE users SET status = ?, updated_at = datetime('now') WHERE id = ?`).run(status, id);
  },

  /**
   * Delete a user. Their posts are handed to `transferTo` (posts must always have an author),
   * their comments are deleted with them, and newsletter rows are kept but unlinked.
   */
  remove(id, transferTo) {
    db.transaction(() => {
      if (transferTo) db.prepare('UPDATE posts SET author_id = ? WHERE author_id = ?').run(transferTo, id);
      db.prepare('UPDATE media SET uploaded_by = ? WHERE uploaded_by = ?').run(transferTo || null, id);
      db.prepare('DELETE FROM users WHERE id = ?').run(id);
    })();
  },

  list({ q = '', role = '' } = {}) {
    return db.prepare(
      `SELECT ${SAFE},
              (SELECT COUNT(*) FROM posts p WHERE p.author_id = users.id) AS post_count,
              (SELECT COUNT(*) FROM comments c WHERE c.user_id = users.id) AS comment_count
         FROM users
        WHERE (@q = '' OR name LIKE @like OR email LIKE @like)
          AND (@role = '' OR role = @role)
        ORDER BY CASE role WHEN 'admin' THEN 0 WHEN 'editor' THEN 1 WHEN 'author' THEN 2 WHEN 'contributor' THEN 3 ELSE 4 END, name`
    ).all({ q, like: `%${q}%`, role });
  },

  staff() {
    return db.prepare(`SELECT ${SAFE} FROM users WHERE role != 'reader' AND status = 'active' ORDER BY name`).all();
  },

  activeAdminCount() {
    return db.prepare(`SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND status = 'active'`).get().n;
  },

  count() {
    return db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  }
};
