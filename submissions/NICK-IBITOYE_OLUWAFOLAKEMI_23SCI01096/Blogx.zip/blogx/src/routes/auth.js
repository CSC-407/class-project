/** Sign up, sign in, sign out. */
const express = require('express');
const Users = require('../models/users');
const Subscribers = require('../models/subscribers');
const Settings = require('../models/settings');
const Audit = require('../models/audit');
const config = require('../config');
const logger = require('../utils/logger');
const { validateRegister, validateLogin, has } = require('../utils/validators');
const { requireGuest, safeNext } = require('../middleware/auth');
const { loginLimiter, formLimiter } = require('../middleware/security');
const { ensureToken } = require('../middleware/csrf');
const { can } = require('../permissions');

/**
 * SECURITY (session fixation): throw away the pre-login session id and issue a new one.
 * A session id planted in the victim's browser before login becomes worthless.
 */
function startSession(req, user, done) {
  const viewed = req.session.viewed;
  req.session.regenerate((err) => {
    if (err) return done(err);
    req.session.userId = user.id;
    req.session.viewed = viewed;
    ensureToken(req); // fresh CSRF token for the fresh session
    req.session.save(done);
  });
}

function registrationClosed(res) {
  return res.status(403).render('error', { title: 'Sign-ups are closed', status: 403, message: 'New account registration is currently turned off by the site administrator.' });
}

module.exports = function authRoutes(options = {}) {
  const router = express.Router();
  const limiter = loginLimiter(options.loginRateLimit);

  // ---------- SIGN UP (always creates a READER; staff roles are only given by an admin) ----------
  router.get('/signup', requireGuest, (req, res) => {
    if (!Settings.flag('registration_open')) return registrationClosed(res);
    res.render('auth/signup', { title: 'Sign up', values: { newsletter: true } });
  });

  router.post('/signup', requireGuest, formLimiter(20), (req, res, next) => {
    if (!Settings.flag('registration_open')) return registrationClosed(res);
    const { values, errors } = validateRegister(req.body);
    if (!errors.email && Users.emailTaken(values.email)) errors.email = 'An account with this email already exists. Try signing in.';
    if (has(errors)) {
      delete values.password; // never echo a password back
      return res.status(400).render('auth/signup', { title: 'Sign up', values, errors });
    }
    const user = Users.create({ name: values.name, email: values.email, password: values.password, role: 'reader' });
    if (values.newsletter && Settings.flag('newsletter_enabled')) Subscribers.subscribe({ email: user.email, name: user.name, userId: user.id });
    Audit.log(req, 'signup', `user ${user.id}`);
    startSession(req, user, (err) => {
      if (err) return next(err);
      req.session.flash = { type: 'success', message: `Welcome to ${Settings.get('site_title')}, ${user.name.split(' ')[0]}!` };
      res.redirect('/');
    });
  });

  // ---------- SIGN IN ----------
  router.get('/signin', requireGuest, (req, res) => {
    res.render('auth/signin', {
      title: 'Sign in',
      next: safeNext(req.query.next),
      flash: req.query.signedout === '1' ? { type: 'success', message: 'You have been signed out.' } : res.locals.flash
    });
  });

  router.post('/signin', requireGuest, limiter, (req, res, next) => {
    const { values, errors } = validateLogin(req.body);
    const nextUrl = safeNext(req.body.next);
    const fail = (message, status = 401) => res.status(status).render('auth/signin', {
      title: 'Sign in', values: { email: values.email }, errors, next: nextUrl, flash: { type: 'error', message }
    });
    // Same message for "unknown email" and "wrong password": attackers can't discover who has an account.
    const GENERIC = 'Incorrect email or password.';
    const LOCKED = `Too many failed attempts. For your security this account is locked for ${config.lockoutMinutes} minutes.`;

    if (has(errors)) return fail('Please enter your email and password.', 400);
    const user = Users.findForLogin(values.email);
    if (!user) {
      Users.verify(values.password, Users.DUMMY_HASH); // same timing as a real check
      Audit.log(req, 'signin_failed', 'unknown email');
      logger.warn('Failed sign-in', { reason: 'unknown email', ip: req.ip });
      return fail(GENERIC);
    }
    if (user.locked_until && user.locked_until > Date.now()) {
      Users.verify(values.password, Users.DUMMY_HASH);
      Audit.log(req, 'signin_blocked', `user ${user.id} locked`);
      return fail(LOCKED, 423);
    }
    if (!Users.verify(values.password, user.password_hash)) {
      const locked = Users.recordFailedLogin(user.id);
      Audit.log(req, 'signin_failed', `user ${user.id}`);
      logger.warn('Failed sign-in', { userId: user.id, ip: req.ip });
      return locked ? fail(LOCKED, 423) : fail(GENERIC);
    }
    if (user.status !== 'active') {
      Audit.log(req, 'signin_blocked', `user ${user.id} suspended`);
      return fail('This account has been suspended. Please contact the site administrator.', 403);
    }
    Users.clearFailedLogins(user.id);
    startSession(req, user, (err) => {
      if (err) return next(err);
      Audit.log(req, 'signin', `user ${user.id}`);
      req.session.flash = { type: 'success', message: `Welcome back, ${user.name.split(' ')[0]}.` };
      res.redirect(nextUrl || (can({ ...user, status: 'active' }, 'admin.access') ? '/admin' : '/'));
    });
  });

  // ---------- SIGN OUT: POST + CSRF token, destroys the server-side session and the cookie ----------
  router.post('/signout', (req, res, next) => {
    if (req.session.userId) Audit.log(req, 'signout', `user ${req.session.userId}`);
    req.session.destroy((err) => {
      if (err) return next(err);
      res.clearCookie('bx.sid', { httpOnly: true, sameSite: 'lax', secure: config.isProd });
      res.redirect('/signin?signedout=1');
    });
  });

  return router;
};
