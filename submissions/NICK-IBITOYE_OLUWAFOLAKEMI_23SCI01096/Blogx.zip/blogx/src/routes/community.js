/** Comments and newsletter: the reader-facing interactions. */
const express = require('express');
const Posts = require('../models/posts');
const Comments = require('../models/comments');
const Subscribers = require('../models/subscribers');
const Settings = require('../models/settings');
const Audit = require('../models/audit');
const { requireLogin } = require('../middleware/auth');
const { formLimiter } = require('../middleware/security');
const { canDeleteComment } = require('../permissions');
const { validateComment, validateSubscribe, str, has } = require('../utils/validators');
const { toPositiveInt } = require('../utils/helpers');

const router = express.Router();

// ---------- POST A COMMENT (signed-in users only) ----------
router.post('/posts/:slug/comments', requireLogin, formLimiter(30), (req, res, next) => {
  const post = Posts.findBySlug(str(req.params.slug, 100));
  if (!post || !Posts.isLive(post)) return next();
  const back = `/posts/${post.slug}#comments`;
  if (!Settings.flag('comments_enabled') || !post.allow_comments) {
    req.session.flash = { type: 'error', message: 'Comments are closed on this post.' };
    return res.redirect(back);
  }
  // Honeypot: a hidden field humans never fill in. Bots that fill every field are silently ignored.
  if (str(req.body.website, 100)) return res.redirect(back);
  const { values, errors } = validateComment(req.body);
  if (has(errors)) {
    req.session.flash = { type: 'error', message: errors.body };
    return res.redirect(back);
  }
  // Flood control: max 5 comments per 10 minutes per account.
  if (Comments.recentCount(req.user.id, 10) >= 5) {
    req.session.flash = { type: 'error', message: 'You are commenting too quickly. Please wait a few minutes.' };
    return res.redirect(back);
  }
  const status = Comments.initialStatus(req.user, Settings.get('comment_moderation'));
  Comments.create({ postId: post.id, userId: req.user.id, body: values.body, status });
  Audit.log(req, 'comment_created', `post ${post.id} (${status})`);
  req.session.flash = status === 'approved'
    ? { type: 'success', message: 'Your comment has been posted.' }
    : { type: 'info', message: 'Thanks! Your comment will appear once a moderator approves it.' };
  res.redirect(back);
});

// ---------- DELETE A COMMENT (own comment, or any for moderators) ----------
router.post('/comments/:id/delete', requireLogin, (req, res, next) => {
  const comment = Comments.findById(toPositiveInt(req.params.id));
  if (!comment) return next();
  if (!canDeleteComment(req.user, comment)) {
    const err = new Error('Forbidden'); err.status = 403; err.publicMessage = 'You can only delete your own comments.';
    return next(err);
  }
  Comments.remove(comment.id);
  Audit.log(req, 'comment_deleted', `comment ${comment.id}`);
  req.session.flash = { type: 'success', message: 'Comment deleted.' };
  res.redirect(`/posts/${comment.post_slug}#comments`);
});

// ---------- NEWSLETTER ----------
router.post('/subscribe', formLimiter(10), (req, res) => {
  const back = /^\/(posts\/[a-z0-9-]+)?$/.test(str(req.body.returnTo, 120)) ? str(req.body.returnTo, 120) : '/';
  if (!Settings.flag('newsletter_enabled')) {
    req.session.flash = { type: 'error', message: 'The newsletter is not accepting sign-ups right now.' };
    return res.redirect(back);
  }
  if (str(req.body.website, 100)) return res.redirect(back); // honeypot
  const { values, errors } = validateSubscribe(req.body);
  if (has(errors)) {
    req.session.flash = { type: 'error', message: errors.email || errors.name };
    return res.redirect(back);
  }
  Subscribers.subscribe({ email: values.email, name: values.name, userId: req.user && req.user.email === values.email ? req.user.id : null });
  // Same message whether or not the email was already on the list (doesn't reveal who subscribes).
  req.session.flash = { type: 'success', message: `You're subscribed! Look out for new posts from ${Settings.get('site_title')}.` };
  res.redirect(back);
});

// One-click unsubscribe. The long random token in the link is the proof of ownership.
// GET only shows a confirmation; the change itself is a POST (GET requests should never change data).
router.get('/unsubscribe/:token', (req, res, next) => {
  const sub = Subscribers.findByToken(req.params.token);
  if (!sub) return next();
  res.render('site/unsubscribe', { title: 'Unsubscribe', sub, done: false, meta: { noindex: true } });
});

router.post('/unsubscribe/:token', (req, res, next) => {
  const sub = Subscribers.findByToken(req.params.token);
  if (!sub) return next();
  Subscribers.setStatus(sub.id, 'unsubscribed');
  res.render('site/unsubscribe', { title: 'Unsubscribed', sub, done: true, meta: { noindex: true } });
});

module.exports = router;
