/** Public site: home, posts, categories, tags, authors, search, RSS, sitemap, security page. */
const express = require('express');
const Posts = require('../models/posts');
const Users = require('../models/users');
const Comments = require('../models/comments');
const Subscribers = require('../models/subscribers');
const Settings = require('../models/settings');
const { categories, tags } = require('../models/taxonomy');
const { canEditPost, can } = require('../permissions');
const { trackView } = require('../middleware/views');
const { str } = require('../utils/validators');
const { toPositiveInt } = require('../utils/helpers');
const config = require('../config');
const { cleanPostHtml } = require('../utils/sanitize');

const router = express.Router();
const perPage = () => Number(Settings.get('posts_per_page')) || 9;

/** Build a link to another results page, keeping the current filters. */
function pager(basePath, params) {
  return (page) => {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) qs.set(k, v);
    if (page > 1) qs.set('page', page);
    const s = qs.toString();
    return basePath + (s ? '?' + s : '');
  };
}

// ---------- HOME (content changes for guests, readers and staff — see views/site/home.ejs) ----------
router.get('/', (req, res) => {
  const page = toPositiveInt(req.query.page) || 1;
  const hero = page === 1 ? Posts.featured(1)[0] || null : null;
  const result = Posts.searchPublic({ page, perPage: perPage(), excludeId: hero ? hero.id : 0 });
  const extra = {};
  if (req.user) {
    extra.subscribed = (Subscribers.findByEmail(req.user.email) || {}).status === 'subscribed';
    if (can(req.user, 'admin.access')) extra.myCounts = Posts.statusCounts(can(req.user, 'post.editAny') ? 0 : req.user.id);
  }
  res.render('site/home', {
    title: null,
    hero,
    result,
    pageLink: pager('/', {}),
    popularTags: tags.popular(10),
    ...extra
  });
});

// ---------- SINGLE POST ----------
router.get('/posts/:slug', (req, res, next) => {
  const post = Posts.findBySlug(str(req.params.slug, 100));
  if (!post) return next();
  const live = Posts.isLive(post);
  // Unpublished posts are only visible as a preview to staff allowed to edit them; everyone else gets 404.
  if (!live && !canEditPost(req.user, post)) return next();
  if (live) trackView(req, post);
  // Defence in depth: content was sanitized when saved; clean it again on the way out in case the
  // database was ever changed by something other than the app.
  post.content_html = cleanPostHtml(post.content_html);

  const site = Settings.all();
  const commentsOpen = live && site.comments_enabled === '1' && !!post.allow_comments;
  res.render('site/post', {
    title: post.meta_title || post.title,
    post,
    preview: !live,
    postTags: tags.forPost(post.id),
    related: live ? Posts.related(post, 3) : [],
    comments: Comments.forPost(post.id, req.user ? req.user.id : 0),
    commentsOpen,
    canModerate: can(req.user, 'comments.moderate'),
    meta: {
      description: post.meta_description || post.excerpt,
      canonical: post.canonical_url || `${config.siteUrl}/posts/${post.slug}`,
      noindex: !!post.noindex || !live,
      image: post.feature_image ? config.siteUrl + post.feature_image : null,
      type: 'article'
    }
  });
});

// ---------- ARCHIVES ----------
function archive(kind) {
  return (req, res, next) => {
    const slug = str(req.params.slug, 100);
    const page = toPositiveInt(req.query.page) || 1;
    const sort = ['newest', 'oldest', 'popular'].includes(req.query.sort) ? req.query.sort : 'newest';
    let subject;
    let filter;
    if (kind === 'category') { subject = categories.findBySlug(slug); filter = { category: subject }; }
    if (kind === 'tag') { subject = tags.findBySlug(slug); filter = { tag: subject }; }
    if (kind === 'author') { subject = Users.findBySlug(slug); filter = { author: subject }; }
    if (!subject) return next();
    const result = Posts.searchPublic({ ...filter, sort, page, perPage: perPage() });
    res.render('site/archive', {
      title: subject.name,
      kind,
      subject,
      subcategories: kind === 'category' ? categories.children(subject.id) : [],
      result,
      sort,
      pageLink: pager(`/${kind}/${subject.slug}`, { sort: sort === 'newest' ? '' : sort }),
      meta: { description: subject.description || subject.bio || '' }
    });
  };
}
router.get('/category/:slug', archive('category'));
router.get('/tag/:slug', archive('tag'));
router.get('/author/:slug', archive('author'));

// ---------- SEARCH & FILTER ----------
router.get('/search', (req, res) => {
  const q = str(req.query.q, 80);
  const category = categories.findBySlug(str(req.query.category, 80)) || null;
  const tag = tags.findBySlug(str(req.query.tag, 80)) || null;
  const sort = ['newest', 'oldest', 'popular'].includes(req.query.sort) ? req.query.sort : 'newest';
  const page = toPositiveInt(req.query.page) || 1;
  const searched = !!(q || category || tag);
  const result = searched ? Posts.searchPublic({ q, category, tag, sort, page, perPage: perPage() }) : { items: [], total: 0, page: 1, pages: 1 };
  res.render('site/search', {
    title: q ? `Search: ${q}` : 'Search',
    q,
    category,
    tag,
    sort,
    searched,
    result,
    allCategories: categories.all(),
    allTags: tags.popular(50),
    pageLink: pager('/search', { q, category: category && category.slug, tag: tag && tag.slug, sort: sort === 'newest' ? '' : sort }),
    meta: { noindex: true }
  });
});

// ---------- FEEDS (SEO) ----------
const xml = (s) => String(s || '').replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]));
const iso = (d) => new Date(String(d).replace(' ', 'T') + 'Z');

router.get('/rss.xml', (req, res) => {
  const site = Settings.all();
  const items = Posts.liveForFeeds(20).map((p) => `
    <item>
      <title>${xml(p.title)}</title>
      <link>${config.siteUrl}/posts/${p.slug}</link>
      <guid isPermaLink="true">${config.siteUrl}/posts/${p.slug}</guid>
      <pubDate>${iso(p.published_at).toUTCString()}</pubDate>
      <dc:creator>${xml(p.author_name)}</dc:creator>
      <description>${xml(p.excerpt)}</description>
    </item>`).join('');
  res.type('application/rss+xml').send(`<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:dc="http://purl.org/dc/elements/1.1/">
  <channel>
    <title>${xml(site.site_title)}</title>
    <link>${config.siteUrl}/</link>
    <description>${xml(site.site_description)}</description>${items}
  </channel>
</rss>
`);
});

router.get('/sitemap.xml', (req, res) => {
  const urls = [`${config.siteUrl}/`, ...Posts.liveForFeeds().map((p) => `${config.siteUrl}/posts/${p.slug}`),
    ...categories.all().filter((c) => c.live_count > 0).map((c) => `${config.siteUrl}/category/${c.slug}`)];
  res.type('application/xml').send(`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map((u) => `  <url><loc>${xml(u)}</loc></url>`).join('\n')}
</urlset>
`);
});

router.get('/robots.txt', (req, res) => {
  res.type('text/plain').send(`User-agent: *\nDisallow: /admin\nDisallow: /account\nDisallow: /search\nSitemap: ${config.siteUrl}/sitemap.xml\n`);
});

router.get('/security', (req, res) => res.render('site/security', { title: 'Security' }));
router.get('/privacy', (req, res) => res.render('site/privacy', { title: 'Terms & privacy' }));

module.exports = router;
