/** Every signed-in user's own account area. Requires login for EVERY route (router-level). */
const express = require('express');
const Users = require('../models/users');
const Comments = require('../models/comments');
const Subscribers = require('../models/subscribers');
const Audit = require('../models/audit');
const config = require('../config');
const { requireLogin } = require('../middleware/auth');
const { validateProfile, validatePasswordChange, has } = require('../utils/validators');

const router = express.Router();
router.use(requireLogin);

function page(req, extra = {}) {
  const sub = Subscribers.findByEmail(req.user.email);
  return {
    title: 'Your account',
    values: req.user,
    subscribed: !!sub && sub.status === 'subscribed',
    myComments: Comments.forUser(req.user.id).slice(0, 20),
    ...extra
  };
}

router.get('/', (req, res) => res.render('account/index', page(req)));

router.post('/profile', (req, res) => {
  const { values, errors } = validateProfile(req.body);
  if (!errors.email && Users.emailTaken(values.email, req.user.id)) errors.email = 'That email is used by another account.';
  if (has(errors)) {
    return res.status(400).render('account/index', page(req, { values, errors, flash: { type: 'error', message: 'Please fix the highlighted fields.' } }));
  }
  // SECURITY: the id comes from the session, never from the form, so nobody can edit another account.
  Users.updateProfile(req.user.id, values);
  Audit.log(req, 'profile_updated', `user ${req.user.id}`);
  req.session.flash = { type: 'success', message: 'Profile saved.' };
  res.redirect('/account');
});

router.post('/newsletter', (req, res) => {
  const sub = Subscribers.findByEmail(req.user.email);
  if (req.body.subscribe === '1') Subscribers.subscribe({ email: req.user.email, name: req.user.name, userId: req.user.id });
  else if (sub) Subscribers.setStatus(sub.id, 'unsubscribed');
  req.session.flash = { type: 'success', message: req.body.subscribe === '1' ? 'You are subscribed to the newsletter.' : 'You have unsubscribed from the newsletter.' };
  res.redirect('/account');
});

router.get('/password', (req, res) => {
  res.render('account/password', { title: 'Change password', forced: !!req.user.must_change_password });
});

router.post('/password', (req, res, next) => {
  const forced = !!req.user.must_change_password;
  const { values, errors } = validatePasswordChange(req.body);
  if (!errors.currentPassword && !Users.verify(values.current, Users.passwordHash(req.user.id))) errors.currentPassword = 'Your current password is incorrect.';
  if (has(errors)) return res.status(400).render('account/password', { title: 'Change password', forced, errors });
  Users.setPassword(req.user.id, values.next);
  Audit.log(req, 'password_changed', `user ${req.user.id}`);
  // SECURITY: new session id after a password change.
  const userId = req.user.id;
  const viewed = req.session.viewed;
  req.session.regenerate((err) => {
    if (err) return next(err);
    Object.assign(req.session, { userId, viewed, flash: { type: 'success', message: 'Your password has been changed.' } });
    res.redirect(forced && req.user.role !== 'reader' ? '/admin' : '/account');
  });
});

router.post('/delete', (req, res, next) => {
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!Users.verify(password, Users.passwordHash(req.user.id))) {
    req.session.flash = { type: 'error', message: 'Account not deleted: the password was incorrect.' };
    return res.redirect('/account');
  }
  if (req.user.role !== 'reader') {
    req.session.flash = { type: 'error', message: 'Staff accounts are removed by an administrator, so their posts can be handed over first.' };
    return res.redirect('/account');
  }
  const sub = Subscribers.findByEmail(req.user.email);
  if (sub) Subscribers.setStatus(sub.id, 'unsubscribed');
  Audit.log(req, 'account_deleted', `user ${req.user.id}`);
  Users.remove(req.user.id, null);
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('bx.sid', { httpOnly: true, sameSite: 'lax', secure: config.isProd });
    res.redirect('/signin?signedout=1');
  });
});

module.exports = router;
