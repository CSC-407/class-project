/**
 * Post management (the content editor).
 * SECURITY: every action checks the permission rules in src/permissions.js on the server:
 *   - contributors/authors only see and edit THEIR OWN posts (changing the id in the URL gives 403);
 *   - only authors (own posts) and editors/admins may publish; contributors can only submit for review;
 *   - the HTML body is sanitized in the model before it is saved.
 */
const express = require('express');
const Posts = require('../../models/posts');
const Media = require('../../models/media');
const Users = require('../../models/users');
const Audit = require('../../models/audit');
const { categories, tags } = require('../../models/taxonomy');
const { can, canEditPost, canPublishPost, canDeletePost } = require('../../permissions');
const { denied } = require('../../middleware/auth');
const { validatePost, POST_STATUSES, str, has } = require('../../utils/validators');
const { toPositiveInt, lagosLocalToSql, sqlToLagosLocal, sqlNow } = require('../../utils/helpers');
const { cleanPostHtml } = require('../../utils/sanitize');

const router = express.Router();

// ---------- LIST + SEARCH/FILTER ----------
router.get('/', (req, res) => {
  const editAny = can(req.user, 'post.editAny');
  const f = {
    q: str(req.query.q, 80),
    status: ['draft', 'review', 'scheduled', 'published', 'archived'].includes(req.query.status) ? req.query.status : '',
    categoryId: toPositiveInt(req.query.category) || 0,
    tagId: toPositiveInt(req.query.tag) || 0,
    authorId: editAny ? toPositiveInt(req.query.author) || 0 : 0,
    sort: ['updated', 'newest', 'oldest', 'popular', 'title'].includes(req.query.sort) ? req.query.sort : 'updated',
    page: toPositiveInt(req.query.page) || 1
  };
  const result = Posts.searchAdmin({ ...f, onlyAuthorId: editAny ? 0 : req.user.id });
  const qs = (page) => {
    const p = new URLSearchParams();
    for (const k of ['q', 'status', 'sort']) if (f[k] && !(k === 'sort' && f.sort === 'updated')) p.set(k, f[k]);
    if (f.categoryId) p.set('category', f.categoryId);
    if (f.tagId) p.set('tag', f.tagId);
    if (f.authorId) p.set('author', f.authorId);
    if (page > 1) p.set('page', page);
    return '/admin/posts' + (p.toString() ? '?' + p : '');
  };
  res.render('admin/posts', {
    title: 'Posts', f, result, pageLink: qs, editAny,
    counts: Posts.statusCounts(editAny ? 0 : req.user.id),
    allCategories: categories.all(), allTags: tags.all(), staff: editAny ? Users.staff() : []
  });
});

// ---------- EDITOR ----------
function editorView(res, req, { post = null, values, errors = {}, status = 200 }) {
  // SECURITY: when a form is shown again after an error, the submitted HTML is sanitized before it is
  // put back into the editor, so a crafted submission can't run script in the editor page.
  values = { ...values, contentHtml: cleanPostHtml(values.contentHtml) };
  res.status(status).render('admin/post-editor', {
    title: post ? `Edit “${post.title}”` : 'New post',
    bodyClass: 'is-editor',
    post,
    values,
    errors,
    allCategories: categories.all(),
    tagSuggestions: tags.all().map((t) => t.name),
    canPublish: canPublishPost(req.user, post),
    canFeature: can(req.user, 'post.editAny'),
    canDelete: post ? canDeletePost(req.user, post) : false
  });
}

function formValues(post) {
  return {
    title: post.title, slug: post.slug, excerpt: post.excerpt, contentHtml: post.content_html, featureImage: post.feature_image,
    categoryId: post.category_id, tags: tags.forPost(post.id).map((t) => t.name), status: post.status,
    publishAt: post.status === 'published' ? sqlToLagosLocal(post.published_at) : '', featured: !!post.featured,
    allowComments: !!post.allow_comments, metaTitle: post.meta_title, metaDescription: post.meta_description,
    canonicalUrl: post.canonical_url, noindex: !!post.noindex
  };
}

/** Shared create/update logic. */
function savePost(req, res, post) {
  const { values, errors } = validatePost(req.body, { categoryIds: categories.all().map((c) => c.id) });

  // Feature images from uploads must exist in the media library.
  if (!errors.featureImage && values.featureImage.startsWith('/uploads/') && !Media.findByPath(values.featureImage)) {
    errors.featureImage = 'That image is not in the media library.';
  }
  // PERMISSION: publishing/archiving needs author (own post) or editor rights.
  if (!errors.status && ['published', 'archived'].includes(values.status) && !canPublishPost(req.user, post)) {
    errors.status = 'Contributors cannot publish. Choose “Submit for review” and an editor will publish it.';
  }
  // Only editors/admins may feature posts on the home page; others keep the current value.
  if (!can(req.user, 'post.editAny')) values.featured = post ? !!post.featured : false;

  if (has(errors)) return editorView(res, req, { post, values, errors, status: 400 });

  let publishedAt = null;
  if (values.status === 'published') publishedAt = lagosLocalToSql(values.publishAt) || (post && post.published_at) || sqlNow();
  if (values.status === 'archived') publishedAt = (post && post.published_at) || sqlNow();

  const saved = Posts.save({ id: post ? post.id : null, authorId: post ? post.author_id : req.user.id, values, status: values.status, publishedAt });
  Audit.log(req, post ? 'post_updated' : 'post_created', `${saved.id} → ${saved.display_status}`);
  const messages = {
    draft: 'Draft saved.',
    review: 'Submitted for review. An editor will take a look.',
    published: 'Post published.',
    scheduled: `Post scheduled for ${values.publishAt.replace('T', ' ')} (Lagos time).`,
    archived: 'Post archived. It is no longer visible on the site.'
  };
  req.session.flash = { type: 'success', message: messages[saved.display_status], link: saved.display_status === 'published' ? { href: `/posts/${saved.slug}`, label: 'View post' } : null };
  res.redirect(`/admin/posts/${saved.id}/edit`);
}

router.get('/new', (req, res) => editorView(res, req, { values: { status: 'draft', allowComments: true, tags: [] } }));
router.post('/new', (req, res) => savePost(req, res, null));

/** Load the post and check the user may edit it (blocks IDOR: guessing other people's post ids). */
function loadEditable(req, res, next) {
  const post = Posts.findById(toPositiveInt(req.params.id));
  if (!post) return next('route');
  if (!canEditPost(req.user, post)) return next(denied('You can only edit your own posts. Published posts are edited by editors.'));
  req.post = post;
  next();
}

router.get('/:id/edit', loadEditable, (req, res) => editorView(res, req, { post: req.post, values: formValues(req.post) }));
router.post('/:id/edit', loadEditable, (req, res) => savePost(req, res, req.post));

// Quick status changes from the list / review queue (editors approve, authors unpublish their own…)
router.post('/:id/status', (req, res, next) => {
  const post = Posts.findById(toPositiveInt(req.params.id));
  if (!post) return next();
  const status = str(req.body.status, 20);
  if (!POST_STATUSES.includes(status)) return next(denied('Unknown status.'));
  const allowed = canEditPost(req.user, post) && (['published', 'archived'].includes(status) ? canPublishPost(req.user, post) : true);
  if (!allowed) return next(denied());
  Posts.setStatus(post.id, status);
  Audit.log(req, 'post_status', `${post.id} → ${status}`);
  req.session.flash = { type: 'success', message: `“${post.title}” is now ${status === 'review' ? 'in review' : status}.` };
  res.redirect(str(req.body.returnTo, 100) === 'dashboard' ? '/admin' : '/admin/posts');
});

router.post('/:id/delete', (req, res, next) => {
  const post = Posts.findById(toPositiveInt(req.params.id));
  if (!post) return next();
  if (!canDeletePost(req.user, post)) return next(denied('You cannot delete this post.'));
  Posts.remove(post.id);
  Audit.log(req, 'post_deleted', `${post.id} ${post.title}`);
  req.session.flash = { type: 'success', message: `“${post.title}” was deleted.` };
  res.redirect('/admin/posts');
});

module.exports = router;
