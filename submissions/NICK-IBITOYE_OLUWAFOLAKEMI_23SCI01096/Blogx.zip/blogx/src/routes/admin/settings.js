/** General site settings + security audit log (administrators only). */
const express = require('express');
const Settings = require('../../models/settings');
const Audit = require('../../models/audit');
const { requirePermission } = require('../../middleware/auth');
const { validateSettings, has } = require('../../utils/validators');

const router = express.Router();

router.get('/settings', requirePermission('settings.manage'), (req, res) => {
  res.render('admin/settings', { title: 'Settings', values: Settings.all() });
});

router.post('/settings', requirePermission('settings.manage'), (req, res) => {
  const { values, errors } = validateSettings(req.body);
  if (has(errors)) return res.status(400).render('admin/settings', { title: 'Settings', values: { ...Settings.all(), ...values }, errors });
  Settings.save(values);
  Audit.log(req, 'settings_updated', Object.keys(values).join(','));
  req.session.flash = { type: 'success', message: 'Settings saved.' };
  res.redirect('/admin/settings');
});

router.get('/audit', requirePermission('audit.view'), (req, res) => {
  res.render('admin/audit', { title: 'Audit log', entries: Audit.recent(200) });
});

module.exports = router;
