/**
 * Admin area. SECURITY: router.use(requirePermission('admin.access')) protects EVERY /admin URL —
 * readers and visitors are refused on the server before any admin code runs.
 * Each sub-router then applies its own, stricter permission (e.g. users.manage for /admin/users).
 */
const express = require('express');
const Posts = require('../../models/posts');
const Comments = require('../../models/comments');
const Subscribers = require('../../models/subscribers');
const Users = require('../../models/users');
const Stats = require('../../models/stats');
const Audit = require('../../models/audit');
const { can } = require('../../permissions');
const { requirePermission } = require('../../middleware/auth');

const router = express.Router();
router.use(requirePermission('admin.access'));

// DASHBOARD — what you see depends on your role
router.get('/', (req, res) => {
  const all = can(req.user, 'stats.viewAll');
  const authorScope = all ? 0 : req.user.id;
  const data = {
    title: 'Dashboard',
    counts: Posts.statusCounts(authorScope),
    daily: Stats.daily(30, authorScope),
    views30: Stats.total(30, authorScope),
    views7: Stats.total(7, authorScope),
    topPosts: Stats.topPosts(5, 30, authorScope),
    myRecent: Posts.searchAdmin({ onlyAuthorId: req.user.id, perPage: 5 }).items,
    reviewQueue: all ? Posts.searchAdmin({ status: 'review', perPage: 10 }).items : [],
    commentCounts: can(req.user, 'comments.moderate') ? Comments.counts() : null,
    subscriberCounts: can(req.user, 'subscribers.view') ? Subscribers.counts() : null,
    userCount: can(req.user, 'users.manage') ? Users.count() : null,
    audit: can(req.user, 'audit.view') ? Audit.recent(8) : [],
    scopeAll: all
  };
  data.maxDaily = Math.max(1, ...data.daily.map((d) => d.views));
  res.render('admin/dashboard', data);
});

router.use('/posts', require('./posts'));
router.use('/media', require('./media'));
router.use('/users', require('./users'));
router.use(require('./taxonomy'));
router.use(require('./community'));
router.use(require('./settings'));

module.exports = router;
