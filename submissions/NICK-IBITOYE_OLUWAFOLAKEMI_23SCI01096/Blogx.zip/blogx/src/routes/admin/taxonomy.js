/** Categories, sub-categories and tags (editors and admins). */
const express = require('express');
const Audit = require('../../models/audit');
const { categories, tags } = require('../../models/taxonomy');
const { requirePermission } = require('../../middleware/auth');
const { validateCategory, validateTag, has } = require('../../utils/validators');
const { toPositiveInt } = require('../../utils/helpers');

const router = express.Router();
router.use(['/categories', '/tags'], requirePermission('taxonomy.manage')); // only these paths
const flash = (req, type, message) => { req.session.flash = { type, message }; };

// ---------- CATEGORIES ----------
function categoryPage(res, { editing = null, values = {}, errors = {}, status = 200 }) {
  res.status(status).render('admin/categories', { title: 'Categories', tree: categories.tree(), parents: categories.topLevel(), editing, values, errors });
}

router.get('/categories', (req, res) => {
  const editing = categories.findById(toPositiveInt(req.query.edit)) || null;
  categoryPage(res, { editing, values: editing ? { name: editing.name, description: editing.description, parentId: editing.parent_id } : {} });
});

function parentIdsFor(editingId = 0) {
  // A category can't be its own parent, and only top-level categories can be parents (one level deep).
  return categories.topLevel().map((c) => c.id).filter((id) => id !== editingId);
}

router.post('/categories', (req, res) => {
  const { values, errors } = validateCategory(req.body, { parentIds: parentIdsFor() });
  if (!errors.name && categories.nameTaken(values.name, values.parentId)) errors.name = 'A category with this name already exists here.';
  if (has(errors)) return categoryPage(res, { values, errors, status: 400 });
  const cat = categories.create(values);
  Audit.log(req, 'category_created', cat.name);
  flash(req, 'success', `${values.parentId ? 'Sub-category' : 'Category'} “${cat.name}” added.`);
  res.redirect('/admin/categories');
});

router.post('/categories/:id/edit', (req, res, next) => {
  const cat = categories.findById(toPositiveInt(req.params.id));
  if (!cat) return next();
  const { values, errors } = validateCategory(req.body, { parentIds: parentIdsFor(cat.id) });
  if (!errors.parentId && values.parentId && categories.children(cat.id).length) errors.parentId = 'This category has sub-categories, so it must stay top-level.';
  if (!errors.name && categories.nameTaken(values.name, values.parentId, cat.id)) errors.name = 'A category with this name already exists here.';
  if (has(errors)) return categoryPage(res, { editing: cat, values, errors, status: 400 });
  categories.update(cat.id, values);
  Audit.log(req, 'category_updated', values.name);
  flash(req, 'success', 'Category saved.');
  res.redirect('/admin/categories');
});

router.post('/categories/:id/delete', (req, res, next) => {
  const cat = categories.findById(toPositiveInt(req.params.id));
  if (!cat) return next();
  const blocked = categories.remove(cat.id);
  if (blocked) flash(req, 'error', `“${cat.name}” can't be deleted because ${blocked}.`);
  else { Audit.log(req, 'category_deleted', cat.name); flash(req, 'success', `“${cat.name}” deleted.`); }
  res.redirect('/admin/categories');
});

// ---------- TAGS ----------
function tagPage(res, { editing = null, values = {}, errors = {}, status = 200 }) {
  res.status(status).render('admin/tags', { title: 'Tags', list: tags.all(), editing, values, errors });
}

router.get('/tags', (req, res) => {
  const editing = tags.findById(toPositiveInt(req.query.edit)) || null;
  tagPage(res, { editing, values: editing ? { name: editing.name } : {} });
});

router.post('/tags', (req, res) => {
  const { values, errors } = validateTag(req.body);
  if (!errors.name && tags.nameTaken(values.name)) errors.name = 'That tag already exists.';
  if (has(errors)) return tagPage(res, { values, errors, status: 400 });
  tags.create(values.name);
  Audit.log(req, 'tag_created', values.name);
  flash(req, 'success', `Tag “${values.name}” added.`);
  res.redirect('/admin/tags');
});

router.post('/tags/:id/edit', (req, res, next) => {
  const tag = tags.findById(toPositiveInt(req.params.id));
  if (!tag) return next();
  const { values, errors } = validateTag(req.body);
  if (!errors.name && tags.nameTaken(values.name, tag.id)) errors.name = 'That tag already exists.';
  if (has(errors)) return tagPage(res, { editing: tag, values, errors, status: 400 });
  tags.rename(tag.id, values.name);
  flash(req, 'success', 'Tag renamed.');
  res.redirect('/admin/tags');
});

router.post('/tags/:id/delete', (req, res, next) => {
  const tag = tags.findById(toPositiveInt(req.params.id));
  if (!tag) return next();
  tags.remove(tag.id);
  Audit.log(req, 'tag_deleted', tag.name);
  flash(req, 'success', `Tag “${tag.name}” deleted and removed from its posts.`);
  res.redirect('/admin/tags');
});

module.exports = router;
