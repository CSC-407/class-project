/** Comment moderation (editors+) and newsletter subscribers (view: editors+, manage/export: admins). */
const express = require('express');
const Comments = require('../../models/comments');
const Subscribers = require('../../models/subscribers');
const Audit = require('../../models/audit');
const { requirePermission } = require('../../middleware/auth');
const { str } = require('../../utils/validators');
const { toPositiveInt } = require('../../utils/helpers');
const { toCsv } = require('../../utils/csv');

const router = express.Router();
const flash = (req, type, message) => { req.session.flash = { type, message }; };

// ---------- COMMENTS ----------
router.get('/comments', requirePermission('comments.moderate'), (req, res) => {
  const status = ['pending', 'approved', 'spam'].includes(req.query.status) ? req.query.status : '';
  const q = str(req.query.q, 60);
  res.render('admin/comments', { title: 'Comments', list: Comments.list({ status, q }), status, q, counts: Comments.counts() });
});

router.post('/comments/:id/status', requirePermission('comments.moderate'), (req, res, next) => {
  const c = Comments.findById(toPositiveInt(req.params.id));
  if (!c) return next();
  const status = str(req.body.status, 10);
  if (!['pending', 'approved', 'spam'].includes(status)) return next();
  Comments.setStatus(c.id, status);
  Audit.log(req, 'comment_' + status, `comment ${c.id}`);
  flash(req, 'success', { approved: 'Comment approved.', pending: 'Comment moved back to pending.', spam: 'Comment marked as spam.' }[status]);
  res.redirect('/admin/comments' + (req.body.filter ? `?status=${encodeURIComponent(str(req.body.filter, 10))}` : ''));
});

router.post('/comments/:id/delete', requirePermission('comments.moderate'), (req, res, next) => {
  const c = Comments.findById(toPositiveInt(req.params.id));
  if (!c) return next();
  Comments.remove(c.id);
  Audit.log(req, 'comment_deleted', `comment ${c.id}`);
  flash(req, 'success', 'Comment deleted.');
  res.redirect('/admin/comments');
});

// ---------- SUBSCRIBERS ----------
router.get('/subscribers', requirePermission('subscribers.view'), (req, res) => {
  const status = ['subscribed', 'unsubscribed'].includes(req.query.status) ? req.query.status : '';
  const q = str(req.query.q, 60);
  res.render('admin/subscribers', { title: 'Subscribers', list: Subscribers.list({ q, status }), q, status, counts: Subscribers.counts() });
});

// CSV export (admins). Cells are protected against spreadsheet formula injection (src/utils/csv.js).
router.get('/subscribers.csv', requirePermission('subscribers.manage'), (req, res) => {
  const rows = Subscribers.list({ status: 'subscribed' }).map((s) => [s.email, s.name || '', s.status, s.created_at]);
  Audit.log(req, 'subscribers_exported', `${rows.length} rows`);
  res.set('Content-Disposition', 'attachment; filename="subscribers.csv"');
  res.type('text/csv').send(toCsv(['email', 'name', 'status', 'subscribed_at'], rows));
});

router.post('/subscribers/:id/status', requirePermission('subscribers.manage'), (req, res, next) => {
  const s = Subscribers.findById(toPositiveInt(req.params.id));
  if (!s) return next();
  const status = req.body.status === 'subscribed' ? 'subscribed' : 'unsubscribed';
  Subscribers.setStatus(s.id, status);
  flash(req, 'success', `${s.email} is now ${status}.`);
  res.redirect('/admin/subscribers');
});

router.post('/subscribers/:id/delete', requirePermission('subscribers.manage'), (req, res, next) => {
  const s = Subscribers.findById(toPositiveInt(req.params.id));
  if (!s) return next();
  Subscribers.remove(s.id);
  Audit.log(req, 'subscriber_deleted', `subscriber ${s.id}`);
  flash(req, 'success', `${s.email} was removed from the list.`);
  res.redirect('/admin/subscribers');
});

module.exports = router;
