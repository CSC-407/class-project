/**
 * User management (administrators only).
 * SAFETY RULES: an admin cannot change their own role/status or delete themselves here,
 * and the last active admin can never be demoted, suspended or deleted.
 */
const express = require('express');
const Users = require('../../models/users');
const Audit = require('../../models/audit');
const { ROLES, ROLE_LABELS } = require('../../permissions');
const { requirePermission } = require('../../middleware/auth');
const { validateNewUser, has, str } = require('../../utils/validators');
const { toPositiveInt } = require('../../utils/helpers');

const router = express.Router();
router.use(requirePermission('users.manage'));
const flash = (req, type, message) => { req.session.flash = { type, message }; };

router.get('/', (req, res) => {
  const q = str(req.query.q, 60);
  const role = ROLES.includes(req.query.role) ? req.query.role : '';
  res.render('admin/users', { title: 'Staff & members', users: Users.list({ q, role }), q, role, ROLES });
});

router.get('/new', (req, res) => res.render('admin/user-new', { title: 'Invite a user', values: { role: 'author' }, ROLES }));

// Admin creates the account with a TEMPORARY password; the user must change it at first sign-in.
router.post('/new', (req, res) => {
  const { values, errors } = validateNewUser(req.body);
  if (!errors.email && Users.emailTaken(values.email)) errors.email = 'An account with this email already exists.';
  if (has(errors)) {
    delete values.password;
    return res.status(400).render('admin/user-new', { title: 'Invite a user', values, errors, ROLES });
  }
  const user = Users.create({ ...values, mustChangePassword: true });
  Audit.log(req, 'user_created', `${user.id} as ${user.role}`);
  flash(req, 'success', `${user.name} can now sign in as ${ROLE_LABELS[user.role]} with the temporary password. They will be asked to change it.`);
  res.redirect('/admin/users');
});

function loadTarget(req, res, next) {
  const target = Users.findById(toPositiveInt(req.params.id));
  if (!target) return next('route');
  if (target.id === req.user.id) {
    flash(req, 'error', 'You cannot change your own role or status, or delete yourself. Ask another administrator.');
    return res.redirect('/admin/users');
  }
  req.target = target;
  next();
}

const lastAdmin = (t) => t.role === 'admin' && t.status === 'active' && Users.activeAdminCount() <= 1;

router.post('/:id/role', loadTarget, (req, res) => {
  const role = str(req.body.role, 20);
  if (!ROLES.includes(role)) { flash(req, 'error', 'Unknown role.'); return res.redirect('/admin/users'); }
  if (role !== 'admin' && lastAdmin(req.target)) { flash(req, 'error', 'The site must keep at least one active administrator.'); return res.redirect('/admin/users'); }
  Users.setRole(req.target.id, role);
  Audit.log(req, 'user_role', `${req.target.id}: ${req.target.role} → ${role}`);
  flash(req, 'success', `${req.target.name} is now ${ROLE_LABELS[role]}.`);
  res.redirect('/admin/users');
});

router.post('/:id/status', loadTarget, (req, res) => {
  const status = req.body.status === 'suspended' ? 'suspended' : 'active';
  if (status === 'suspended' && lastAdmin(req.target)) { flash(req, 'error', 'The site must keep at least one active administrator.'); return res.redirect('/admin/users'); }
  Users.setStatus(req.target.id, status);
  if (status === 'active') Users.clearFailedLogins(req.target.id);
  Audit.log(req, 'user_' + status, String(req.target.id));
  flash(req, 'success', `${req.target.name} is now ${status}. ${status === 'suspended' ? 'They were signed out everywhere.' : ''}`);
  res.redirect('/admin/users');
});

router.post('/:id/delete', loadTarget, (req, res) => {
  if (lastAdmin(req.target)) { flash(req, 'error', 'The site must keep at least one active administrator.'); return res.redirect('/admin/users'); }
  Users.remove(req.target.id, req.user.id); // their posts are handed to the admin doing the delete
  Audit.log(req, 'user_deleted', String(req.target.id));
  flash(req, 'success', `${req.target.name}'s account was deleted. Any posts they wrote now belong to you.`);
  res.redirect('/admin/users');
});

module.exports = router;
