/** Media library: upload, browse, describe (alt text) and delete images. */
const express = require('express');
const Media = require('../../models/media');
const Audit = require('../../models/audit');
const { can, canDeleteMedia } = require('../../permissions');
const { requirePermission, denied } = require('../../middleware/auth');
const { verifyCsrf } = require('../../middleware/csrf');
const { upload, saveImage, deleteFile } = require('../../middleware/upload');
const { str } = require('../../utils/validators');
const { toPositiveInt } = require('../../utils/helpers');

const router = express.Router();
router.use(requirePermission('media.upload'));

const scope = (req) => (can(req.user, 'media.deleteAny') ? 0 : req.user.id); // writers see their own uploads

router.get('/', (req, res) => {
  const q = str(req.query.q, 60);
  res.render('admin/media', { title: 'Media', items: Media.list({ q, onlyUserId: scope(req) }), q });
});

// JSON list for the editor's image picker
router.get('/library.json', (req, res) => {
  res.json(Media.list({ q: str(req.query.q, 60), onlyUserId: scope(req) }).map((m) => ({ id: m.id, path: m.path, alt: m.alt || '', name: m.original_name })));
});

function store(req) {
  const saved = saveImage(req.file);
  if (saved.error) return saved;
  const item = Media.create({ ...saved, alt: str(req.body.alt, 150), uploadedBy: req.user.id });
  Audit.log(req, 'media_uploaded', `${item.id} ${item.original_name}`);
  return { item };
}

// Upload form. multer parses the multipart body FIRST, then the CSRF token is checked, THEN the file is saved.
router.post('/', upload.single('file'), verifyCsrf, (req, res) => {
  const result = store(req);
  req.session.flash = result.error ? { type: 'error', message: result.error } : { type: 'success', message: `Uploaded “${result.item.original_name}”.` };
  res.redirect('/admin/media');
});

// Upload from inside the editor (fetch + X-CSRF-Token header) → JSON
router.post('/upload.json', upload.single('file'), verifyCsrf, (req, res) => {
  const result = store(req);
  if (result.error) return res.status(400).json({ error: result.error });
  res.json({ id: result.item.id, path: result.item.path, alt: result.item.alt || '', name: result.item.original_name });
});

function loadItem(req, res, next) {
  const item = Media.findById(toPositiveInt(req.params.id));
  if (!item) return next('route');
  if (!canDeleteMedia(req.user, item)) return next(denied('You can only manage images you uploaded.'));
  req.item = item;
  next();
}

router.post('/:id/alt', loadItem, (req, res) => {
  Media.updateAlt(req.item.id, str(req.body.alt, 150));
  req.session.flash = { type: 'success', message: 'Description saved.' };
  res.redirect('/admin/media');
});

router.post('/:id/delete', loadItem, (req, res) => {
  const used = Media.usage(req.item.path);
  if (used > 0) {
    req.session.flash = { type: 'error', message: `“${req.item.original_name}” is used in ${used} post(s). Remove it from those posts first.` };
    return res.redirect('/admin/media');
  }
  Media.remove(req.item.id);
  deleteFile(req.item.path);
  Audit.log(req, 'media_deleted', `${req.item.id} ${req.item.original_name}`);
  req.session.flash = { type: 'success', message: 'Image deleted.' };
  res.redirect('/admin/media');
});

module.exports = router;
