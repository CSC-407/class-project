-- Blog.x database schema (SQLite)
PRAGMA foreign_keys = ON;

-- Accounts. role decides permissions (see src/permissions.js).
CREATE TABLE IF NOT EXISTS users (
  id                   INTEGER PRIMARY KEY AUTOINCREMENT,
  name                 TEXT    NOT NULL,
  email                TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  slug                 TEXT    NOT NULL UNIQUE,
  password_hash        TEXT    NOT NULL,          -- bcrypt hash, never the password itself
  role                 TEXT    NOT NULL DEFAULT 'reader'
                       CHECK (role IN ('reader', 'contributor', 'author', 'editor', 'admin')),
  bio                  TEXT,
  website              TEXT,
  status               TEXT    NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  must_change_password INTEGER NOT NULL DEFAULT 0,  -- set when an admin creates the account
  failed_logins        INTEGER NOT NULL DEFAULT 0,
  locked_until         INTEGER,                     -- unix ms
  created_at           TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at           TEXT    NOT NULL DEFAULT (datetime('now'))
);

-- Categories, with optional parent for sub-categories (one level deep).
CREATE TABLE IF NOT EXISTS categories (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  slug        TEXT NOT NULL UNIQUE,
  description TEXT,
  parent_id   INTEGER REFERENCES categories(id) ON DELETE RESTRICT,
  UNIQUE (name, parent_id)
);

CREATE TABLE IF NOT EXISTS tags (
  id   INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  slug TEXT NOT NULL UNIQUE
);

-- Uploaded images (media library)
CREATE TABLE IF NOT EXISTS media (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  path          TEXT    NOT NULL UNIQUE,          -- /uploads/<random>.<ext>
  original_name TEXT    NOT NULL,
  mime          TEXT    NOT NULL,
  size          INTEGER NOT NULL,
  alt           TEXT,
  uploaded_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS posts (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  title            TEXT    NOT NULL,
  slug             TEXT    NOT NULL UNIQUE,
  excerpt          TEXT,
  content_html     TEXT    NOT NULL DEFAULT '',   -- ALWAYS sanitized before saving
  content_text     TEXT    NOT NULL DEFAULT '',   -- plain text copy, for search & reading time
  feature_image    TEXT,
  status           TEXT    NOT NULL DEFAULT 'draft'
                   CHECK (status IN ('draft', 'review', 'published', 'archived')),
  featured         INTEGER NOT NULL DEFAULT 0,
  allow_comments   INTEGER NOT NULL DEFAULT 1,
  author_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  category_id      INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  meta_title       TEXT,
  meta_description TEXT,
  canonical_url    TEXT,
  noindex          INTEGER NOT NULL DEFAULT 0,
  reading_minutes  INTEGER NOT NULL DEFAULT 1,
  view_count       INTEGER NOT NULL DEFAULT 0,
  published_at     TEXT,                         -- in the future = scheduled
  created_at       TEXT    NOT NULL DEFAULT (datetime('now')),
  updated_at       TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_posts_status ON posts(status, published_at);
CREATE INDEX IF NOT EXISTS idx_posts_author ON posts(author_id);
CREATE INDEX IF NOT EXISTS idx_posts_category ON posts(category_id);

CREATE TABLE IF NOT EXISTS post_tags (
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  tag_id  INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (post_id, tag_id)
);

-- Daily view counts per post (no IP addresses or personal data are stored)
CREATE TABLE IF NOT EXISTS post_views (
  post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  day     TEXT    NOT NULL,            -- YYYY-MM-DD
  views   INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (post_id, day)
);

CREATE TABLE IF NOT EXISTS comments (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id    INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body       TEXT    NOT NULL,                   -- plain text, escaped when shown
  status     TEXT    NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'spam')),
  created_at TEXT    NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id, status);

CREATE TABLE IF NOT EXISTS subscribers (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  email             TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name              TEXT,
  status            TEXT NOT NULL DEFAULT 'subscribed' CHECK (status IN ('subscribed', 'unsubscribed')),
  unsubscribe_token TEXT NOT NULL UNIQUE,         -- random, used in one-click unsubscribe links
  user_id           INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at        TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Site-wide settings (key/value)
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- Security audit trail. Never stores passwords or tokens.
CREATE TABLE IF NOT EXISTS audit_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER,
  action     TEXT NOT NULL,
  detail     TEXT,
  ip         TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
