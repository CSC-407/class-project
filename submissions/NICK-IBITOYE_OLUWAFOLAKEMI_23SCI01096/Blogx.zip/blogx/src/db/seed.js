/**
 * npm run db:seed — adds the demo users, categories, posts, comments, subscribers and view history.
 * Anything that already exists is skipped, so it is safe to run more than once.
 *
 * The admin password comes from SEED_ADMIN_PASSWORD in .env (default: ChangeMe2026!).
 * CHANGE IT after the first sign-in: Account → Change password.
 */
const db = require('./index');
const config = require('../config');
const Users = require('../models/users');
const Posts = require('../models/posts');
const Comments = require('../models/comments');
const Subscribers = require('../models/subscribers');
const { categories } = require('../models/taxonomy');
const data = require('./seed-data');

const sqlDaysAgo = (days) => new Date(Date.now() - days * 86400000 - 3 * 3600000).toISOString().slice(0, 19).replace('T', ' ');

function seed({ quiet = false } = {}) {
  const say = (...a) => { if (!quiet) console.log(...a); };
  if (config.isProd && !process.env.SEED_ADMIN_PASSWORD) throw new Error('Set SEED_ADMIN_PASSWORD before seeding a production database.');

  db.transaction(() => {
    // ---- Users ----
    const userIds = {};
    // .env values are ignored in tests so the automated tests always know the demo passwords.
    const env = config.isTest ? {} : process.env;
    for (const u of data.users) {
      const email = ((u.envEmail && env[u.envEmail]) || u.email).toLowerCase();
      const password = (u.envPassword && env[u.envPassword]) || u.password;
      const existing = Users.findForLogin(email);
      userIds[u.key] = existing ? existing.id : Users.create({ name: u.name, email, password, role: u.role, bio: u.bio || null }).id;
    }

    // ---- Categories + sub-categories ----
    const catIds = {};
    for (const c of data.categories) {
      const parent = db.prepare('SELECT id FROM categories WHERE name = ? AND parent_id IS NULL').get(c.name) || categories.create({ name: c.name, description: c.description, parentId: null });
      catIds[c.name] = parent.id;
      for (const ch of c.children) {
        const child = db.prepare('SELECT id FROM categories WHERE name = ? AND parent_id = ?').get(ch.name, parent.id) || categories.create({ name: ch.name, description: ch.description, parentId: parent.id });
        catIds[ch.name] = child.id;
      }
    }

    // ---- Posts (saved through the model, so content is sanitized exactly like real posts) ----
    const postIds = {};
    for (const p of data.posts) {
      const existing = db.prepare('SELECT id FROM posts WHERE title = ?').get(p.title);
      if (existing) { postIds[p.title] = existing.id; continue; }
      const publishedAt = p.daysAgo === null ? null : sqlDaysAgo(p.daysAgo);
      const saved = Posts.save({
        authorId: userIds[p.author],
        status: p.status,
        publishedAt,
        values: {
          title: p.title, slug: '', excerpt: p.excerpt, contentHtml: p.html, featureImage: `/images/covers/${p.cover}.jpg`,
          categoryId: catIds[p.category], tags: p.tags, featured: p.featured, allowComments: true,
          metaTitle: '', metaDescription: '', canonicalUrl: '', noindex: false
        }
      });
      const created = publishedAt && p.daysAgo > 0 ? publishedAt : sqlDaysAgo(1);
      db.prepare('UPDATE posts SET created_at = ?, updated_at = ? WHERE id = ?').run(created, created, saved.id);
      postIds[p.title] = saved.id;
    }

    // ---- Comments ----
    if (db.prepare('SELECT COUNT(*) AS n FROM comments').get().n === 0) {
      for (const c of data.comments) Comments.create({ postId: postIds[c.post], userId: userIds[c.user], body: c.body, status: c.status });
    }

    // ---- Newsletter subscribers ----
    for (const [email, name, status] of data.subscribers) {
      if (Subscribers.findByEmail(email)) continue;
      const { subscriber } = Subscribers.subscribe({ email, name, userId: email === 'reader@blogx.test' ? userIds.reader : null });
      if (status) Subscribers.setStatus(subscriber.id, status);
    }

    // ---- 30 days of view history so the dashboard chart has something to show ----
    if (db.prepare('SELECT COUNT(*) AS n FROM post_views').get().n === 0) {
      const live = db.prepare(`SELECT id, published_at FROM posts WHERE status = 'published' AND published_at <= datetime('now')`).all();
      const insert = db.prepare('INSERT INTO post_views (post_id, day, views) VALUES (?, ?, ?)');
      let seedNum = 7;
      const rand = () => { seedNum = (seedNum * 16807) % 2147483647; return seedNum / 2147483647; }; // repeatable pseudo-random
      for (const post of live) {
        for (let d = 29; d >= 0; d--) {
          const day = new Date(Date.now() - d * 86400000).toISOString().slice(0, 10);
          if (day < post.published_at.slice(0, 10)) continue;
          const views = Math.round(rand() * 25 + (29 - d) * 0.6);
          if (views > 0) insert.run(post.id, day, views);
        }
      }
      db.prepare('UPDATE posts SET view_count = COALESCE((SELECT SUM(views) FROM post_views v WHERE v.post_id = posts.id), 0)').run();
    }
  })();

  say(`Seed complete: ${data.users.length} users, ${data.posts.length} posts.`);
  if (!process.env.SEED_ADMIN_PASSWORD) say('WARNING: the admin uses the default demo password from the README. Change it after signing in.');
}

module.exports = seed;
if (require.main === module) seed();
