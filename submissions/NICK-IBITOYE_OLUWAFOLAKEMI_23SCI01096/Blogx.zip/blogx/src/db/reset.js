/** npm run db:reset — DELETES the local database and rebuilds it with demo content. Development only. */
const fs = require('fs');
const config = require('../config');

if (config.isProd) {
  console.error('Refusing to reset the database in production.');
  process.exit(1);
}
for (const suffix of ['', '-wal', '-shm']) {
  if (fs.existsSync(config.dbFile + suffix)) fs.unlinkSync(config.dbFile + suffix);
}
console.log('Old database removed.');
require('./seed')();
