/** npm run db:migrate — creates any missing tables. Safe to run repeatedly; never deletes data. */
const db = require('./index');
db.migrate();
console.log('Database ready:', db.name);
