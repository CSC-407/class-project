/**
 * SQLite connection (better-sqlite3).
 * SECURITY: every query in Blog.x uses prepared statements with bound parameters
 * (? or @name). User input is never glued into SQL text, which prevents SQL injection.
 */
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const config = require('../config');

if (config.dbFile !== ':memory:') fs.mkdirSync(path.dirname(config.dbFile), { recursive: true });

const db = new Database(config.dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function migrate() {
  db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));
}
migrate();

module.exports = db;
module.exports.migrate = migrate;
