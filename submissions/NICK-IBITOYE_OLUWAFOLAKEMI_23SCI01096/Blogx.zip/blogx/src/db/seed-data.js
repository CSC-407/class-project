/**
 * Demo content for Blog.x. All text was written for this project; cover images are generated
 * abstract artwork (scripts/generate-covers.sh). Passwords can be overridden in .env.
 */

module.exports.users = [
  { key: 'admin', name: 'Site Admin', role: 'admin', envEmail: 'SEED_ADMIN_EMAIL', email: 'admin@blogx.test', envPassword: 'SEED_ADMIN_PASSWORD', password: 'ChangeMe2026!',
    bio: 'Keeps the lights on at Blog.x.' },
  { key: 'editor', name: 'Tolu Adebayo', role: 'editor', email: 'editor@blogx.test', password: 'EditorPass2026',
    bio: 'Managing editor. Coffee first, commas second.' },
  { key: 'author', name: 'Chidi Okeke', role: 'author', email: 'author@blogx.test', password: 'AuthorPass2026',
    bio: 'Software engineer in Yaba writing about the web, security and building things that last.' },
  { key: 'contributor', name: 'Amara Bello', role: 'contributor', email: 'contributor@blogx.test', password: 'ContribPass2026',
    bio: 'Food lover and occasional travel writer.' },
  { key: 'reader', name: 'Ngozi Eze', role: 'reader', email: 'reader@blogx.test', password: 'ReaderPass2026' },
  { key: 'reader2', name: 'Femi Adewale', role: 'reader', email: 'femi@blogx.test', password: 'ReaderPass2026' }
];

// Categories with sub-categories (children)
module.exports.categories = [
  { name: 'Technology', description: 'Software, the web and the tools we build with.', children: [
    { name: 'Web Development', description: 'Building for the browser.' },
    { name: 'Security', description: 'Keeping people and their data safe.' },
    { name: 'AI', description: 'Machine learning in everyday products.' }] },
  { name: 'Culture', description: 'Food, music and the way we live.', children: [
    { name: 'Food', description: 'What we cook and where we eat.' },
    { name: 'Music', description: 'Sounds from Lagos and beyond.' }] },
  { name: 'Lifestyle', description: 'Work, travel and everything in between.', children: [
    { name: 'Travel', description: 'Getting out of town.' }] },
  { name: 'Business', description: 'Startups, money and building companies.', children: [] }
];

const p = (...paras) => paras.map((x) => (x.startsWith('<') ? x : `<p>${x}</p>`)).join('\n');

/**
 * daysAgo: when it was published (negative = scheduled in the future).
 * status: draft | review | published | archived
 */
module.exports.posts = [
  {
    title: 'Welcome to Blog.x', author: 'admin', category: 'Technology', tags: ['Announcements', 'Writing'], cover: 'lagos-dusk',
    status: 'published', daysAgo: 38, featured: false,
    excerpt: 'A quick tour of the platform: who can do what, how posts move from draft to published, and where to find everything.',
    html: p(
      'Blog.x is a home for writing. Readers can follow along, comment and subscribe to the newsletter. Writers get a calm, distraction-free editor. Editors and administrators get the tools to keep it all organised.',
      '<h2>Roles at a glance</h2>',
      '<ul><li><strong>Readers</strong> comment on posts and manage their newsletter subscription.</li><li><strong>Contributors</strong> write drafts and submit them for review.</li><li><strong>Authors</strong> publish their own posts.</li><li><strong>Editors</strong> manage every post, category, tag and comment.</li><li><strong>Administrators</strong> also manage people and site settings.</li></ul>',
      '<h2>From draft to published</h2>',
      'Every post starts as a draft. Contributors submit drafts for review, and an editor publishes them. Authors and editors can publish straight away, or schedule a post for later. Archived posts disappear from the site but stay safe in the admin area.',
      'Curious how we keep your account safe? Read the <a href="/security">security page</a>.'
    )
  },
  {
    title: 'Ten habits that keep your web app secure', author: 'author', category: 'Security', tags: ['Security', 'Tutorials', 'Beginners'], cover: 'night-code',
    status: 'published', daysAgo: 3, featured: true,
    excerpt: 'Security is not a feature you add at the end. These ten habits catch most of the problems that make the news.',
    html: p(
      'Most security incidents are not clever. They are the same handful of mistakes, repeated. The good news: a few habits, applied every day, close most of the doors attackers walk through.',
      '<h2>1. Never trust input</h2>',
      'Anything that arrives from the browser can be changed: form fields, hidden fields, headers, cookies. Validate on the server, every time, even if the browser already checked.',
      '<h2>2. Use parameterised queries</h2>',
      'Gluing user input into SQL is how injection happens. Prepared statements send the query and the data separately, so data can never become code.',
      '<h2>3. Escape output, then add a Content Security Policy</h2>',
      'Escaping stops <code>&lt;script&gt;</code> from running. A strict CSP is the safety net if you ever forget.',
      '<blockquote>Defence in depth means assuming one layer will fail, and making sure another catches it.</blockquote>',
      '<h2>4–10. The rest of the list</h2>',
      '<ol><li>Hash passwords with bcrypt or Argon2.</li><li>Put a CSRF token on every form that changes data.</li><li>Set cookies to HttpOnly, Secure and SameSite.</li><li>Check permissions on the server for every request.</li><li>Rate-limit logins.</li><li>Keep secrets out of your code and your logs.</li><li>Show users friendly errors and keep the details in your logs.</li></ol>'
    )
  },
  {
    title: 'Building a blog with Node.js and SQLite', author: 'author', category: 'Web Development', tags: ['Tutorials', 'JavaScript'], cover: 'indigo-wave',
    status: 'published', daysAgo: 9, featured: false,
    excerpt: 'Why a single-file database is a great fit for a small publication, and the trade-offs to know about before you grow.',
    html: p(
      'SQLite gets underestimated. It is a full SQL database that lives in one file, needs no server, and handles far more traffic than most blogs will ever see.',
      '<h2>Why it works for a blog</h2>',
      'A blog is read far more often than it is written. SQLite is extremely fast at reads, and with write-ahead logging (WAL) readers never wait for a writer.',
      '<h2>Where it stops fitting</h2>',
      'If you need several servers writing at once, move to PostgreSQL. Until then, enjoy backups that are a single file copy.',
      '<pre><code>db.prepare("SELECT * FROM posts WHERE slug = ?").get(slug);</code></pre>',
      'Notice the question mark: the slug is sent separately from the SQL. That is the habit that prevents SQL injection.'
    )
  },
  {
    title: 'The joy of a Saturday morning in Yaba', author: 'contributor', category: 'Food', tags: ['Lagos', 'Food'], cover: 'desert-sun',
    status: 'published', daysAgo: 14, featured: false,
    excerpt: 'Akara from the corner stand, a crowded bus stop, and the city slowly waking up.',
    html: p(
      'There is a woman at the corner of Herbert Macaulay Way whose akara sells out before eight. If you want some, you join the line early, and you do not complain about the smoke.',
      'Saturday in Yaba moves at its own pace. Shops roll up their shutters one by one. Somebody is always testing a speaker. The traffic has not decided yet whether today will be bad.',
      '<h2>Where to go next</h2>',
      'After breakfast, walk toward the market. Buy nothing you planned to buy. That is the rule.'
    )
  },
  {
    title: 'What we learned launching a product in Lagos', author: 'editor', category: 'Business', tags: ['Startups', 'Lagos'], cover: 'golden-hour',
    status: 'published', daysAgo: 20, featured: false,
    excerpt: 'Power, payments and patience: notes from shipping a small product to real customers.',
    html: p(
      'We thought the hard part would be the code. It was everything else: getting paid, staying online during outages, and explaining the product in one sentence.',
      '<h2>Plan for the network you have</h2>',
      'Pages must load on slow connections. We cut our home page to under 100 KB and sign-ups went up.',
      '<h2>Make payment boring</h2>',
      'Use a trusted payment provider. Never store card numbers yourself.',
      '<h2>Talk to people</h2>',
      'Ten conversations taught us more than a month of analytics.'
    )
  },
  {
    title: 'A beginner\'s guide to Afrobeats production', author: 'author', category: 'Music', tags: ['Music', 'Beginners'], cover: 'violet-haze',
    status: 'published', daysAgo: 27, featured: false,
    excerpt: 'Log drums, shakers and space: the building blocks behind the sound filling dance floors worldwide.',
    html: p(
      'You do not need an expensive studio to start. A laptop, headphones and patience will take you a long way.',
      '<h2>Start with the groove</h2>',
      'Programme a simple kick and shaker pattern. Leave space. The groove lives in what you do not play.',
      '<h2>Add the bass and the log drum</h2>',
      'Keep the bass simple and let the log drum answer it.',
      'Most of all: finish songs. Ten finished rough songs teach more than one perfect loop.'
    )
  },
  {
    title: 'How AI is changing customer support', author: 'editor', category: 'AI', tags: ['AI', 'Opinion'], cover: 'ocean-mist',
    status: 'published', daysAgo: 6, featured: false,
    excerpt: 'Good assistants answer the easy questions instantly, and know when to hand over to a human.',
    html: p(
      'The best support teams we spoke to do not use AI to replace people. They use it to clear the queue of simple questions so humans can focus on the hard ones.',
      '<h2>What works</h2>',
      '<ul><li>Answering common questions from your own help articles.</li><li>Drafting replies for an agent to check.</li><li>Summarising long conversations.</li></ul>',
      '<h2>What to watch</h2>',
      'Never let an assistant promise refunds or share personal data. Keep a clear path to a person.'
    )
  },
  {
    title: 'A weekend in Abeokuta', author: 'contributor', category: 'Travel', tags: ['Travel', 'Nigeria'], cover: 'deep-forest',
    status: 'published', daysAgo: 33, featured: false,
    excerpt: 'Olumo Rock at sunrise, adire markets and amala worth the trip.',
    html: p(
      'Ninety minutes from Lagos, if the road is kind. Abeokuta is the kind of town that rewards slowing down.',
      '<h2>Olumo Rock</h2>',
      'Go early. The climb is easier before the sun is high, and the view over the city is worth every step.',
      '<h2>Adire at Itoku market</h2>',
      'Watch the dyers work, then buy directly from them. Ask about the patterns; every one has a name.'
    )
  },
  {
    title: 'Writing headlines people actually click', author: 'editor', category: 'Lifestyle', tags: ['Writing', 'Tutorials'], cover: 'coral-reef',
    status: 'published', daysAgo: 12, featured: false,
    excerpt: 'Clear beats clever. Specific beats vague. And the SEO title does not have to match the headline.',
    html: p(
      'A headline has one job: help the right reader decide to read. Clever headlines often fail at that job.',
      '<h2>Be specific</h2>',
      '“Ten habits that keep your web app secure” tells you exactly what you will get.',
      '<h2>Use the SEO fields</h2>',
      'In the editor, the meta title and description control what search engines show. Keep the meta title under 60 characters and the description under 160.'
    )
  },
  {
    title: 'Coming soon: our December reading list', author: 'editor', category: 'Culture', tags: ['Announcements'], cover: 'ember',
    status: 'published', daysAgo: -5, featured: false,
    excerpt: 'Twelve books by Nigerian writers to close out the year.',
    html: p('This post is scheduled. It will appear on the site automatically on its publish date.')
  },
  {
    title: 'My favourite street foods in Surulere', author: 'contributor', category: 'Food', tags: ['Food', 'Lagos'], cover: 'mint-paper',
    status: 'review', daysAgo: null, featured: false,
    excerpt: 'Suya, boli and the best puff-puff on Bode Thomas.',
    html: p('A draft submitted for review by a contributor. An editor can publish it from the dashboard.', 'Suya first, always. Then boli with groundnut. Then, if there is room, puff-puff.')
  },
  {
    title: 'Notes on password managers', author: 'author', category: 'Security', tags: ['Security'], cover: 'green-signal',
    status: 'draft', daysAgo: null, featured: false,
    excerpt: 'Why one strong master password beats fifty weak ones.',
    html: p('Draft in progress. Only the author and editors can see this.')
  },
  {
    title: 'Our 2025 roadmap (archived)', author: 'admin', category: 'Business', tags: ['Announcements'], cover: 'indigo-wave',
    status: 'archived', daysAgo: 300, featured: false,
    excerpt: 'Last year\'s plans, kept for the record.',
    html: p('This post is archived. It no longer appears on the public site.')
  }
];

module.exports.comments = [
  { post: 'Ten habits that keep your web app secure', user: 'reader', body: 'Number 5 is the one I keep forgetting. Thanks for the reminder!', status: 'approved' },
  { post: 'Ten habits that keep your web app secure', user: 'reader2', body: 'Could you write a follow-up on CSRF tokens with an example?', status: 'approved' },
  { post: 'The joy of a Saturday morning in Yaba', user: 'reader', body: 'I know exactly which akara woman you mean. Best in Lagos.', status: 'approved' },
  { post: 'How AI is changing customer support', user: 'reader2', body: 'Totally agree about keeping a path to a real person.', status: 'pending' },
  { post: 'Welcome to Blog.x', user: 'reader2', body: 'Cheap followers!!! visit my site now', status: 'spam' }
];

module.exports.subscribers = [
  ['reader@blogx.test', 'Ngozi Eze'], ['ada.n@example.com', 'Ada Nwosu'], ['tunde@example.com', 'Tunde Bakare'],
  ['zainab@example.com', 'Zainab Musa'], ['kola@example.com', 'Kola Ajayi'], ['ifeoma@example.com', 'Ifeoma Obi'],
  ['seun@example.com', null], ['old.reader@example.com', 'Old Reader', 'unsubscribed']
];
