/**
 * AUTHENTICATION + ACCESS CONTROL middleware.
 * SECURITY: these run on the SERVER before protected routes. Hiding links is not protection;
 * a reader who types /admin into the address bar is stopped here.
 */
const Users = require('../models/users');
const { can, ROLE_LABELS } = require('../permissions');

/** Load the user from the DATABASE on every request, so role changes and suspensions apply instantly. */
function loadUser(req, res, next) {
  req.user = null;
  if (!req.session.userId) return next();
  const user = Users.findById(req.session.userId);
  if (!user || user.status !== 'active') {
    return req.session.regenerate(() => next()); // deleted or suspended → logged out immediately
  }
  req.user = user;
  res.locals.currentUser = user;
  res.locals.roleLabel = ROLE_LABELS[user.role];
  next();
}

/** Only allow redirects to paths on THIS site (stops "open redirect" phishing links). */
function safeNext(value) {
  return typeof value === 'string' && /^\/(?!\/)[\w\-/?=&.%]*$/.test(value) && !value.includes('\\') ? value : null;
}

function denied(message = 'You do not have permission to do that.') {
  const err = new Error('Forbidden');
  err.status = 403;
  err.publicMessage = message;
  return err;
}

function requireLogin(req, res, next) {
  if (req.user) return next();
  req.session.flash = { type: 'error', message: 'Please sign in to continue.' };
  const back = req.method === 'GET' ? `?next=${encodeURIComponent(req.originalUrl)}` : '';
  res.redirect('/signin' + back);
}

/** Factory: requirePermission('users.manage') */
function requirePermission(permission) {
  return (req, res, next) => {
    if (!req.user) return requireLogin(req, res, next);
    if (can(req.user, permission)) return next();
    return next(denied());
  };
}

function requireGuest(req, res, next) {
  if (req.user) return res.redirect(can(req.user, 'admin.access') ? '/admin' : '/account');
  next();
}

/**
 * Accounts created by an admin get a temporary password. Until the owner sets their own,
 * every page except "change password" and "sign out" redirects them there.
 */
function enforcePasswordChange(req, res, next) {
  if (!req.user || !req.user.must_change_password) return next();
  if (req.path === '/account/password' || req.path === '/signout' || req.path.startsWith('/css/') || req.path === '/theme.css') return next();
  if (req.method !== 'GET') return next(denied('Please set a new password first.'));
  res.redirect('/account/password');
}

module.exports = { loadUser, requireLogin, requirePermission, requireGuest, enforcePasswordChange, safeNext, denied };
