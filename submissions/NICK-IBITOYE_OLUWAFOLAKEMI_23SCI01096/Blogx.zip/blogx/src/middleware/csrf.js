/**
 * CSRF PROTECTION (Synchronizer Token Pattern)
 *
 * The attack: while you are logged in, a malicious website secretly submits a form to
 * our site (e.g. "change my email"). Your browser attaches your session cookie, so
 * without protection the server would think YOU sent it.
 *
 * The defence: every session gets a long random secret token. Every form we render
 * includes it as a hidden field (<input name="_csrf">). Every state-changing request
 * (POST/PUT/PATCH/DELETE) must send it back, and it must match. Another website cannot
 * read our pages, so it can never know the token, so its forged request is rejected.
 * (SameSite cookies, set in app.js, are a second layer of defence.)
 */
const crypto = require('crypto');
const logger = require('../utils/logger');

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);
// Routes that receive file uploads (multipart forms). Their body is only readable after
// multer runs, so those routes call verifyCsrf themselves straight after parsing.
const MULTIPART_ROUTES = [/^\/admin\/media$/, /^\/admin\/media\/upload\.json$/];

function ensureToken(req) {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  return req.session.csrfToken;
}

function tokensMatch(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  // Constant-time comparison so the token cannot be guessed character by character from timing.
  return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
}

function verifyCsrf(req, res, next) {
  const sent = (req.body && req.body._csrf) || req.get('x-csrf-token');
  if (tokensMatch(sent, req.session.csrfToken)) return next();
  logger.warn('CSRF token rejected', { method: req.method, path: req.path, ip: req.ip });
  const err = new Error('Invalid or missing CSRF token');
  err.status = 403;
  err.csrf = true;
  err.publicMessage = 'Your session form expired or the request could not be verified. Please go back, refresh the page and try again.';
  return next(err);
}

/** Global middleware: exposes the token to every view and checks it on every unsafe request. */
function csrfProtection(req, res, next) {
  res.locals.csrfToken = ensureToken(req);
  if (SAFE_METHODS.has(req.method)) return next();
  if (req.is('multipart/form-data')) {
    if (MULTIPART_ROUTES.some((re) => re.test(req.path))) return next(); // route verifies after upload parsing
    return verifyCsrf(req, res, next); // body not parsed → token missing → rejected
  }
  return verifyCsrf(req, res, next);
}

module.exports = { csrfProtection, verifyCsrf, ensureToken };
