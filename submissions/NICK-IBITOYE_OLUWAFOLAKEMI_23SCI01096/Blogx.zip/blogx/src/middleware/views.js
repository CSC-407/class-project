/**
 * Count a post view — at most once per browser session per post, never for bots,
 * and never for the post's own staff (so writers don't inflate their own numbers).
 */
const Stats = require('../models/stats');

const BOT_RE = /bot|crawl|spider|slurp|facebookexternalhit|preview|headless|curl|wget|python-requests/i;

function trackView(req, post) {
  if (BOT_RE.test(req.get('user-agent') || '')) return false;
  if (req.user && req.user.id === post.author_id) return false;
  const seen = req.session.viewed || [];
  if (seen.includes(post.id)) return false;
  // Remember the last 50 posts viewed in this session (keeps the session small)
  req.session.viewed = [...seen, post.id].slice(-50);
  Stats.recordView(post.id);
  return true;
}

module.exports = { trackView, BOT_RE };
