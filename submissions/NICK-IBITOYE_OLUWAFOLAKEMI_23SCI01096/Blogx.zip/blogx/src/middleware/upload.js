/**
 * SECURE IMAGE UPLOADS (media library)
 *  1. Max 3 MB, one file per request; the file is held in memory until every check passes.
 *  2. The real type is read from the file's first bytes ("magic numbers"): JPEG, PNG, WebP or GIF only.
 *     The file name and the browser's claimed type are ignored because both can be faked.
 *     SVG is refused: SVG files can contain JavaScript.
 *  3. Saved under a random 32-character name we choose, so "../../" path tricks are impossible.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const config = require('../config');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: config.maxUploadBytes, files: 1, fields: 10 } });

const MIME = { jpg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif' };

function detectImageType(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (buf.subarray(0, 4).toString('ascii') === 'RIFF' && buf.subarray(8, 12).toString('ascii') === 'WEBP') return 'webp';
  const head = buf.subarray(0, 6).toString('ascii');
  if (head === 'GIF87a' || head === 'GIF89a') return 'gif';
  return null;
}

/** Validate + write the file. Returns { path, mime, size, originalName } or { error }. */
function saveImage(file) {
  if (!file) return { error: 'Please choose an image to upload.' };
  const ext = detectImageType(file.buffer);
  if (!ext) return { error: 'Please upload a real JPG, PNG, WebP or GIF image.' };
  fs.mkdirSync(config.uploadDir, { recursive: true });
  const name = crypto.randomBytes(16).toString('hex') + '.' + ext;
  fs.writeFileSync(path.join(config.uploadDir, name), file.buffer);
  const originalName = String(file.originalname || 'image').replace(/[^\w.\- ]/g, '').slice(0, 100) || 'image';
  return { path: '/uploads/' + name, mime: MIME[ext], size: file.size, originalName };
}

function deleteFile(publicPath) {
  if (typeof publicPath !== 'string' || !/^\/uploads\/[a-f0-9]{32}\.(jpg|png|webp|gif)$/.test(publicPath)) return;
  fs.rm(path.join(config.uploadDir, path.basename(publicPath)), { force: true }, () => {});
}

module.exports = { upload, detectImageType, saveImage, deleteFile };
