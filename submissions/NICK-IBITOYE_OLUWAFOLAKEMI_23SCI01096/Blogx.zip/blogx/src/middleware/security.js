/**
 * SECURITY HEADERS + RATE LIMITING
 */
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const config = require('../config');
const logger = require('../utils/logger');

/**
 * Helmet sets HTTP response headers that tell the browser to behave safely:
 *  - Content-Security-Policy (CSP): only run scripts/styles/images from OUR site.
 *    Even if an attacker managed to inject <script>, the browser would refuse to run it
 *    because inline scripts are not allowed (no 'unsafe-inline'). Second layer vs XSS.
 *  - X-Frame-Options / frame-ancestors 'none': our pages cannot be put in an invisible
 *    <iframe> on another site (stops clickjacking).
 *  - X-Content-Type-Options: nosniff — browser must trust our declared file types.
 *  - Strict-Transport-Security (production): browser must always use HTTPS.
 *  - Referrer-Policy: do not leak full URLs to other sites.
 *  - Removes X-Powered-By so attackers are not told we use Express.
 */
function securityHeaders() {
  return helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        imgSrc: ["'self'", 'data:'],
        mediaSrc: ["'none'"],
        fontSrc: ["'self'"],
        connectSrc: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        // Only upgrade to HTTPS in production (local http://localhost must keep working).
        ...(config.isProd ? { upgradeInsecureRequests: [] } : {})
      }
    },
    strictTransportSecurity: config.isProd ? { maxAge: 31536000, includeSubDomains: true } : false,
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    crossOriginEmbedderPolicy: false
  });
}

/**
 * Login rate limiter (per IP address): after LOGIN_RATE_LIMIT attempts in 15 minutes,
 * further login attempts from that address are refused with HTTP 429.
 * Works together with the per-ACCOUNT lockout in routes/auth.js:
 *   - rate limit stops one computer guessing many accounts' passwords
 *   - lockout stops many computers guessing one account's password
 */
function loginLimiter(limit = config.loginRateLimit) {
  return rateLimit({
    windowMs: 15 * 60 * 1000,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    skipSuccessfulRequests: true, // only failed logins count
    handler: (req, res) => {
      logger.warn('Login rate limit hit', { ip: req.ip });
      res.status(429).render('auth/signin', {
        title: 'Sign in',
        values: { email: '' },
        errors: {},
        next: null,
        flash: { type: 'error', message: 'Too many sign-in attempts from your network. Please wait 15 minutes and try again.' }
      });
    }
  });
}

/** A gentler limit for registration and order tracking (stops bots spamming accounts/guessing references). */
function formLimiter(limit = 30) {
  return rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: config.isTest ? 1000 : limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (req, res, next) => {
      const err = new Error('Rate limited');
      err.status = 429;
      err.publicMessage = 'Too many requests. Please wait a few minutes and try again.';
      next(err);
    }
  });
}

module.exports = { securityHeaders, loginLimiter, formLimiter };
