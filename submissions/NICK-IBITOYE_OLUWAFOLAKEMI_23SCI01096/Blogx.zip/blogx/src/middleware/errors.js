/**
 * ERROR HANDLING
 * SECURITY: visitors only ever see a short, friendly message. Real details (stack traces,
 * SQL, file paths) go to the server log, because they help attackers map the system.
 */
const logger = require('../utils/logger');

function notFound(req, res, next) {
  const err = new Error('Not found');
  err.status = 404;
  err.publicMessage = "We couldn't find that page. It may have been moved, unpublished or never existed.";
  next(err);
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err.code === 'LIMIT_FILE_SIZE') {
    err.status = 400;
    err.publicMessage = 'That file is too large. The maximum size is 3 MB.';
  }
  if (err.type === 'entity.too.large') err.publicMessage = 'That request was too large.';
  const status = err.status || err.statusCode || 500;
  if (status >= 500) logger.error('Unhandled error', { message: err.message, stack: err.stack, method: req.method, path: req.path });
  else if (status !== 404) logger.warn('Request refused', { status, message: err.message, path: req.path, ip: req.ip });

  const titles = { 400: 'Bad request', 403: 'Access denied', 404: 'Page not found', 413: 'Too large', 429: 'Slow down' };
  const title = titles[status] || 'Something went wrong';
  const message = err.publicMessage || 'Something went wrong on our side. Please try again in a moment.';

  if (req.path.endsWith('.json')) return res.status(status).json({ error: message });
  res.status(status).render('error', { title, status, message }, (renderErr, html) => {
    if (!renderErr) return res.send(html);
    // Never fall back to Express's default page (it prints a stack trace).
    logger.error('Error page failed to render', { message: renderErr.message, stack: renderErr.stack });
    res.type('html').send(`<!doctype html><meta charset="utf-8"><title>${title}</title><h1>${title}</h1><p>${message}</p><p><a href="/">Home</a></p>`);
  });
}

module.exports = { notFound, errorHandler };
