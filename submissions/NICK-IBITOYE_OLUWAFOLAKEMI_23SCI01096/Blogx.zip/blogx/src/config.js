/**
 * Blog.x configuration.
 * SECURITY: secrets come only from environment variables (a .env file locally, the host's
 * dashboard in production). The .env file is git-ignored and never committed.
 */
const path = require('path');
require('dotenv').config({ quiet: true });

const env = process.env.NODE_ENV || 'development';
const isProd = env === 'production';
const isTest = env === 'test';

// SECURITY: refuse to start in production with a missing, short or placeholder secret.
const sessionSecret = process.env.SESSION_SECRET || (isProd ? '' : 'dev-only-secret-not-for-production');
if (isProd && (sessionSecret.length < 32 || sessionSecret.startsWith('replace-with'))) {
  throw new Error('SESSION_SECRET must be set to 32+ random characters in production.');
}

const root = path.join(__dirname, '..');
const num = (v, d) => (Number.isFinite(parseInt(v, 10)) ? parseInt(v, 10) : d);

module.exports = {
  env,
  isProd,
  isTest,
  root,
  port: num(process.env.PORT, 3000),
  sessionSecret,
  sessionMinutes: isTest ? 120 : num(process.env.SESSION_MINUTES, 120),
  dbFile: isTest ? ':memory:' : path.resolve(root, process.env.DB_FILE || 'data/blogx.db'),
  // Uploaded images. Can point to a persistent disk in production (e.g. /var/data/uploads); served at /uploads.
  uploadDir: isTest ? path.join(root, 'public', 'uploads') : path.resolve(root, process.env.UPLOAD_DIR || 'public/uploads'),
  logDir: path.join(root, 'logs'),
  maxUploadBytes: 3 * 1024 * 1024,
  // In tests these are fixed, so a developer's .env can never change the test results.
  loginMaxAttempts: isTest ? 5 : num(process.env.LOGIN_MAX_ATTEMPTS, 5),
  lockoutMinutes: isTest ? 15 : num(process.env.LOCKOUT_MINUTES, 15),
  loginRateLimit: isTest ? 1000 : num(process.env.LOGIN_RATE_LIMIT, 10),
  bcryptRounds: isTest ? 4 : 12,
  trustProxy: process.env.TRUST_PROXY === 'true',
  siteUrl: (process.env.SITE_URL || 'http://localhost:3000').replace(/\/+$/, '')
};
