/**
 * Blog.x — shared browser behaviour (public site and admin).
 *
 * CLIENT-SIDE VALIDATION here is for quick, friendly feedback only. It can be switched off,
 * so the server validates everything again (src/utils/validators.js).
 * Loaded from our own domain: the Content Security Policy forbids inline scripts.
 */
(function () {
  'use strict';

  // ---------- Toggle menus (mobile site nav, admin sidebar) ----------
  document.querySelectorAll('[data-toggle]').forEach(function (btn) {
    var target = document.getElementById(btn.getAttribute('data-toggle'));
    if (!target) return;
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      var open = target.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', String(open));
    });
    document.addEventListener('click', function (e) {
      if (target.classList.contains('is-open') && !target.contains(e.target)) {
        target.classList.remove('is-open');
        btn.setAttribute('aria-expanded', 'false');
      }
    });
  });

  // Close the account dropdown when clicking elsewhere
  document.addEventListener('click', function (e) {
    document.querySelectorAll('details.user-menu[open]').forEach(function (d) { if (!d.contains(e.target)) d.removeAttribute('open'); });
  });

  // ---------- Dismiss flash messages ----------
  document.querySelectorAll('[data-dismiss]').forEach(function (b) {
    b.addEventListener('click', function () { b.closest('.flash').remove(); });
  });

  // ---------- Confirm destructive actions ----------
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!window.confirm(form.getAttribute('data-confirm'))) e.preventDefault();
    });
  });

  // ---------- Character counters ----------
  document.querySelectorAll('[data-counter]').forEach(function (field) {
    var max = Number(field.getAttribute('data-recommended') || field.getAttribute('maxlength'));
    if (!max) return;
    var out = document.createElement('span');
    out.className = 'counter';
    field.insertAdjacentElement('afterend', out);
    var update = function () {
      var n = field.value.length;
      out.textContent = n + ' / ' + max;
      out.classList.toggle('over', n > max);
    };
    field.addEventListener('input', update);
    update();
  });

  // ---------- Colour picker <-> text field ----------
  document.querySelectorAll('[data-color-sync]').forEach(function (picker) {
    var text = document.getElementById(picker.getAttribute('data-color-sync'));
    picker.addEventListener('input', function () { text.value = picker.value; });
    text.addEventListener('input', function () { if (/^#[0-9a-f]{6}$/i.test(text.value)) picker.value = text.value; });
  });

  // ---------- Password strength meter ----------
  document.querySelectorAll('[data-strength]').forEach(function (input) {
    var meter = document.createElement('div');
    meter.className = 'strength';
    meter.setAttribute('aria-hidden', 'true');
    meter.appendChild(document.createElement('span'));
    input.insertAdjacentElement('afterend', meter);
    input.addEventListener('input', function () {
      var v = input.value, s = 0;
      if (v.length >= 10) s++;
      if (/[a-z]/.test(v) && /[A-Z]/.test(v)) s++;
      if (/\d/.test(v)) s++;
      if (v.length >= 14 || /[^A-Za-z0-9]/.test(v)) s++;
      meter.className = 'strength' + (v ? ' s' + s : '');
    });
  });

  // ---------- Form validation ----------
  var NAME_RE = /^[\p{L}][\p{L}\s.'-]*$/u;
  var EMAIL_RE = /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[a-z]{2,}$/i;

  function labelFor(field, form) {
    var l = form.querySelector('label[for="' + field.id + '"]');
    return l ? l.textContent.replace(/\(.*?\)/g, '').trim() : 'This field';
  }

  /** Returns an error message, or '' when the field is valid. */
  function check(field, form) {
    if (field.type === 'checkbox') return field.required && !field.checked ? 'Please tick this box to continue.' : '';
    if (field.type === 'file') {
      var max = Number(field.getAttribute('data-max-bytes'));
      if (field.required && !field.files.length) return 'Please choose a file.';
      if (field.files.length && max && field.files[0].size > max) return 'That file is too large (maximum ' + Math.round(max / 1048576) + ' MB).';
      if (field.files.length && !/^image\/(jpeg|png|webp|gif)$/.test(field.files[0].type)) return 'Please choose a JPG, PNG, WebP or GIF image.';
      return '';
    }
    var v = field.value.trim();
    var label = labelFor(field, form);
    if (!v) return field.required ? label + ' is required.' : '';
    if (field.minLength > 0 && v.length < field.minLength) return label + ' must be at least ' + field.minLength + ' characters.';
    if (field.type === 'email' && !EMAIL_RE.test(v)) return 'Please enter a valid email address.';
    if (field.type === 'url' && !/^https?:\/\/[^\s]+\.[^\s]+/i.test(v)) return label + ' must start with https://';
    if (field.hasAttribute('data-name') && !NAME_RE.test(v)) return 'Use letters, spaces, hyphens and apostrophes only.';
    if (field.pattern && !new RegExp('^(?:' + field.pattern + ')$').test(v)) return field.getAttribute('data-pattern-message') || label + ' is not in the right format.';
    if (field.type === 'number') {
      var n = Number(v);
      if (!Number.isFinite(n)) return label + ' must be a number.';
      if (field.min !== '' && n < Number(field.min)) return label + ' must be at least ' + field.min + '.';
      if (field.max !== '' && n > Number(field.max)) return label + ' must be at most ' + field.max + '.';
    }
    if (field.hasAttribute('data-strength') && (v.length < 10 || !/[a-z]/.test(v) || !/[A-Z]/.test(v) || !/\d/.test(v))) {
      return 'Use at least 10 characters with an uppercase letter, a lowercase letter and a number.';
    }
    var match = field.getAttribute('data-match');
    if (match && v !== form.querySelector('[name="' + match + '"]').value.trim()) return 'Passwords do not match.';
    return '';
  }

  function show(field, message) {
    var box = field.closest('.field') || field.parentElement;
    var el = box.querySelector('.js-error');
    var serverMsg = box.classList.contains('field') && box.querySelector('.field-error:not(.js-error)');
    if (serverMsg) serverMsg.hidden = true;
    if (message) {
      if (!el) {
        el = document.createElement('p');
        el.className = 'field-error js-error';
        el.setAttribute('role', 'alert');
        box.appendChild(el);
      }
      el.textContent = message; // textContent, never innerHTML → no XSS
      field.setAttribute('aria-invalid', 'true');
      box.classList.add('has-error');
    } else {
      if (el) el.remove();
      field.removeAttribute('aria-invalid');
      box.classList.remove('has-error');
    }
  }

  document.querySelectorAll('form[data-validate]').forEach(function (form) {
    var fields = function () {
      return Array.prototype.filter.call(form.querySelectorAll('input, select, textarea'), function (f) {
        return f.type !== 'hidden' && f.type !== 'submit' && f.type !== 'color' && !f.closest('.hp') && !f.closest('[hidden]');
      });
    };
    fields().forEach(function (f) {
      f.addEventListener('blur', function () { show(f, check(f, form)); });
      if (f.type === 'checkbox' || f.type === 'file') f.addEventListener('change', function () { show(f, check(f, form)); });
    });
    form.addEventListener('submit', function (e) {
      var first = null;
      fields().forEach(function (f) {
        var msg = check(f, form);
        show(f, msg);
        if (msg && !first) first = f;
      });
      if (first) {
        e.preventDefault();
        first.focus();
      } else {
        var btn = form.querySelector('button[type="submit"]');
        if (btn) setTimeout(function () { btn.disabled = true; }, 0); // prevent double submits
      }
    });
  });
})();
