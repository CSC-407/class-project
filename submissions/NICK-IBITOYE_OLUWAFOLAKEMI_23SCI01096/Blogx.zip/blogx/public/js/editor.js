/**
 * Blog.x rich-text post editor.
 *
 * Turns the plain HTML <textarea> into a WYSIWYG area (contenteditable) with a formatting
 * toolbar, an image picker/uploader, live SEO preview and autosaving of the slug.
 * Without JavaScript the textarea still works, so nothing depends on this file.
 *
 * SECURITY NOTES
 *  - Whatever HTML this editor produces is treated as UNTRUSTED by the server and cleaned with
 *    an allow-list before saving (src/utils/sanitize.js). This file is a convenience, not a defence.
 *  - Pasted content is inserted as plain text (no foreign styles or scripts).
 *  - Image uploads send the CSRF token in an X-CSRF-Token header.
 *  - Text from the server (image names, alt text) is placed into the page with textContent /
 *    element properties, never by building HTML strings.
 */
(function () {
  'use strict';

  var form = document.getElementById('post-form');
  if (!form) return;
  var csrf = form.querySelector('input[name="_csrf"]').value;
  var source = form.querySelector('[data-source]');
  var editor = form.querySelector('[data-editor]');
  var toolbar = form.querySelector('[data-toolbar]');
  var dirty = false;

  // ---------- Switch from the HTML textarea to the visual editor ----------
  editor.innerHTML = source.value; // server-sanitized HTML
  editor.contentEditable = 'true';
  editor.hidden = false;
  toolbar.hidden = false;
  source.hidden = true;
  try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) { /* older browsers */ }
  if (!editor.textContent.trim() && !editor.querySelector('img')) editor.innerHTML = '';

  // Make sure typing always happens inside a paragraph, even in an empty post.
  editor.addEventListener('focus', function () {
    if (editor.innerHTML.trim() === '') {
      editor.innerHTML = '<p><br></p>';
      var r = document.createRange();
      r.setStart(editor.firstChild, 0);
      r.collapse(true);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(r);
    }
  });

  function sync() {
    // Browsers sometimes turn /uploads/x.jpg into http://host/uploads/x.jpg while editing; store the short path.
    editor.querySelectorAll('img').forEach(function (img) {
      var src = img.getAttribute('src') || '';
      try { var u = new URL(src, location.href); if (u.origin === location.origin) img.setAttribute('src', u.pathname); } catch (e) { /* leave it */ }
    });
    source.value = editor.innerHTML;
  }

  // ---------- Toolbar ----------
  function safeLink(url) {
    url = String(url || '').trim();
    if (/^(https?:\/\/|mailto:|\/(?!\/))/i.test(url)) return url;
    if (/^[\w.-]+\.[a-z]{2,}(\/|$)/i.test(url)) return 'https://' + url;
    return null; // javascript:, data: … refused here and also removed by the server
  }

  function escapeText(text) {
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  toolbar.addEventListener('mousedown', function (e) { if (e.target.closest('button')) e.preventDefault(); }); // keep the selection
  toolbar.addEventListener('click', function (e) {
    var btn = e.target.closest('button[data-cmd]');
    if (!btn) return;
    editor.focus();
    var cmd = btn.getAttribute('data-cmd');
    if (cmd === 'link') {
      var url = safeLink(window.prompt('Link address (https://…)', 'https://'));
      if (url) document.execCommand('createLink', false, url);
      else if (url === null) return;
    } else if (cmd === 'code') {
      var text = window.getSelection().toString();
      if (text) document.execCommand('insertHTML', false, '<code>' + escapeText(text) + '</code>');
    } else if (cmd === 'formatBlock') {
      document.execCommand('formatBlock', false, '<' + btn.getAttribute('data-arg') + '>');
    } else {
      document.execCommand(cmd, false, null);
    }
    dirty = true;
    updateCounts();
  });

  // Paste as plain text: keeps posts clean and drops anything hidden in copied HTML.
  editor.addEventListener('paste', function (e) {
    e.preventDefault();
    var text = (e.clipboardData || window.clipboardData).getData('text/plain');
    document.execCommand('insertText', false, text);
  });
  editor.addEventListener('drop', function (e) { e.preventDefault(); }); // use the image button instead
  editor.addEventListener('input', function () { dirty = true; updateCounts(); });

  var wordcount = form.querySelector('[data-wordcount]');
  function updateCounts() {
    var words = (editor.innerText || '').split(/\s+/).filter(Boolean).length;
    wordcount.textContent = words + ' words · about ' + Math.max(1, Math.round(words / 230)) + ' min read';
  }
  updateCounts();

  // ---------- Title, slug and SEO preview ----------
  var title = form.querySelector('#title');
  var slug = form.querySelector('[data-slug]');
  var slugTouched = !!slug.value;
  var metaTitle = form.querySelector('#metaTitle');
  var metaDesc = form.querySelector('#metaDescription');
  var excerpt = form.querySelector('#excerpt');

  function slugify(t) {
    return t.toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
  }
  function autogrow() { title.style.height = 'auto'; title.style.height = title.scrollHeight + 'px'; }
  function preview() {
    form.querySelector('[data-seo-title]').textContent = metaTitle.value || title.value || 'Post title';
    form.querySelector('[data-seo-desc]').textContent = metaDesc.value || excerpt.value || 'A short description of the post appears here in search results.';
    form.querySelector('[data-seo-slug]').textContent = slug.value || slugify(title.value) || 'your-post';
  }
  title.addEventListener('input', function () {
    if (!slugTouched) slug.value = slugify(title.value);
    autogrow(); preview(); dirty = true;
  });
  title.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); editor.focus(); } });
  slug.addEventListener('input', function () { slugTouched = true; preview(); });
  [metaTitle, metaDesc, excerpt].forEach(function (f) { f.addEventListener('input', function () { preview(); dirty = true; }); });
  autogrow();

  // ---------- Status → publish date field & button label ----------
  var status = form.querySelector('[data-status]');
  var publishAt = form.querySelector('[data-publish-at]');
  var saveBtn = form.querySelector('[data-save-label]');
  function statusChanged() {
    if (publishAt) publishAt.hidden = status.value !== 'published';
    saveBtn.textContent = { draft: 'Save draft', review: 'Submit for review', published: 'Publish', archived: 'Archive' }[status.value] || 'Save';
  }
  status.addEventListener('change', function () { statusChanged(); dirty = true; });
  statusChanged();

  // ---------- Settings panel toggle ----------
  var toggle = form.querySelector('[data-toggle-settings]');
  toggle.addEventListener('click', function () {
    var closed = form.classList.toggle('settings-closed');
    toggle.setAttribute('aria-expanded', String(!closed));
  });

  // ---------- Save: copy the editor's HTML into the form field ----------
  form.addEventListener('submit', function () { sync(); dirty = false; });
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); form.requestSubmit(); }
  });
  window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });
  form.querySelectorAll('input, select, textarea').forEach(function (f) { f.addEventListener('change', function () { dirty = true; }); });

  // ---------- Media picker ----------
  var dialog = document.querySelector('[data-media-dialog]');
  var grid = dialog.querySelector('[data-media-grid]');
  var covers = dialog.querySelector('.media-dialog-covers');
  var message = dialog.querySelector('[data-dialog-message]');
  var featureInput = form.querySelector('[data-feature-input]');
  var featurePreview = form.querySelector('[data-feature-preview]');
  var removeFeature = form.querySelector('[data-remove-feature]');
  var mode = 'feature';
  var savedRange = null;

  function tile(item) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'media-tile';
    b.setAttribute('data-choose', item.path);
    b.setAttribute('data-alt', item.alt || '');
    b.title = item.name;
    var img = document.createElement('img');
    img.src = item.path;
    img.alt = item.alt || item.name;
    img.loading = 'lazy';
    b.appendChild(img);
    return b;
  }

  function loadLibrary() {
    grid.textContent = 'Loading…';
    fetch('/admin/media/library.json', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (items) {
        grid.textContent = '';
        if (!items.length) { var p = document.createElement('p'); p.className = 'muted small'; p.textContent = 'No uploads yet. Upload one above.'; grid.appendChild(p); }
        items.forEach(function (i) { grid.appendChild(tile(i)); });
      })
      .catch(function () { grid.textContent = 'Could not load the media library.'; });
  }

  function openPicker(m) {
    mode = m;
    var sel = window.getSelection();
    savedRange = m === 'inline' && sel.rangeCount && editor.contains(sel.anchorNode) ? sel.getRangeAt(0).cloneRange() : null;
    covers.hidden = m === 'inline'; // built-in covers are for feature images only
    message.textContent = 'JPG, PNG, WebP or GIF, up to 3 MB.';
    loadLibrary();
    dialog.showModal();
  }

  function choose(path, alt) {
    if (mode === 'feature') {
      featureInput.value = path;
      featurePreview.src = path;
      featurePreview.hidden = false;
      removeFeature.hidden = false;
      dialog.close();
    } else {
      // Close the (modal) dialog FIRST: while it is open the editor behind it can't take focus.
      dialog.close();
      editor.focus();
      if (savedRange) { var s = window.getSelection(); s.removeAllRanges(); s.addRange(savedRange); }
      var img = document.createElement('img');
      img.setAttribute('src', path);
      img.setAttribute('alt', alt || '');
      document.execCommand('insertHTML', false, img.outerHTML);
      updateCounts();
    }
    dirty = true;
  }

  form.addEventListener('click', function (e) {
    var pick = e.target.closest('[data-pick]');
    if (pick) { e.preventDefault(); openPicker(pick.getAttribute('data-pick')); }
  });
  removeFeature.addEventListener('click', function () {
    featureInput.value = '';
    featurePreview.hidden = true;
    removeFeature.hidden = true;
    dirty = true;
  });
  dialog.addEventListener('click', function (e) {
    var t = e.target.closest('[data-choose]');
    if (t) choose(t.getAttribute('data-choose'), t.getAttribute('data-alt'));
    if (e.target.closest('[data-close-dialog]') || e.target === dialog) dialog.close();
  });

  dialog.querySelector('[data-dialog-upload]').addEventListener('change', function (e) {
    var file = e.target.files[0];
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) { message.textContent = 'That image is too large (maximum 3 MB).'; return; }
    if (!/^image\/(jpeg|png|webp|gif)$/.test(file.type)) { message.textContent = 'Please choose a JPG, PNG, WebP or GIF image.'; return; }
    var data = new FormData();
    data.append('file', file);
    message.textContent = 'Uploading…';
    fetch('/admin/media/upload.json', { method: 'POST', body: data, credentials: 'same-origin', headers: { 'X-CSRF-Token': csrf } })
      .then(function (r) { return r.json().then(function (j) { return { ok: r.ok, body: j }; }); })
      .then(function (res) {
        if (!res.ok) { message.textContent = res.body.error || 'Upload failed.'; return; }
        choose(res.body.path, res.body.alt);
      })
      .catch(function () { message.textContent = 'Upload failed. Check your connection.'; })
      .finally(function () { e.target.value = ''; });
  });
})();
