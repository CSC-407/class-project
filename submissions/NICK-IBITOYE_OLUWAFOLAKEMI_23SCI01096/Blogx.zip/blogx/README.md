# Blog.x

A secure blog management system in the style of [Ghost](https://ghost.org), built for a university project on **Web Application Security, Testing, Deployment and Review**.

**Stack:** Node.js 22+ · Express 5 · EJS · SQLite (better-sqlite3) · sanitize-html · bcryptjs · Helmet · express-session · express-rate-limit · Multer · Jest + Supertest

## What it does

| Component | Features |
|---|---|
| **Public site** | Home with featured post, post pages with reading time and related posts, category / sub-category / tag / author archives, search with filters and sorting, RSS feed, sitemap, robots.txt |
| **Content editor** | Rich-text editor (headings, bold, italic, quotes, lists, links, code, dividers, images), feature images, media library uploads, tags, categories, excerpt, URL slug, draft / review / scheduled / published / archived, SEO meta title & description with live Google preview, canonical URL, noindex |
| **Comments & readers** | Reader accounts, comments with three moderation modes, spam marking, newsletter subscriptions with one-click unsubscribe links, privacy-friendly view tracking |
| **Admin dashboard** | Views chart, top posts, review queue, moderation counts; manage posts, media, categories & sub-categories, tags, comments, subscribers (CSV export), users and roles, site settings (title, accent colour, posts per page, comments, sign-ups), audit log |
| **Roles** | Visitor · Reader · Contributor · Author · Editor · Administrator; each sees a different menu and dashboard |
| **Security** | See the in-app **Security** page (`/security`) or [docs/PROJECT_REVIEW.md](docs/PROJECT_REVIEW.md#3-security-measures-implemented) |

## Quick start

Requires **Node.js 22 or 24** (LTS) from [nodejs.org](https://nodejs.org). Stay online during `npm install`; it downloads a ready-made SQLite binary.

```bash
npm install
cp .env.example .env          # Windows PowerShell: Copy-Item .env.example .env
npm run db:reset              # fresh database with demo posts and accounts
npm run dev                   # http://localhost:3000   (Ctrl+C to stop)
```

### Demo accounts

| Role | Email | Password |
|---|---|---|
| Administrator | `admin@blogx.test` | `ChangeMe2026!` |
| Editor | `editor@blogx.test` | `EditorPass2026` |
| Author | `author@blogx.test` | `AuthorPass2026` |
| Contributor | `contributor@blogx.test` | `ContribPass2026` |
| Reader | `reader@blogx.test` | `ReaderPass2026` |

⚠️ **Change the admin password after the first sign-in:** avatar menu → Your account → Change password. For a live site, set `SEED_ADMIN_PASSWORD` in the environment before the first start.

## Scripts

| Command | Purpose |
|---|---|
| `npm run dev` | Start with auto-restart on code changes |
| `npm start` | Start normally (production) |
| `npm test` | Run all 184 automated tests |
| `npm run test:coverage` | Tests plus a coverage report in `coverage/` |
| `npm run db:migrate` | Create any missing tables (safe, keeps data) |
| `npm run db:seed` | Add demo users, categories, posts, comments and subscribers |
| `npm run db:reset` | Delete and rebuild the local database (development only) |
| `npm run db:backup` | Safe copy of the database to `backups/` |
| `npm run create-admin -- "Name" email@x.com` | Create or promote an administrator |

## Testing

```bash
npm test
```

Expected: `Test Suites: 10 passed` and `Tests: 184 passed`. Tests use an in-memory database and ignore your `.env`, so they never change your data.

The manual test plan (49 cases, all run and passed, with screenshots) is in [docs/TEST_PLAN.md](docs/TEST_PLAN.md).

## Deployment

Full guide: [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md). In short: push to GitHub (GitHub Actions runs the tests), then on [render.com](https://render.com) choose **New → Blueprint** and pick the repository. `render.yaml` configures everything and HTTPS is automatic.

## Project structure

```
blogx/
├── server.js                    Start-up (fills an empty database with demo content)
├── src/
│   ├── app.js                   Middleware order, sessions, theme.css, routes
│   ├── config.js                Settings from environment variables
│   ├── permissions.js           ★ All role rules in one place
│   ├── db/                      schema.sql, connection, migrate, seed, reset, demo content
│   ├── middleware/              auth, csrf, security (Helmet, rate limits), upload, views, errors
│   ├── models/                  users, posts, taxonomy, media, comments, subscribers, stats, settings, audit
│   ├── routes/                  public, auth, community, account
│   │   └── admin/               dashboard, posts (editor), media, taxonomy, community, users, settings
│   └── utils/                   validators, sanitize (HTML allow-list), csv, logger, helpers
├── views/                       EJS templates: site/, auth/, account/, admin/, partials/
├── public/                      css/ (site.css, admin.css), js/ (site.js, editor.js), images/, uploads/
├── tests/                       unit/ and integration/ (Jest + Supertest)
├── scripts/                     backup, create-admin, generate-covers.sh
├── docs/                        TEST_PLAN, DEPLOYMENT, PROJECT_REVIEW, PRESENTATION_NOTES, evidence/
├── .env.example                 Environment variable template (no real secrets)
├── render.yaml                  One-click Render deployment
└── .github/workflows/test.yml   CI: tests + npm audit on every push
```

## Documentation

- [docs/TEST_PLAN.md](docs/TEST_PLAN.md): test plan, 49 manual cases with results, how to run them
- [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md): environments, database, HTTPS, hosting, backups, logging, local demo
- [docs/PROJECT_REVIEW.md](docs/PROJECT_REVIEW.md): features, security, results, performance, problems, limitations, improvements
- [docs/PRESENTATION_NOTES.md](docs/PRESENTATION_NOTES.md): plain-English explanations and likely defence questions

All demo text was written for this project and the cover images are generated abstract artwork (`scripts/generate-covers.sh`), so there are no copyright issues. The visual style is inspired by Ghost; no Ghost code or assets are used.

## Troubleshooting

| Problem | Fix |
|---|---|
| `better-sqlite3` fails during `npm install` | Use Node 22 or 24 LTS (`node -v`) and stay online. Delete `node_modules` and run `npm install` again. |
| `EADDRINUSE :3000` | Another program uses port 3000. Set `PORT=3001` in `.env`. |
| "account is locked" | Wait 15 minutes, or run `npm run db:reset`. |
| "request could not be verified" | The page was open longer than your session. Refresh and try again. |
| The editor shows raw HTML | JavaScript is disabled or blocked. The HTML box still works and the server cleans whatever is submitted. |
