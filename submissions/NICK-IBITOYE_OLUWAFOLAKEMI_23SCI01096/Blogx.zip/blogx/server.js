/** Entry point: `npm start` (production) or `npm run dev` (auto-restarts while coding). */
const config = require('./src/config');
const createApp = require('./src/app');
const logger = require('./src/utils/logger');
const Users = require('./src/models/users');

// First run: an empty database is filled with demo content and accounts.
if (Users.count() === 0) require('./src/db/seed')();

const app = createApp();
const server = app.listen(config.port, () => logger.info('Blog.x is running', { url: `http://localhost:${config.port}`, env: config.env }));

process.on('unhandledRejection', (err) => logger.error('Unhandled promise rejection', { message: String(err && err.message), stack: err && err.stack }));
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception', { message: err.message, stack: err.stack });
  server.close(() => process.exit(1));
});
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => server.close(() => process.exit(0)));
