import csv
import io

from flask import Blueprint, Response, abort, flash, redirect, render_template, request, url_for
from flask_login import current_user
from sqlalchemy import func, or_

from .forms import LecturerForm
from .main import ranked_query
from .models import CRITERIA, AuditLog, Evaluation, Lecturer, User, db
from .utils import escape_like, log_action, role_required

bp = Blueprint("admin", __name__)


@bp.route("/lecturers")
@role_required("admin")
def lecturers():
    items = Lecturer.query.order_by(Lecturer.name).all()
    return render_template("admin/lecturers.html", items=items)


@bp.route("/lecturers/new", methods=["GET", "POST"])
@role_required("admin")
def lecturer_new():
    form = LecturerForm()
    if form.validate_on_submit():
        lecturer = Lecturer(title=form.title.data or None, name=form.name.data.strip(), department=form.department.data.strip(), bio=form.bio.data or None)
        db.session.add(lecturer)
        db.session.commit()
        log_action("lecturer_added", lecturer.name)
        flash("Lecturer added.", "success")
        return redirect(url_for("admin.lecturers"))
    return render_template("admin/lecturer_form.html", form=form, heading="Add a lecturer")


@bp.route("/lecturers/<int:lecturer_id>/edit", methods=["GET", "POST"])
@role_required("admin")
def lecturer_edit(lecturer_id):
    lecturer = db.get_or_404(Lecturer, lecturer_id)
    form = LecturerForm(obj=lecturer)
    if form.validate_on_submit():
        lecturer.title = form.title.data or None
        lecturer.name = form.name.data.strip()
        lecturer.department = form.department.data.strip()
        lecturer.bio = form.bio.data or None
        db.session.commit()
        log_action("lecturer_edited", lecturer.name)
        flash("Lecturer updated.", "success")
        return redirect(url_for("admin.lecturers"))
    return render_template("admin/lecturer_form.html", form=form, heading="Edit lecturer")


@bp.route("/lecturers/<int:lecturer_id>/delete", methods=["POST"])
@role_required("admin")
def lecturer_delete(lecturer_id):
    lecturer = db.get_or_404(Lecturer, lecturer_id)
    log_action("lecturer_deleted", lecturer.name)
    db.session.delete(lecturer)
    db.session.commit()
    flash("Lecturer and their evaluations were deleted.", "info")
    return redirect(url_for("admin.lecturers"))


@bp.route("/users")
@role_required("admin")
def users():
    q = request.args.get("q", "").strip()[:80]
    query = User.query
    if q:
        like = f"%{escape_like(q)}%"
        query = query.filter(or_(User.full_name.ilike(like, escape="\\"), User.email.ilike(like, escape="\\")))
    return render_template("admin/users.html", items=query.order_by(User.created_at.desc()).all(), q=q)


@bp.route("/users/<int:user_id>/toggle", methods=["POST"])
@role_required("admin")
def user_toggle(user_id):
    user = db.get_or_404(User, user_id)
    if user.role == "admin" or user.id == current_user.id:
        abort(403)
    user.active = not user.active
    db.session.commit()
    log_action("user_enabled" if user.active else "user_disabled", user.email)
    flash(f"{user.email} is now {'active' if user.active else 'disabled'}.", "info")
    return redirect(url_for("admin.users"))


def report_rows():
    query, stats = ranked_query()
    rows = []
    for lecturer, avg, n in query.order_by(Lecturer.name).all():
        per = [
            db.session.query(func.avg(getattr(Evaluation, key))).filter(Evaluation.lecturer_id == lecturer.id).scalar()
            for key, _ in CRITERIA
        ]
        rows.append((lecturer, n or 0, avg, per))
    return rows


@bp.route("/reports")
@role_required("admin")
def reports():
    return render_template("admin/reports.html", rows=report_rows(), criteria=CRITERIA)


def safe_cell(value):
    """Stop spreadsheet programs from running a cell that starts with a formula character."""
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@") else text


@bp.route("/reports.csv")
@role_required("admin")
def reports_csv():
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["Lecturer", "Department", "Evaluations", "Overall"] + [label for _, label in CRITERIA])
    for lecturer, n, avg, per in report_rows():
        writer.writerow([safe_cell(lecturer.display_name), safe_cell(lecturer.department), n, round(avg, 2) if avg else ""] + [round(p, 2) if p else "" for p in per])
    log_action("report_exported")
    return Response(out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=lecturer-report.csv"})


@bp.route("/audit")
@role_required("admin")
def audit():
    logs = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(100).all()
    return render_template("admin/audit.html", logs=logs)
