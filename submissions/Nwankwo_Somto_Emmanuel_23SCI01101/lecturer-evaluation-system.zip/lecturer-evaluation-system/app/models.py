from datetime import datetime, timezone

from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

db = SQLAlchemy()

CRITERIA = [
    ("teaching_clarity", "Clarity of teaching"),
    ("punctuality", "Punctuality and use of class time"),
    ("engagement", "Engagement with students"),
    ("fairness", "Fairness of assessment"),
    ("availability", "Availability for consultation"),
]


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(10), nullable=False, default="student")
    active = db.Column(db.Boolean, nullable=False, default=True)
    failed_logins = db.Column(db.Integer, nullable=False, default=0)
    locked_until = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=utcnow)
    last_login = db.Column(db.DateTime)

    evaluations = db.relationship("Evaluation", backref="student", cascade="all, delete-orphan")

    @property
    def is_active(self):
        return self.active

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Lecturer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    title = db.Column(db.String(40))
    department = db.Column(db.String(80), nullable=False, index=True)
    bio = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=utcnow)

    evaluations = db.relationship("Evaluation", backref="lecturer", cascade="all, delete-orphan")

    @property
    def display_name(self):
        return f"{self.title} {self.name}" if self.title else self.name


class Evaluation(db.Model):
    __table_args__ = (
        db.UniqueConstraint("student_id", "lecturer_id", "course_code", name="one_evaluation_per_course"),
        *[db.CheckConstraint(f"{key} BETWEEN 1 AND 5", name=f"ck_{key}") for key, _ in CRITERIA],
    )

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    lecturer_id = db.Column(db.Integer, db.ForeignKey("lecturer.id"), nullable=False)
    course_code = db.Column(db.String(10), nullable=False)
    teaching_clarity = db.Column(db.Integer, nullable=False)
    punctuality = db.Column(db.Integer, nullable=False)
    engagement = db.Column(db.Integer, nullable=False)
    fairness = db.Column(db.Integer, nullable=False)
    availability = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.String(500), nullable=False, default="")
    created_at = db.Column(db.DateTime, default=utcnow)

    @property
    def overall(self):
        return sum(getattr(self, key) for key, _ in CRITERIA) / len(CRITERIA)


class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer)
    action = db.Column(db.String(40), nullable=False)
    detail = db.Column(db.String(200))
    ip = db.Column(db.String(45))
    created_at = db.Column(db.DateTime, default=utcnow, index=True)
