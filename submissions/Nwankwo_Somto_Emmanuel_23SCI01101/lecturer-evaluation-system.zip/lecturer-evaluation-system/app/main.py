from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required
from sqlalchemy import func

from .forms import ChangePasswordForm, EvaluationForm, ProfileForm
from .models import CRITERIA, Evaluation, Lecturer, User, db
from .utils import escape_like, log_action, role_required

bp = Blueprint("main", __name__)

OVERALL = sum(getattr(Evaluation, key) for key, _ in CRITERIA) / 5.0


def ranked_query():
    """Lecturers joined to their average overall rating and number of evaluations."""
    stats = (
        db.session.query(
            Evaluation.lecturer_id.label("lid"),
            func.avg(OVERALL).label("avg"),
            func.count(Evaluation.id).label("n"),
        )
        .group_by(Evaluation.lecturer_id)
        .subquery()
    )
    query = db.session.query(Lecturer, stats.c.avg, stats.c.n).outerjoin(stats, stats.c.lid == Lecturer.id)
    return query, stats


@bp.route("/")
def index():
    return render_template("index.html")


@bp.route("/security")
def security():
    return render_template("security.html")


@bp.route("/dashboard")
@login_required
def dashboard():
    if current_user.role == "admin":
        query, stats = ranked_query()
        top = query.filter(stats.c.n > 0).order_by(stats.c.avg.desc()).limit(5).all()
        totals = {
            "Students": User.query.filter_by(role="student").count(),
            "Lecturers": Lecturer.query.count(),
            "Evaluations": Evaluation.query.count(),
        }
        return render_template("dashboard.html", totals=totals, top=top)
    mine = Evaluation.query.filter_by(student_id=current_user.id)
    done = mine.with_entities(func.count(func.distinct(Evaluation.lecturer_id))).scalar()
    recent = mine.order_by(Evaluation.created_at.desc()).limit(5).all()
    return render_template("dashboard.html", total=mine.count(), remaining=Lecturer.query.count() - done, recent=recent)


@bp.route("/lecturers")
@login_required
def lecturers():
    q = request.args.get("q", "").strip()[:80]
    department = request.args.get("department", "").strip()[:80]
    sort = request.args.get("sort", "name")
    page = request.args.get("page", 1, type=int)

    query, stats = ranked_query()
    if q:
        query = query.filter(Lecturer.name.ilike(f"%{escape_like(q)}%", escape="\\"))
    if department:
        query = query.filter(Lecturer.department == department)
    if sort == "rating":
        query = query.order_by(func.coalesce(stats.c.avg, 0).desc(), Lecturer.name)
    else:
        query = query.order_by(Lecturer.name)

    pagination = query.paginate(page=page, per_page=9, error_out=False)
    departments = [d for (d,) in db.session.query(Lecturer.department).distinct().order_by(Lecturer.department)]
    return render_template("lecturers.html", pagination=pagination, departments=departments, q=q, department=department, sort=sort)


@bp.route("/lecturers/<int:lecturer_id>")
@login_required
def lecturer_detail(lecturer_id):
    lecturer = db.get_or_404(Lecturer, lecturer_id)
    row = (
        db.session.query(*[func.avg(getattr(Evaluation, key)) for key, _ in CRITERIA], func.count(Evaluation.id))
        .filter(Evaluation.lecturer_id == lecturer.id)
        .one()
    )
    count = row[-1]
    averages = [(label, row[i]) for i, (_, label) in enumerate(CRITERIA)]
    overall = sum(v for _, v in averages) / len(averages) if count else None
    comments = (
        Evaluation.query.filter(Evaluation.lecturer_id == lecturer.id, Evaluation.comment != "")
        .order_by(Evaluation.created_at.desc())
        .limit(30)
        .all()
    )
    return render_template("lecturer_detail.html", lecturer=lecturer, averages=averages, overall=overall, count=count, comments=comments)


@bp.route("/lecturers/<int:lecturer_id>/evaluate", methods=["GET", "POST"])
@role_required("student")
def evaluate(lecturer_id):
    lecturer = db.get_or_404(Lecturer, lecturer_id)
    form = EvaluationForm()
    if form.validate_on_submit():
        code = form.clean_code(form.course_code.data)
        if Evaluation.query.filter_by(student_id=current_user.id, lecturer_id=lecturer.id, course_code=code).first():
            flash(f"You have already evaluated this lecturer for {code}.", "warning")
        else:
            ev = Evaluation(student_id=current_user.id, lecturer_id=lecturer.id, course_code=code, comment=(form.comment.data or "").strip())
            for key, _ in CRITERIA:
                setattr(ev, key, int(getattr(form, key).data))
            db.session.add(ev)
            db.session.commit()
            log_action("evaluation_submitted", f"lecturer={lecturer.id} course={code}")
            flash("Thank you. Your evaluation was submitted anonymously.", "success")
            return redirect(url_for("main.lecturer_detail", lecturer_id=lecturer.id))
    return render_template("evaluate.html", form=form, lecturer=lecturer, criteria=CRITERIA)


@bp.route("/my-evaluations")
@role_required("student")
def my_evaluations():
    items = Evaluation.query.filter_by(student_id=current_user.id).order_by(Evaluation.created_at.desc()).all()
    return render_template("my_evaluations.html", items=items)


@bp.route("/my-evaluations/<int:evaluation_id>/delete", methods=["POST"])
@role_required("student")
def delete_evaluation(evaluation_id):
    ev = db.get_or_404(Evaluation, evaluation_id)
    if ev.student_id != current_user.id:  # access-control check: you can only remove your own
        log_action("forbidden_delete", f"evaluation={evaluation_id}")
        abort(403)
    db.session.delete(ev)
    db.session.commit()
    flash("Evaluation deleted.", "info")
    return redirect(url_for("main.my_evaluations"))


@bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    form = ProfileForm(obj=current_user)
    if form.validate_on_submit():
        current_user.full_name = form.full_name.data.strip()
        db.session.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("main.profile"))
    return render_template("profile.html", form=form)


@bp.route("/profile/password", methods=["GET", "POST"])
@login_required
def change_password():
    form = ChangePasswordForm()
    if form.validate_on_submit():
        if not current_user.check_password(form.current.data):
            form.current.errors.append("Current password is incorrect.")
        else:
            current_user.set_password(form.new.data)
            db.session.commit()
            log_action("password_changed")
            flash("Password changed.", "success")
            return redirect(url_for("main.profile"))
    return render_template("change_password.html", form=form)
