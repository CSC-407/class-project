import re

from flask_wtf import FlaskForm
from wtforms import PasswordField, RadioField, StringField, TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Optional, Regexp, ValidationError

from .models import CRITERIA, User
from .utils import password_problem

NAME_RE = r"^[A-Za-z][A-Za-z .'\-]{1,79}$"


def strong_password(form, field):
    problem = password_problem(field.data or "")
    if problem:
        raise ValidationError(problem)


class RegistrationForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(2, 80), Regexp(NAME_RE, message="Use letters, spaces, hyphens and apostrophes only.")])
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)], filters=[lambda v: v.strip().lower() if v else v])
    password = PasswordField("Password", validators=[DataRequired(), strong_password])
    confirm = PasswordField("Confirm password", validators=[DataRequired(), EqualTo("password", message="Passwords do not match.")])

    def validate_email(self, field):
        if User.query.filter_by(email=field.data).first():
            raise ValidationError("An account with this email already exists.")


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Length(max=120)], filters=[lambda v: v.strip().lower() if v else v])
    password = PasswordField("Password", validators=[DataRequired(), Length(max=128)])


class ProfileForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(2, 80), Regexp(NAME_RE, message="Use letters, spaces, hyphens and apostrophes only.")])


class ChangePasswordForm(FlaskForm):
    current = PasswordField("Current password", validators=[DataRequired()])
    new = PasswordField("New password", validators=[DataRequired(), strong_password])
    confirm = PasswordField("Confirm new password", validators=[DataRequired(), EqualTo("new", message="Passwords do not match.")])


class LecturerForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired(), Length(2, 100), Regexp(NAME_RE.replace("80", "100"), message="Use letters, spaces, hyphens and apostrophes only.")])
    title = StringField("Title (for example Dr. or Prof.)", validators=[Optional(), Length(max=40)])
    department = StringField("Department", validators=[DataRequired(), Length(2, 80)])
    bio = TextAreaField("Short bio", validators=[Optional(), Length(max=300)])


def _rating_field(label):
    return RadioField(label, choices=[(str(n), str(n)) for n in range(1, 6)], validators=[DataRequired(message="Pick a rating from 1 to 5.")])


class EvaluationForm(FlaskForm):
    course_code = StringField("Course code", validators=[DataRequired(), Regexp(r"^[A-Za-z]{3}\s?\d{3}$", message="Use a code like CSC 301.")])
    teaching_clarity = _rating_field(CRITERIA[0][1])
    punctuality = _rating_field(CRITERIA[1][1])
    engagement = _rating_field(CRITERIA[2][1])
    fairness = _rating_field(CRITERIA[3][1])
    availability = _rating_field(CRITERIA[4][1])
    comment = TextAreaField("Comment (optional, shown anonymously)", validators=[Optional(), Length(max=500)])

    @staticmethod
    def clean_code(value):
        return re.sub(r"\s+", "", value).upper()
