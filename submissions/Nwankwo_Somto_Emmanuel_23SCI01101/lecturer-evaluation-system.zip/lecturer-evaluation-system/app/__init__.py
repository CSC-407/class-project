import logging
import os
from logging.handlers import RotatingFileHandler

import click
from flask import Flask, redirect, render_template, request
from flask_login import LoginManager
from flask_wtf.csrf import CSRFError, CSRFProtect
from werkzeug.middleware.proxy_fix import ProxyFix

from config import config_by_name

from .models import Evaluation, Lecturer, User, db
from .utils import log_action, password_problem

login_manager = LoginManager()
csrf = CSRFProtect()

# Everything is served from our own domain, so the policy can stay very strict.
CSP = (
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
    "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
)


def create_app(config_name=None):
    config_name = config_name or os.environ.get("APP_ENV", "development")
    app = Flask(__name__)
    app.config.from_object(config_by_name[config_name])
    if not app.config.get("SECRET_KEY"):
        raise RuntimeError("SECRET_KEY is not set. Add it to your .env file or environment.")

    os.makedirs(app.instance_path, exist_ok=True)
    if app.config["TRUST_PROXY"]:
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    db.init_app(app)
    csrf.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message = "Please log in to see that page."
    login_manager.login_message_category = "info"
    login_manager.session_protection = "strong"

    from .admin import bp as admin_bp
    from .auth import bp as auth_bp
    from .main import bp as main_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp, url_prefix="/admin")

    @login_manager.user_loader
    def load_user(user_id):
        user = db.session.get(User, int(user_id))
        return user if user and user.active else None

    @app.before_request
    def force_https():
        if app.config["FORCE_HTTPS"] and not request.is_secure:
            return redirect(request.url.replace("http://", "https://", 1), code=301)

    @app.after_request
    def security_headers(resp):
        resp.headers["Content-Security-Policy"] = CSP
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        resp.headers["Permissions-Policy"] = "geolocation=(), camera=(), microphone=()"
        if app.config["SESSION_COOKIE_SECURE"]:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if request.endpoint != "static":
            resp.headers["Cache-Control"] = "no-store"
        return resp

    def show_error(code, title, message):
        return render_template("error.html", code=code, title=title, message=message), code

    @app.errorhandler(403)
    def forbidden(e):
        return show_error(403, "Access denied", "Your account does not have permission to open this page.")

    @app.errorhandler(404)
    def not_found(e):
        return show_error(404, "Page not found", "The page you asked for does not exist or has been moved.")

    @app.errorhandler(413)
    def too_large(e):
        return show_error(413, "Request too large", "That submission is bigger than the server accepts.")

    @app.errorhandler(CSRFError)
    def csrf_failed(e):
        return show_error(400, "Session expired", "Your form session expired or was invalid. Go back, refresh the page and try again.")

    @app.errorhandler(500)
    def server_error(e):
        db.session.rollback()
        return show_error(500, "Something went wrong", "The error has been logged. Please try again in a moment.")

    if not app.testing and not app.debug:
        os.makedirs("logs", exist_ok=True)
        handler = RotatingFileHandler("logs/app.log", maxBytes=1_000_000, backupCount=5)
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        handler.setLevel(logging.INFO)
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)

    register_cli(app)
    return app


def register_cli(app):
    @app.cli.command("init-db")
    def init_db():
        """Create all database tables."""
        db.create_all()
        click.echo("Database tables created.")

    @app.cli.command("create-admin")
    @click.option("--name", prompt="Full name")
    @click.option("--email", prompt="Email")
    @click.password_option()
    def create_admin(name, email, password):
        """Create an administrator account."""
        db.create_all()
        problem = password_problem(password)
        if problem:
            raise click.ClickException(problem)
        email = email.strip().lower()
        if User.query.filter_by(email=email).first():
            raise click.ClickException("That email is already registered.")
        user = User(full_name=name, email=email, role="admin")
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        log_action("admin_created", email, user_id=user.id)
        click.echo(f"Administrator {email} created.")

    @app.cli.command("seed-demo")
    def seed_demo():
        """Add sample lecturers and one demo student for testing the interface."""
        db.create_all()
        samples = [
            ("Dr.", "Ada Okonkwo", "Computer Science", "Databases and information systems."),
            ("Prof.", "Ibrahim Musa", "Computer Science", "Networks and cybersecurity."),
            ("Dr.", "Ngozi Eze", "Mathematics", "Linear algebra and numerical methods."),
            ("Mr.", "Tunde Bakare", "Physics", "Electronics and instrumentation."),
            ("Mrs.", "Chidinma Obi", "Statistics", "Probability and data analysis."),
            ("Dr.", "Samuel Adeyemi", "Computer Science", "Software engineering and web development."),
        ]
        if Lecturer.query.count() == 0:
            for title, name, dept, bio in samples:
                db.session.add(Lecturer(title=title, name=name, department=dept, bio=bio))
        if not User.query.filter_by(email="student@example.com").first():
            demo = User(full_name="Demo Student", email="student@example.com")
            demo.set_password("Student2025x")
            db.session.add(demo)
        db.session.commit()
        click.echo("Demo data added. Demo student: student@example.com / Student2025x (development only).")
