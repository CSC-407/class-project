from datetime import timedelta

from flask import Blueprint, current_app, flash, redirect, render_template, request, session, url_for
from flask_login import current_user, login_required, login_user, logout_user
from werkzeug.security import check_password_hash, generate_password_hash

from .forms import LoginForm, RegistrationForm
from .models import User, db, utcnow
from .utils import is_safe_url, log_action

bp = Blueprint("auth", __name__)

# Checked when the email is unknown so that response time does not reveal which emails exist.
DUMMY_HASH = generate_password_hash("not-a-real-password")


@bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    form = RegistrationForm()
    if form.validate_on_submit():
        user = User(full_name=form.full_name.data.strip(), email=form.email.data, role="student")
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        log_action("register", user.email, user_id=user.id)
        flash("Account created. You can log in now.", "success")
        return redirect(url_for("auth.login"))
    return render_template("register.html", form=form)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        now = utcnow()
        if user and user.locked_until and user.locked_until > now:
            log_action("login_blocked", form.email.data, user_id=user.id)
            flash("Too many failed attempts. Please wait a few minutes and try again.", "danger")
        elif user and user.check_password(form.password.data):
            if not user.active:
                flash("This account has been disabled. Contact the administrator.", "danger")
                return render_template("login.html", form=form)
            user.failed_logins = 0
            user.locked_until = None
            user.last_login = now
            db.session.commit()
            session.clear()  # start a fresh session so an old one cannot be reused (session fixation)
            login_user(user)
            session.permanent = True
            log_action("login", user_id=user.id)
            target = request.args.get("next")
            return redirect(target if is_safe_url(target) else url_for("main.dashboard"))
        else:
            if user:
                user.failed_logins += 1
                if user.failed_logins >= current_app.config["MAX_FAILED_LOGINS"]:
                    user.locked_until = now + timedelta(minutes=current_app.config["LOCKOUT_MINUTES"])
                    user.failed_logins = 0
                db.session.commit()
            else:
                check_password_hash(DUMMY_HASH, form.password.data)
            log_action("login_failed", form.email.data, user_id=user.id if user else None)
            flash("Invalid email or password.", "danger")
    return render_template("login.html", form=form)


@bp.route("/logout", methods=["POST"])
@login_required
def logout():
    log_action("logout")
    logout_user()
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("main.index"))
