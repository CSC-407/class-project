import re
from functools import wraps
from urllib.parse import urljoin, urlparse

from flask import abort, current_app, has_request_context, request
from flask_login import current_user

from .models import AuditLog, db

COMMON_PASSWORDS = {"password", "password1", "12345678", "123456789", "qwerty123", "iloveyou1"}


def password_problem(password):
    """Return a plain-English reason the password is too weak, or None if it is fine."""
    if len(password) < 8:
        return "Use at least 8 characters."
    if len(password) > 128:
        return "Use 128 characters or fewer."
    if not (re.search(r"[a-z]", password) and re.search(r"[A-Z]", password) and re.search(r"\d", password)):
        return "Mix upper case, lower case and at least one number."
    if password.lower() in COMMON_PASSWORDS:
        return "That password is too common."
    return None


def role_required(role):
    """Allow only logged-in users with the given role; everyone else gets a 401 redirect or 403."""

    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                return current_app.login_manager.unauthorized()
            if current_user.role != role:
                abort(403)
            return view(*args, **kwargs)

        return wrapped

    return decorator


def is_safe_url(target):
    """Only allow redirects back to this same site (prevents open redirects)."""
    if not target or "\\" in target:
        return False
    host = urlparse(request.host_url)
    dest = urlparse(urljoin(request.host_url, target))
    return dest.scheme in ("http", "https") and dest.netloc == host.netloc


def escape_like(value):
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def log_action(action, detail=None, user_id=None):
    if user_id is None and current_user and current_user.is_authenticated:
        user_id = current_user.id
    ip = request.remote_addr if has_request_context() else "cli"
    db.session.add(AuditLog(user_id=user_id, action=action, detail=(detail or "")[:200], ip=ip))
    db.session.commit()
