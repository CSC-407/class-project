import pytest

from app import create_app
from app.models import Lecturer, User, db

GOOD_PASSWORD = "Strong1Pass"


@pytest.fixture
def app():
    app = create_app("testing")
    with app.app_context():
        db.create_all()
        admin = User(full_name="Admin User", email="admin@example.com", role="admin")
        admin.set_password(GOOD_PASSWORD)
        db.session.add(admin)
        db.session.add(Lecturer(title="Dr.", name="Ada Okonkwo", department="Computer Science"))
        db.session.add(Lecturer(title="Prof.", name="Ibrahim Musa", department="Physics"))
        db.session.commit()
        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


def register(client, email="stu@example.com", name="Stu Dent", password=GOOD_PASSWORD, confirm=None):
    return client.post("/register", data={"full_name": name, "email": email, "password": password, "confirm": confirm or password})


def login(client, email="stu@example.com", password=GOOD_PASSWORD, **kwargs):
    return client.post("/login", data={"email": email, "password": password}, **kwargs)


def make_student(app, email, name="Other Student"):
    with app.app_context():
        u = User(full_name=name, email=email)
        u.set_password(GOOD_PASSWORD)
        db.session.add(u)
        db.session.commit()
        return u.id


def evaluation_data(**overrides):
    data = {"course_code": "CSC 301", "teaching_clarity": "5", "punctuality": "4", "engagement": "4", "fairness": "5", "availability": "3", "comment": "Clear lectures."}
    data.update(overrides)
    return data
