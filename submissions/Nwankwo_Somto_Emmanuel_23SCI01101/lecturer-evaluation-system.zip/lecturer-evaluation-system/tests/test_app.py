import pytest
from sqlalchemy.exc import IntegrityError

from app import create_app
from app.models import AuditLog, Evaluation, Lecturer, User, db

from .conftest import GOOD_PASSWORD, evaluation_data, login, make_student, register


# ---------- Functional: pages, navigation, search ----------
def test_public_pages_load(client):
    for path in ["/", "/login", "/register", "/security"]:
        assert client.get(path).status_code == 200


def test_viewport_meta_for_mobile(client):
    assert b'name="viewport"' in client.get("/").data


def test_lecturer_search_and_filter(client):
    register(client)
    login(client)
    assert b"Ada Okonkwo" in client.get("/lecturers?q=ada").data
    page = client.get("/lecturers?q=ada").data
    assert b"Ibrahim Musa" not in page
    assert b"Ibrahim Musa" in client.get("/lecturers?department=Physics").data
    assert b"No lecturers match" in client.get("/lecturers?q=zzzz").data


# ---------- Registration ----------
def test_registration_stores_hashed_password(client, app):
    assert register(client).status_code == 302
    with app.app_context():
        user = User.query.filter_by(email="stu@example.com").first()
        assert user is not None and user.role == "student"
        assert user.password_hash != GOOD_PASSWORD and GOOD_PASSWORD not in user.password_hash
        assert user.check_password(GOOD_PASSWORD)


@pytest.mark.parametrize("password", ["short1A", "alllowercase1", "ALLUPPERCASE1", "NoNumbersHere"])
def test_weak_passwords_rejected(client, password):
    assert register(client, password=password).status_code == 200


def test_registration_validation(client):
    assert b"do not match" in register(client, confirm="Different1Pass").data
    assert b"Invalid email" in register(client, email="not-an-email").data
    assert b"letters, spaces" in register(client, name="<b>Bad</b>").data
    register(client)
    assert b"already exists" in register(client).data


# ---------- Login, logout, sessions ----------
def test_login_logout_flow(client):
    register(client)
    assert login(client).status_code == 302
    assert client.get("/dashboard").status_code == 200
    assert client.post("/logout").status_code == 302
    assert client.get("/dashboard").status_code == 302


def test_wrong_password_and_unknown_email(client):
    register(client)
    assert b"Invalid email or password" in login(client, password="Wrong1Pass").data
    assert b"Invalid email or password" in login(client, email="ghost@example.com").data


def test_account_lockout_after_repeated_failures(client):
    register(client)
    for _ in range(5):
        login(client, password="Wrong1Pass")
    assert b"Too many failed attempts" in login(client).data  # even the right password is refused


def test_protected_pages_redirect_to_login(client):
    for path in ["/dashboard", "/lecturers", "/profile", "/my-evaluations", "/admin/users"]:
        resp = client.get(path)
        assert resp.status_code == 302 and "/login" in resp.headers["Location"]


def test_open_redirect_blocked(client):
    register(client)
    resp = login(client, query_string={"next": "//evil.example.com"})
    assert "evil.example.com" not in resp.headers["Location"]
    client.post("/logout")
    resp = login(client, query_string={"next": "/lecturers"})
    assert resp.headers["Location"].endswith("/lecturers")


def test_session_cookie_flags_in_production_config():
    from config import ProductionConfig

    assert ProductionConfig.SESSION_COOKIE_SECURE is True
    assert ProductionConfig.SESSION_COOKIE_HTTPONLY is True
    assert ProductionConfig.SESSION_COOKIE_SAMESITE == "Lax"


def test_production_requires_secret_key(monkeypatch):
    monkeypatch.delenv("SECRET_KEY", raising=False)
    from config import ProductionConfig

    monkeypatch.setattr(ProductionConfig, "SECRET_KEY", None)
    with pytest.raises(RuntimeError):
        create_app("production")


# ---------- Role-based access control ----------
def test_student_cannot_open_admin_pages(client):
    register(client)
    login(client)
    for path in ["/admin/lecturers", "/admin/users", "/admin/reports", "/admin/audit", "/admin/reports.csv"]:
        assert client.get(path).status_code == 403


def test_admin_pages_and_admin_cannot_evaluate(client):
    login(client, email="admin@example.com")
    for path in ["/admin/lecturers", "/admin/users", "/admin/reports", "/admin/audit", "/dashboard"]:
        assert client.get(path).status_code == 200
    assert client.get("/lecturers/1/evaluate").status_code == 403


def test_student_cannot_delete_another_students_evaluation(client, app):
    other = make_student(app, "other@example.com")
    with app.app_context():
        ev = Evaluation(student_id=other, lecturer_id=1, course_code="CSC301", teaching_clarity=3, punctuality=3, engagement=3, fairness=3, availability=3)
        db.session.add(ev)
        db.session.commit()
        ev_id = ev.id
    register(client)
    login(client)
    assert client.post(f"/my-evaluations/{ev_id}/delete").status_code == 403
    with app.app_context():
        assert db.session.get(Evaluation, ev_id) is not None


def test_admin_disables_student(client, app):
    register(client)
    with app.app_context():
        uid = User.query.filter_by(email="stu@example.com").first().id
    login(client, email="admin@example.com")
    assert client.post(f"/admin/users/{uid}/toggle").status_code == 302
    client.post("/logout")
    assert b"disabled" in login(client).data
    assert client.get("/dashboard").status_code == 302


# ---------- Evaluation form validation ----------
def test_submit_evaluation_and_duplicate_blocked(client, app):
    register(client)
    login(client)
    assert client.post("/lecturers/1/evaluate", data=evaluation_data()).status_code == 302
    assert b"already evaluated" in client.post("/lecturers/1/evaluate", data=evaluation_data(course_code="csc301")).data
    with app.app_context():
        assert Evaluation.query.count() == 1


@pytest.mark.parametrize("bad", [{"teaching_clarity": "7"}, {"punctuality": "0"}, {"fairness": ""}, {"course_code": "12345"}, {"comment": "x" * 501}])
def test_evaluation_validation(client, app, bad):
    register(client)
    login(client)
    assert client.post("/lecturers/1/evaluate", data=evaluation_data(**bad)).status_code == 200
    with app.app_context():
        assert Evaluation.query.count() == 0


# ---------- Injection and XSS ----------
def test_sql_injection_in_search_returns_nothing(client):
    register(client)
    login(client)
    page = client.get("/lecturers", query_string={"q": "' OR '1'='1"}).data
    assert b"Ada Okonkwo" not in page and b"No lecturers match" in page
    assert client.get("/lecturers", query_string={"department": "x'; DROP TABLE user;--"}).status_code == 200
    assert client.get("/profile").status_code == 200  # tables still exist


def test_sql_injection_in_login_fails(client):
    register(client)
    assert b"Invalid email or password" in login(client, email="' OR 1=1 --", password="x").data


def test_stored_xss_is_escaped(client, app):
    payload = "<script>alert(1)</script>"
    register(client)
    login(client)
    client.post("/lecturers/1/evaluate", data=evaluation_data(comment=payload))
    page = client.get("/lecturers/1").data
    assert payload.encode() not in page and b"&lt;script&gt;" in page
    client.post("/logout")
    login(client, email="admin@example.com")
    client.post("/admin/lecturers/new", data={"name": "Evil", "department": payload})
    assert payload.encode() not in client.get("/admin/lecturers").data


# ---------- CSRF, headers, errors ----------
def test_csrf_blocks_post_without_token(app):
    app.config["WTF_CSRF_ENABLED"] = True
    resp = app.test_client().post("/login", data={"email": "a@b.co", "password": "x"})
    assert resp.status_code == 400 and b"Session expired" in resp.data


def test_security_headers_present(client):
    resp = client.get("/")
    for header in ["Content-Security-Policy", "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy"]:
        assert header in resp.headers
    assert "script-src 'self'" in resp.headers["Content-Security-Policy"]


def test_custom_error_pages_hide_internals(client):
    resp = client.get("/does-not-exist")
    assert resp.status_code == 404 and b"Page not found" in resp.data and b"Traceback" not in resp.data
    register(client)
    login(client)
    forbidden = client.get("/admin/users")
    assert forbidden.status_code == 403 and b"Access denied" in forbidden.data


def test_oversized_request_rejected(client):
    resp = client.post("/login", data={"email": "a" * 2_000_000, "password": "x"})
    assert resp.status_code == 413


# ---------- Profile ----------
def test_profile_update_and_password_change(client):
    register(client)
    login(client)
    client.post("/profile", data={"full_name": "New Name"})
    assert b"New Name" in client.get("/profile").data
    assert b"incorrect" in client.post("/profile/password", data={"current": "Wrong1Pass", "new": "Another1Pass", "confirm": "Another1Pass"}).data
    assert client.post("/profile/password", data={"current": GOOD_PASSWORD, "new": "Another1Pass", "confirm": "Another1Pass"}).status_code == 302
    client.post("/logout")
    assert login(client, password="Another1Pass").status_code == 302


# ---------- Database ----------
def test_unique_email_constraint(app):
    with app.app_context():
        db.session.add(User(full_name="Dup", email="admin@example.com", password_hash="x"))
        with pytest.raises(IntegrityError):
            db.session.commit()
        db.session.rollback()


def test_rating_range_constraint(app):
    with app.app_context():
        db.session.add(Evaluation(student_id=1, lecturer_id=1, course_code="CSC301", teaching_clarity=9, punctuality=3, engagement=3, fairness=3, availability=3))
        with pytest.raises(IntegrityError):
            db.session.commit()
        db.session.rollback()


def test_deleting_lecturer_removes_evaluations(client, app):
    register(client)
    login(client)
    client.post("/lecturers/1/evaluate", data=evaluation_data())
    client.post("/logout")
    login(client, email="admin@example.com")
    client.post("/admin/lecturers/1/delete")
    with app.app_context():
        assert Evaluation.query.count() == 0 and db.session.get(Lecturer, 1) is None


def test_audit_log_records_events(client, app):
    register(client)
    login(client, password="Wrong1Pass")
    login(client)
    with app.app_context():
        actions = {row.action for row in AuditLog.query.all()}
    assert {"register", "login_failed", "login"} <= actions


# ---------- Admin reports ----------
def test_csv_export_neutralises_formulas(client):
    login(client, email="admin@example.com")
    client.post("/admin/lecturers/new", data={"name": "Formula Guy", "title": "=HYPERLINK(1)", "department": "Physics"})
    body = client.get("/admin/reports.csv").data.decode()
    assert "'=HYPERLINK" in body and "\n=HYPERLINK" not in body and ",=HYPERLINK" not in body
