# Deployment

This guide follows the application from your laptop to a live HTTPS site on an Ubuntu server. If you have no server, section 8 shows a free platform route that skips most of the setup.

## 1. From development to live, in order

1. Develop and test locally with `APP_ENV=development`.
2. Push the code to GitHub. The GitHub Actions workflow runs the tests on every push.
3. On the server, pull the code, install the dependencies, set the production environment variables and create the database.
4. Gunicorn runs the app, systemd keeps it running, and Nginx sits in front to handle HTTPS and static files.
5. Test the live site, then repeat steps 2 and 3 whenever there is an update.

## 2. Configuration by environment

The same code runs in three modes, chosen by the `APP_ENV` variable.

| Setting | development | production |
|---|---|---|
| Debug pages | on | off |
| Secure cookies and HTTPS redirect | off | on |
| Secret key | built-in placeholder | must be supplied, app refuses to start without it |
| Log file | none | `logs/app.log`, rotating |

## 3. Environment variables

Create `/srv/lecturer-eval/.env` on the server and set permissions with `chmod 600 .env` so only the app user can read it.

```
APP_ENV=production
SECRET_KEY=<paste output of: python -c "import secrets; print(secrets.token_hex(32))">
DATABASE_URL=sqlite:////srv/lecturer-eval/instance/app.db
TRUST_PROXY=1
FORCE_HTTPS=1
```

`TRUST_PROXY=1` tells the app to believe Nginx about the visitor's real address and whether the connection was HTTPS. Only turn it on when Nginx is in front.

## 4. Install on the server

```bash
sudo apt update && sudo apt install -y python3-venv nginx certbot python3-certbot-nginx sqlite3
sudo useradd --system --create-home --shell /usr/sbin/nologin leval
sudo mkdir -p /srv/lecturer-eval && sudo chown leval: /srv/lecturer-eval
sudo -u leval git clone <your-repo-url> /srv/lecturer-eval
cd /srv/lecturer-eval
sudo -u leval python3 -m venv .venv
sudo -u leval .venv/bin/pip install -r requirements.txt
# create .env as described in section 3, then:
sudo -u leval .venv/bin/flask --app wsgi init-db
sudo -u leval .venv/bin/flask --app wsgi create-admin
```

Do not run `seed-demo` on the live server.

## 5. Run with Gunicorn and systemd

Copy `deploy/lecturer-eval.service` to `/etc/systemd/system/`, then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now lecturer-eval
sudo systemctl status lecturer-eval
```

Gunicorn listens only on `127.0.0.1:8000`, so the app is never reachable directly from the internet.

## 6. Domain, Nginx and HTTPS

1. Point your domain's A record at the server's IP address.
2. Copy `deploy/nginx.conf` to `/etc/nginx/sites-available/lecturer-eval`, replace `example.com` with your domain, link it into `sites-enabled` and run `sudo nginx -t && sudo systemctl reload nginx`.
3. Run `sudo certbot --nginx -d example.com`. Certbot obtains a free Let's Encrypt certificate, edits the Nginx file for HTTPS and sets up automatic renewal.
4. Confirm renewal works with `sudo certbot renew --dry-run`.
5. Open the firewall for web traffic only: `sudo ufw allow OpenSSH && sudo ufw allow 'Nginx Full' && sudo ufw enable`.

## 7. Backups, logs and monitoring

1. **Backups**: `deploy/backup.sh` makes a consistent copy of the SQLite database and deletes copies older than 14 days. Schedule it with `sudo crontab -u leval -e` and the line `0 2 * * * /srv/lecturer-eval/deploy/backup.sh`. Copy the `backups/` folder off the server now and then, because a backup on the same disk does not survive a disk failure.
2. **Application log**: errors and warnings go to `logs/app.log`, which rotates at 1 MB and keeps five old files. Read it with `tail -f /srv/lecturer-eval/logs/app.log`.
3. **Service log**: `sudo journalctl -u lecturer-eval -f` shows Gunicorn start-up problems.
4. **Web server log**: `/var/log/nginx/access.log` and `error.log` show every request and proxy failure.
5. **In-app audit log**: administrators can read logins, failed attempts and admin actions from the Audit log page.
6. **Uptime**: a free monitor such as UptimeRobot can ping the site and email you if it goes down.

## 8. Free platform alternative

If renting a server is not practical, Render and PythonAnywhere both have free tiers and provide HTTPS automatically.

1. Connect the GitHub repo, and set the start command to `gunicorn wsgi:app`.
2. Add `APP_ENV`, `SECRET_KEY`, `TRUST_PROXY=1` and `FORCE_HTTPS=1` in the platform's environment settings.
3. Run `flask --app wsgi init-db` and `flask --app wsgi create-admin` once from the platform's console.
4. Free tiers often reset the disk on redeploy, which would erase a SQLite file. For anything beyond a demo, use the platform's free PostgreSQL option and set `DATABASE_URL` to it, which needs `pip install psycopg2-binary` added to `requirements.txt`.

## 9. Updating the live site

```bash
cd /srv/lecturer-eval
sudo -u leval git pull
sudo -u leval .venv/bin/pip install -r requirements.txt
sudo systemctl restart lecturer-eval
```
