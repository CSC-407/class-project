# Testing

The project has two kinds of testing. The first is an automated suite of 39 pytest tests that checks behaviour and security rules every time it runs. The second is a short manual checklist for things a script cannot judge well, such as how the pages feel on a phone.

Run the automated suite with `python -m pytest`. Last run: **39 passed**.

## 1. Automated tests

Each row names the test area, what is being checked, and the tests in `tests/test_app.py` that cover it.

| Area | What is checked | Tests |
|---|---|---|
| Functional | Public pages load, lecturer search and department filter return the right lecturers, the viewport tag is present | `test_public_pages_load`, `test_lecturer_search_and_filter`, `test_viewport_meta_for_mobile` |
| Registration | Account is created, password is stored only as a hash, weak passwords rejected, mismatched passwords, bad email, bad name and duplicate email all rejected | `test_registration_stores_hashed_password`, `test_weak_passwords_rejected`, `test_registration_validation` |
| Login and sessions | Login and logout work, wrong password and unknown email give the same message, account locks after five failures, protected pages redirect to login, open redirects are blocked | `test_login_logout_flow`, `test_wrong_password_and_unknown_email`, `test_account_lockout_after_repeated_failures`, `test_protected_pages_redirect_to_login`, `test_open_redirect_blocked` |
| Configuration | Production cookies are Secure, HttpOnly and SameSite, and production refuses to start without a secret key | `test_session_cookie_flags_in_production_config`, `test_production_requires_secret_key` |
| Access control | Students get 403 on every admin page, admins cannot submit evaluations, a student cannot delete another student's evaluation, a disabled account cannot log in | `test_student_cannot_open_admin_pages`, `test_admin_pages_and_admin_cannot_evaluate`, `test_student_cannot_delete_another_students_evaluation`, `test_admin_disables_student` |
| Form validation | Evaluation saves once, duplicate course evaluations blocked, ratings outside 1 to 5, missing ratings, bad course codes and overlong comments are rejected | `test_submit_evaluation_and_duplicate_blocked`, `test_evaluation_validation` |
| SQL injection | Injection strings in search, filter and login do nothing and the tables survive | `test_sql_injection_in_search_returns_nothing`, `test_sql_injection_in_login_fails` |
| Cross-site scripting | Script tags in comments and lecturer fields are shown as plain text | `test_stored_xss_is_escaped` |
| CSRF and headers | A POST without a token is refused, security headers and a strict Content-Security-Policy are sent | `test_csrf_blocks_post_without_token`, `test_security_headers_present` |
| Error handling | Custom 404 and 403 pages appear with no stack trace, oversized requests get 413 | `test_custom_error_pages_hide_internals`, `test_oversized_request_rejected` |
| Profile | Name can be changed, password change checks the current password and the new one works at next login | `test_profile_update_and_password_change` |
| Database | Unique email, rating range check, cascade delete of evaluations, audit log entries are written | `test_unique_email_constraint`, `test_rating_range_constraint`, `test_deleting_lecturer_removes_evaluations`, `test_audit_log_records_events` |
| Reports | CSV export neutralises cells that start with a formula character | `test_csv_export_neutralises_formulas` |

## 2. Manual checklist

Fill in the last column yourself while you click through the running app, and add screenshots to your report. These are the checks that need a person.

| Area | Steps | Expected result | Result |
|---|---|---|---|
| Usability | Register, log in, find a lecturer, submit an evaluation, then find it under My evaluations. Ask a classmate to do the same without help. | Classmate finishes without asking where to click | |
| Usability | Submit the evaluation form with nothing filled in | Each missing field shows a clear message under it | |
| Responsive | Open the site on a phone, or use browser developer tools at 375 px width | Menu collapses behind the toggle, lecturer cards stack in one column, tables scroll sideways instead of breaking the page | |
| Responsive | Resize to tablet width (768 px) and desktop (1280 px) | Layout moves to two and then three columns with nothing overlapping | |
| Keyboard | Tab through the login page and the evaluation form | Focus outline is always visible and the rating buttons can be chosen with the arrow keys | |
| Session timeout | Log in, wait 30 minutes without activity, then reload | You are sent back to the login page | |
| HTTPS (live site only) | Visit the http:// address of the deployed site | Browser is redirected to https:// and shows a valid certificate | |
| Backup | Run `deploy/backup.sh`, then open the copy with `sqlite3` | Backup file exists and contains the tables | |

## 3. Security testing notes

1. **Authentication**: lockout and uniform error messages are covered by the tests above. To see it by hand, enter a wrong password five times and watch the Audit log page record the failures.
2. **Session handling**: after logging out, press the browser back button. The cached page should not show private data because every response carries `Cache-Control: no-store`.
3. **Header check**: on the live site, scan the domain with a header checker such as securityheaders.com and record the grade in your report.
4. **Dependency check**: run `pip install pip-audit` followed by `pip-audit -r requirements.txt` to list known vulnerabilities in the libraries.
