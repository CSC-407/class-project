#!/usr/bin/env bash
# Makes a safe copy of the SQLite database and removes copies older than 14 days.
set -euo pipefail
APP_DIR="${APP_DIR:-/srv/lecturer-eval}"
DB="$APP_DIR/instance/app.db"
OUT="$APP_DIR/backups"
mkdir -p "$OUT"
sqlite3 "$DB" ".backup '$OUT/app-$(date +%F-%H%M).db'"
find "$OUT" -name 'app-*.db' -mtime +14 -delete
echo "Backup finished: $(ls -1t "$OUT" | head -1)"
