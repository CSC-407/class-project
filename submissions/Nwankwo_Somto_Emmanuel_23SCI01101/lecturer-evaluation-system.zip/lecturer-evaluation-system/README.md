# Lecturer Evaluation System

A web application where students rate their lecturers anonymously and administrators manage lecturers, review averages and watch an audit log. It was built for a web application security assignment, so most of the effort went into authentication, access control, input handling, testing and deployment.

Everything it uses is free and open source: Python, Flask, SQLite, Bootstrap 5 (bundled in `app/static/vendor`, so no CDN is needed), Gunicorn and Nginx.

## What it does

1. Students register, log in, search and filter lecturers, submit one evaluation per lecturer per course, and delete their own evaluations.
2. Administrators add, edit and delete lecturers, disable student accounts, read averaged reports (with CSV export) and view the audit log.
3. Anyone can read the Security page, which explains each protection and points to the file that implements it.

## Run it locally

```bash
git clone <your-repo-url>
cd lecturer-evaluation-system
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env               # Windows: copy .env.example .env
# open .env and set SECRET_KEY to a long random value:
python -c "import secrets; print(secrets.token_hex(32))"

flask --app wsgi init-db
flask --app wsgi create-admin      # asks for name, email and password
flask --app wsgi seed-demo         # optional: sample lecturers and a demo student
flask --app wsgi run
```

Open http://127.0.0.1:5000. The demo student created by `seed-demo` is `student@example.com` with password `Student2025x`. It is meant for development only, so never run `seed-demo` on a live server.

## Run the tests

```bash
python -m pytest
```

The test plan and results are in [docs/TESTING.md](docs/TESTING.md). The same suite runs automatically on every push through GitHub Actions.

## Project layout

```
app/            application code (routes, models, forms, templates, static files)
tests/          automated test suite (pytest)
docs/           TESTING.md and DEPLOYMENT.md
deploy/         Nginx config, systemd service, backup script
config.py       development, production and testing settings
wsgi.py         entry point used by Gunicorn
```

## Deploying

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) for the full walkthrough from your laptop to a live HTTPS site, including environment variables, backups and log monitoring.

## Before you push to GitHub

Check that `.env`, `instance/` and `logs/` do not appear in `git status`. They are already listed in `.gitignore`, and they hold your secret key, your database and your logs.
