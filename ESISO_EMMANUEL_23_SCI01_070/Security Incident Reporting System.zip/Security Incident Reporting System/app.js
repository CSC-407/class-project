

   const KEY_USERS = 'beacon_users';
   const KEY_REPORTS = 'beacon_reports';
   const KEY_SESSION = 'beacon_session';
   const STATUSES = ['New', 'In Progress', 'Resolved'];
   
   const $ = (id) => document.getElementById(id);
   const load = (k, fallback) => { try { return JSON.parse(localStorage.getItem(k)) ?? fallback; } catch { return fallback; } };
   const save = (k, v) => localStorage.setItem(k, JSON.stringify(v));
   const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
   const fmt = (iso) => new Date(iso).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
   const stClass = (s) => 'st-' + s.replace(' ', '');
   

   if (!load(KEY_USERS, null)) {
     save(KEY_USERS, [{ name: 'Security Officer', email: 'officer@beacon.com', password: 'officer123', role: 'officer' }]);
   }
   
   let session = load(KEY_SESSION, null);   
   let filter = 'All';
   let openId = null;
   let signupMode = false;
   

   function show(id) {
     document.querySelectorAll('.screen').forEach((s) => (s.hidden = s.id !== id));
     $('topbar').hidden = id === 'authScreen';
     window.scrollTo(0, 0);
   }
   
   function goHome() {
     if (!session) { show('authScreen'); return; }
     if (session.role === 'officer') { renderDash(); show('dashScreen'); }
     else { renderHome(); show('homeScreen'); }
   }
   
   document.addEventListener('click', (e) => {
     const go = e.target.closest('[data-go]');
     if (go) goHome();
   });
   

   function setAuthMode(signup) {
     signupMode = signup;
     $('nameRow').hidden = !signup;
     $('aName').required = signup;
     $('authSubmit').textContent = signup ? 'Create account' : 'Log in';
     $('authToggle').textContent = signup ? 'Already registered? Log in' : 'New here? Create an account';
     $('aPass').autocomplete = signup ? 'new-password' : 'current-password';
     $('authError').textContent = '';
   }
   
   $('authToggle').addEventListener('click', () => setAuthMode(!signupMode));
   
   $('authForm').addEventListener('submit', (e) => {
     e.preventDefault();
     const email = $('aEmail').value.trim().toLowerCase();
     const pass = $('aPass').value;
     const users = load(KEY_USERS, []);
     const err = $('authError');
   
     if (signupMode) {
       if (users.some((u) => u.email === email)) { err.textContent = 'That email already has an account. Log in instead.'; return; }
       const user = { name: $('aName').value.trim(), email, password: pass, role: 'reporter' };
       users.push(user);
       save(KEY_USERS, users);
       session = { name: user.name, email, role: 'reporter' };
     } else {
       const user = users.find((u) => u.email === email && u.password === pass);
       if (!user) { err.textContent = 'Wrong email or password. Check both and try again.'; return; }
       session = { name: user.name, email: user.email, role: user.role };
     }
     save(KEY_SESSION, session);
     $('authForm').reset();
     goHome();
   });
   
   $('logoutBtn').addEventListener('click', () => {
     localStorage.removeItem(KEY_SESSION);
     session = null;
     setAuthMode(false);
     show('authScreen');
   });
   

   function cardHTML(r) {
     return `<button class="card sev-${esc(r.severity)}" data-id="${esc(r.id)}">
       <div class="row"><b>${esc(r.type)}</b><span class="pill ${stClass(r.status)}">${esc(r.status)}</span></div>
       <small>${esc(r.location)} &bull; ${esc(fmt(r.when))}</small>
       <small>${esc(r.id)} &bull; ${esc(r.severity)} severity${session.role === 'officer' ? ' &bull; by ' + esc(r.byName) : ''}</small>
     </button>`;
   }
   
   function bindCards(container) {
     container.querySelectorAll('.card').forEach((c) => c.addEventListener('click', () => openDetail(c.dataset.id)));
   }
   

   function renderHome() {
     $('greet').textContent = 'Hi ' + session.name.split(' ')[0] + ', stay safe.';
     const mine = load(KEY_REPORTS, []).filter((r) => r.by === session.email).sort((a, b) => b.created - a.created);
     const box = $('myList');
     box.innerHTML = mine.length ? mine.map(cardHTML).join('') : '<div class="empty">No reports yet. Tap the button above if you see something unsafe.</div>';
     bindCards(box);
   }
   
   $('newReportBtn').addEventListener('click', () => {
     $('reportForm').reset();
     const now = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
     $('fWhen').value = now;
     $('formError').textContent = '';
     show('formScreen');
   });
   
   $('reportForm').addEventListener('submit', (e) => {
     e.preventDefault();
     const reports = load(KEY_REPORTS, []);
     let id;
     do { id = 'BCN-' + Math.floor(1000 + Math.random() * 9000); } while (reports.some((r) => r.id === id));
     reports.push({
       id,
       type: $('fType').value,
       severity: document.querySelector('input[name=sev]:checked').value,
       location: $('fLoc').value.trim(),
       when: new Date($('fWhen').value).toISOString(),
       description: $('fDesc').value.trim(),
       status: 'New',
       note: '',
       by: session.email,
       byName: session.name,
       created: Date.now()
     });
     save(KEY_REPORTS, reports);
     $('doneRef').textContent = id;
     show('doneScreen');
   });
   

   function renderDash() {
     const all = load(KEY_REPORTS, []).sort((a, b) => b.created - a.created);
     const count = (s) => all.filter((r) => r.status === s).length;
     $('stats').innerHTML = STATUSES.map((s) => `<div class="stat"><b>${count(s)}</b><span>${s}</span></div>`).join('');
     $('chips').innerHTML = ['All', ...STATUSES].map((s) => `<button class="chip ${s === filter ? 'on' : ''}" data-f="${s}">${s}</button>`).join('');
     $('chips').querySelectorAll('.chip').forEach((c) => c.addEventListener('click', () => { filter = c.dataset.f; renderDash(); }));
     const shown = all.filter((r) => filter === 'All' || r.status === filter);
     const box = $('allList');
     box.innerHTML = shown.length ? shown.map(cardHTML).join('') : '<div class="empty">No reports here yet.</div>';
     bindCards(box);
   }
   

   function openDetail(id) {
     openId = id;
     renderDetail();
     show('detailScreen');
   }
   
   function renderDetail() {
     const r = load(KEY_REPORTS, []).find((x) => x.id === openId);
     if (!r) { goHome(); return; }
     const officer = session.role === 'officer';
     $('detailBody').innerHTML = `
       <h2>${esc(r.type)} <span class="pill ${stClass(r.status)}">${esc(r.status)}</span></h2>
       <div class="detail-box"><dl>
         <dt>Reference</dt><dd>${esc(r.id)}</dd>
         <dt>Severity</dt><dd>${esc(r.severity)}</dd>
         <dt>Location</dt><dd>${esc(r.location)}</dd>
         <dt>When it happened</dt><dd>${esc(fmt(r.when))}</dd>
         <dt>Reported by</dt><dd>${esc(r.byName)}</dd>
         <dt>Description</dt><dd>${esc(r.description)}</dd>
       </dl></div>
       ${officer ? `
         <label>Update status</label>
         <div class="status-row">${STATUSES.map((s) => `<button class="chip ${s === r.status ? 'on' : ''}" data-s="${s}">${s}</button>`).join('')}</div>
         <label>Note for the reporter<textarea id="noteInput" rows="3">${esc(r.note)}</textarea></label>
         <button class="btn primary" id="saveNote">Save note</button>`
       : (r.note ? `<div class="note-box"><b>Security note</b><p>${esc(r.note)}</p></div>` : '<p>Security will add a note here once they review your report.</p>')}`;
   
     if (officer) {
       $('detailBody').querySelectorAll('[data-s]').forEach((b) => b.addEventListener('click', () => updateReport({ status: b.dataset.s })));
       $('saveNote').addEventListener('click', () => updateReport({ note: $('noteInput').value.trim() }));
     }
   }
   
   function updateReport(changes) {
     const reports = load(KEY_REPORTS, []);
     const r = reports.find((x) => x.id === openId);
     if (!r) return;
     Object.assign(r, changes);
     save(KEY_REPORTS, reports);
     renderDetail();
   }
   
   $('detailBack').addEventListener('click', goHome);
   
 
   window.addEventListener('storage', (e) => {
     if (e.key !== KEY_REPORTS || !session) return;
     if (!$('detailScreen').hidden) renderDetail();
     else if (!$('dashScreen').hidden) renderDash();
     else if (!$('homeScreen').hidden) renderHome();
   });
   

   setAuthMode(false);
   goHome();